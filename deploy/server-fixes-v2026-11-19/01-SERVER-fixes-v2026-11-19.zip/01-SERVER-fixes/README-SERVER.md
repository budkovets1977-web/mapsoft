# 01-SERVER-fixes — серверные правки MapWebServer 6.00.60

## 1. core-server-fixes

Копировать файлы с сохранением структуры в корень MapWebServer сервера.

| Файл | Описание |
|---|---|
| `src/service/app/med/cisz/bundle.php` | Сплит-импорт Bundle: новый `Bundle.id` и новый `Bundle.identifier.value` для каждого под-бандла (сервер дедуплирует по identifier). Фикс «Импортируемый ресурс уже существует» для ЭЛН/ВН. |
| `src/service/app/med/cisz/traits/serviceRequestTrait.php` | MedLogSend: диагноз по умолчанию Z00.0, код услуги по умолчанию B01-023-001, инициализация `$diagId`, `diagId=0` для направлений без диагноза. |
| `src/service/app/med/cisz/traits/episodeOfTemporaryDisabilityTrait.php` | TDCaseClosing: заключение ВН только при `periodType === 'close'` (дефолт '1'), статус `finished` только для close. |
| `src/service/app/med/cisz/traits/encounterTrait.php` | MedVisitPatient: не формировать `Encounter.actualPeriod.end`, если `HH2/MM2` отсутствуют; отклонять явно указанное окончание раньше начала. Исправление FHIR `per-1`. |

После копирования: `php -l <файл>`, перезапуск Apache (OPcache выключен).

## 2. sendByDay-feature

Оригинальный пакет создания кнопки «Отправить в ЦИСЗ за день».

| Файл | Описание |
|---|---|
| `add-menu-cisz-sendbydate.sql` | Добавляет пункт меню в `map.SysMenu`. **Запускать только после бэкапа SysMenu!** |
| `src/service/app/med/cisz/sendByDate.php` | Backend JSON-RPC класс `med_cisz_sendByDate` |
| `src/desktop/build/production/{comfort,maptheme,maptouch}-ru/app/med/cisz.js` | Frontend view + controller |
| `src/desktop/build/production/{comfort,maptheme,maptouch}-ru/app/med/cisz-model.js` | Frontend model |
| `README.md` | Исходная инструкция пакета |

**Важно:** БД в WIN1251 — SQL уже содержит `SET client_encoding TO 'WIN1251';`.

## 3. sendByDay-latest-fixes

Последние улучшения кнопки и UI (пакет `mapsoft-ui-fixes-20261114`).

| Файл | Описание |
|---|---|
| `sendByDate.php.latest` | Заменить оригинальный `sendByDate.php` этим файлом. Добавлены фильтры врач/ЦИСЗ/закончено, проброс doctorId из картотеки. |
| `apply.php` | Установщик UI-правок (календарь, тулбары, кнопки, SendByDate). Режимы: `auto`, `blocks`, `verify`, `rollback`. |
| `rollback.php` | Откат UI-правок. |
| `README-UI-fixes.md` | Исходная инструкция. |

## Контрольные суммы SHA-256 (первые 16 символов)

- `bundle.php`: `964239F78BF07A03`
- `serviceRequestTrait.php`: `4D44F959389785C0`
- `episodeOfTemporaryDisabilityTrait.php`: `4409EBCC19F7CC3B`
- `encounterTrait.php`: `65E6F5A566856901`
