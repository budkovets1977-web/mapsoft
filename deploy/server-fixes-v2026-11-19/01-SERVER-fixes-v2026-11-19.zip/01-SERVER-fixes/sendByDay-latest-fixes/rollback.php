<?php
/**
 * Откат применённого пакета mapsoft-ui-fixes-20261114
 * Использование: php apply.php <путь к src> rollback
 * Ищет последний backup-ui-fixes-* внутри пакета и возвращает файлы.
 */
$srcRoot = isset($argv[1]) ? rtrim($argv[1], '"\\/') : null;
if (!$srcRoot) {
    fwrite(STDERR, "Использование: php apply.php <путь к src> rollback\n");
    exit(1);
}
$prod = $srcRoot . '\\desktop\\build\\production';
if (!is_dir($prod)) { fwrite(STDERR, "Не найден $prod\n"); exit(1); }

$cands = glob(__DIR__ . '\\backup-ui-fixes-*');
if (!$cands) { fwrite(STDERR, "Нет backup-ui-fixes-* в пакете\n"); exit(1); }
sort($cands);
$bak = end($cands);
echo "Откат из: $bak\n";

$themes = ['maptheme-ru', 'comfort-ru', 'maptouch-ru'];
$fail = 0;
foreach ($themes as $t) {
    foreach (['app.js', 'resources\\common.css'] as $rel) {
        $from = "$bak\\$t\\$rel";
        $to   = "$prod\\$t\\$rel";
        if (!file_exists($from)) { echo "  $t/$rel: нет в бэкапе, пропуск\n"; continue; }
        $r = @copy($from, $to);
        echo "  $t/$rel: " . ($r ? 'восстановлен' : 'ОШИБКА') . "\n";
        if (!$r) $fail++;
    }
}
$sbdFrom = "$bak\\sendByDate.php";
$sbdTo   = $srcRoot . '\\service\\app\\med\\cisz\\sendByDate.php';
if (file_exists($sbdFrom)) {
    $r = @copy($sbdFrom, $sbdTo);
    echo "  sendByDate.php: " . ($r ? 'восстановлен' : 'ОШИБКА') . "\n";
    if (!$r) $fail++;
}
echo $fail === 0 ? "Откат завершён успешно.\n" : "Откат с ошибками ($fail).\n";
exit($fail === 0 ? 0 : 1);
