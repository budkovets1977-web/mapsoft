<?php
/**
 * Установщик пакета доработок mapsoft-ui-fixes-20261114
 * ============================================================
 * Применяет доработки МИС MapWebServer на целевом сервере:
 *   1. Календарь (Ext.picker.Month): порядок месяцев/годов, компактная
 *      панель без обрезания, кнопки OK(#16a34a)/Отмена(#d9534f).
 *   2. Тулбары: поля одной высоты с кнопками (48px), кнопки с бирюзовым
 *      оттенком (#e6f5f3 / рамка #7fd0c8) через MutationObserver.
 *   3. sendByDate.php: массовая отправка ЦИСЗ (фильтры врач/ЦИСЗ/закончено).
 *
 * Использование:
 *   php apply.php <путь к src сервера> [режим]
 *
 *   <путь>  например D:\Mapsoft\MapWebServer\src
 *   [режим] auto (по умолчанию) | files | blocks | verify | rollback
 *
 * Логика auto:
 *   - app.js: если содержит __tealPainted => уже обновлён, пропуск;
 *     если совпадает с базовой версией (base/<theme>/app.js) => полная замена;
 *     иначе => append blocks/appjs_append.js (безопасно для любой версии).
 *   - common.css: если содержит маркер "21k." => пропуск; иначе append.
 *   - sendByDate.php: замена, если целевой совпадает с базой или отсутствует;
 *     если отличается от базы — предупреждение + append-режим не применим
 *     (это отдельный файл: спрашивать подтверждение не можем в CLI без -y,
 *     поэтому заменяем, а старый попадёт в бэкап).
 *
 * Перед любым изменением создаётся бэкап: backup-ui-fixes-<метка времени>\
 *
 * Перезапуск Apache / MapWebAssist выполняется администратором вручную.
 * OPcache у MapWebServer обычно выключен; если включён — перезапустите Apache.
 */

error_reporting(E_ALL);
ini_set('display_errors', '1');

$pkgRoot   = __DIR__;
$themes    = ['maptheme-ru', 'comfort-ru', 'maptouch-ru'];

// ---- Разбор аргументов -------------------------------------------------
$srcRoot = isset($argv[1]) ? rtrim($argv[1], '"\\/') : null;
$mode    = isset($argv[2]) ? strtolower($argv[2]) : 'auto';
$yes     = in_array('-y', $argv, true) || in_array('/y', $argv, true);

if ($mode === 'rollback') { require __DIR__ . '/rollback.php'; exit; }

if (!$srcRoot) {
    fwrite(STDERR, "Использование: php apply.php <путь к src сервера> [auto|files|blocks|verify] [-y]\n");
    exit(1);
}

$prod = $srcRoot . '\\desktop\\build\\production';
if (!is_dir($prod)) {
    fwrite(STDERR, "ОШИБКА: не найден каталог $prod\nПроверьте путь (должен указывать на ...\\MapWebServer\\src)\n");
    exit(1);
}

/**
 * Верификация наличия правок в содержимом.
 */
function hasModsJs($content) {
    return [
        'appjs_monthpicker' => strpos($content, 'Ext.override(Ext.picker.Month') !== false,
        'appjs_observer'    => strpos($content, '__tealPainted') !== false,
        'appjs_calcolors'   => strpos($content, '#16a34a') !== false && strpos($content, '#d9534f') !== false,
    ];
}

function hasModsCss($content) {
    return [
        'css_21blocks' => strpos($content, '21c.') !== false && strpos($content, '21k. Toolbar fields') !== false,
    ];
}

function out($s) { echo $s . "\n"; }

/**
 * Сравнение "общий префикс": возвращает длину совпадающего префикса.
 */
function commonPrefixLen($a, $b) {
    $min = min(strlen($a), strlen($b));
    $n = 0;
    $step = 4096;
    while ($n < $min) {
        $chunk = min($step, $min - $n);
        if (substr($a, $n, $chunk) !== substr($b, $n, $chunk)) {
            for ($i = $n; $i < $n + $chunk; $i++) {
                if ($a[$i] !== $b[$i]) return $i;
            }
        }
        $n += $chunk;
    }
    return $min;
}

$blockJs  = file_get_contents($pkgRoot . '\\blocks\\appjs_append.js');
$blockCss = file_get_contents($pkgRoot . '\\blocks\\common_css_append.css');
if ($blockJs === false || $blockCss === false) {
    fwrite(STDERR, "ОШИБКА: не найдены blocks\\appjs_append.js / blocks\\common_css_append.css\n");
    exit(1);
}

// ---- Режим verify ------------------------------------------------------
if ($mode === 'verify') {
    $fail = 0;
    foreach ($themes as $t) {
        $jsPath  = "$prod\\$t\\app.js";
        $cssPath = "$prod\\$t\\resources\\common.css";
        $js  = @file_get_contents($jsPath);
        $css = @file_get_contents($cssPath);
        if ($js === false || $css === false) { out("$t: ФАЙЛЫ НЕ НАЙДЕНЫ"); $fail++; continue; }
        $m = array_merge(hasModsJs($js), hasModsCss($css));
        $ok = $m['appjs_monthpicker'] && $m['appjs_observer'] && $m['appjs_calcolors'] && $m['css_21blocks'];
        out(sprintf("%s: monthpicker=%s observer=%s calcolors=%s css21=%s => %s",
            $t,
            $m['appjs_monthpicker'] ? 'Y' : 'n',
            $m['appjs_observer']    ? 'Y' : 'n',
            $m['appjs_calcolors']   ? 'Y' : 'n',
            $m['css_21blocks']      ? 'Y' : 'n',
            $ok ? 'OK' : 'NOT APPLIED'
        ));
        if (!$ok) $fail++;
    }
    $sbdPath = $srcRoot . '\\service\\app\\med\\cisz\\sendByDate.php';
    $sbd = @file_get_contents($sbdPath);
    $sbdOk = $sbd !== false && (strpos($sbd, 'doctorId') !== false);
    out("sendByDate.php: doctorId filter = " . ($sbdOk ? 'Y' : 'n') . " => " . ($sbdOk ? 'OK' : 'NOT APPLIED / OTHER VERSION'));
    exit($fail === 0 && $sbdOk ? 0 : 1);
}

// ---- Бэкап -------------------------------------------------------------
$bakDir = $pkgRoot . '\\backup-ui-fixes-' . date('Ymd-His');
foreach ($themes as $t) {
    @mkdir("$bakDir\\$t\\resources", 0777, true);
}
@mkdir("$bakDir\\service", 0777, true);
$sbdPath = $srcRoot . '\\service\\app\\med\\cisz\\sendByDate.php';
foreach ($themes as $t) {
    @copy("$prod\\$t\\app.js", "$bakDir\\$t\\app.js");
    @copy("$prod\\$t\\resources\\common.css", "$bakDir\\$t\\resources\\common.css");
}
@copy($sbdPath, "$bakDir\\sendByDate.php");
out("Бэкап: $bakDir");

// ---- Применение --------------------------------------------------------
$report = [];
$fail = 0;

foreach ($themes as $t) {
    out("-- $t --");

    // app.js
    $jsPath = "$prod\\$t\\app.js";
    $js = @file_get_contents($jsPath);
    if ($js === false) { out("  app.js: READ ERROR"); $fail++; }
    else {
        $m = hasModsJs($js);
        if ($m['appjs_monthpicker'] && $m['appjs_observer']) {
            out("  app.js: уже содержит доработки, пропуск");
        } elseif ($mode === 'files' || ($mode === 'auto' && file_exists($pkgRoot . "\\base\\$t\\app.js")
                 && commonPrefixLen($js, file_get_contents($pkgRoot . "\\base\\$t\\app.js")) === filesize($pkgRoot . "\\base\\$t\\app.js"))) {
            // точное совпадение с базой -> полная замена из files/
            $full = file_get_contents($pkgRoot . "\\files\\$t\\app.js");
            if (file_put_contents($jsPath, $full) === false) { out("  app.js: WRITE ERROR"); $fail++; }
            else out("  app.js: полная замена (" . strlen($full) . " B)");
        } elseif ($mode === 'blocks' || $mode === 'auto') {
            if (file_put_contents($jsPath, $js . "\n" . $blockJs) === false) { out("  app.js: WRITE ERROR (append)"); $fail++; }
            else out("  app.js: append blocks (" . strlen($blockJs) . " B)");
        }
    }

    // common.css
    $cssPath = "$prod\\$t\\resources\\common.css";
    $css = @file_get_contents($cssPath);
    if ($css === false) { out("  common.css: READ ERROR"); $fail++; }
    else {
        if (strpos($css, '21k. Toolbar fields') !== false) {
            out("  common.css: уже содержит блоки 21x, пропуск");
        } elseif ($mode === 'files' && file_exists($pkgRoot . "\\files\\$t\\resources\\common.css")) {
            $full = file_get_contents($pkgRoot . "\\files\\$t\\resources\\common.css");
            if (file_put_contents($cssPath, $full) === false) { out("  common.css: WRITE ERROR"); $fail++; }
            else out("  common.css: полная замена (" . strlen($full) . " B)");
        } else {
            if (file_put_contents($cssPath, $css . $blockCss . "\n") === false) { out("  common.css: WRITE ERROR (append)"); $fail++; }
            else out("  common.css: append blocks (" . strlen($blockCss) . " B)");
        }
    }
}

// sendByDate.php
out("-- sendByDate.php --");
if ($sbdPath && @file_exists(dirname($sbdPath))) {
    $cur = @file_get_contents($sbdPath);
    $new = file_get_contents($pkgRoot . '\\service\\app\\med\\cisz\\sendByDate.php');
    if ($cur !== false && strpos($cur, 'doctorId') !== false && strpos($cur, 'cisz') !== false) {
        out("уже обновлён (doctorId найден), пропуск");
    } else {
        if ($cur !== false && $cur !== $new && !$yes) {
            out("ВНИМАНИЕ: целевой sendByDate.php отличается от эталонной базы.");
            out("Старая версия сохранена в бэкап. Заменяю на версию из пакета.");
        }
        if (file_put_contents($sbdPath, $new) === false) { out("  WRITE ERROR"); $fail++; }
        else out("  заменён (" . strlen($new) . " B)");
    }
} else {
    out("  каталог service\\app\\med\\cisz не найден — файл пропущен (фронтенд-правки применены)");
}

// ---- Пост-проверка -----------------------------------------------------
out("\n== Пост-проверка ==");
foreach ($themes as $t) {
    $js  = @file_get_contents("$prod\\$t\\app.js");
    $css = @file_get_contents("$prod\\$t\\resources\\common.css");
    $m = array_merge(hasModsJs((string)$js), hasModsCss((string)$css));
    $ok = $m['appjs_monthpicker'] && $m['appjs_observer'] && $m['appjs_calcolors'] && $m['css_21blocks'];
    out("$t: " . ($ok ? 'OK' : 'FAIL'));
    if (!$ok) $fail++;
}

out("");
if ($fail === 0) {
    out("ГОТОВО. Все доработки применены.");
    out("Далее (вручную): перезапустите Apache/MapWebAssist, если включён OPcache;");
    out("в браузере сделайте жёсткую перезагрузку (Ctrl+F5) или ?_hardreload=<ts>.");
    exit(0);
} else {
    out("ЗАВЕРШЕНО С ОШИБКАМИ ($fail). Проверьте сообщения выше.");
    out("Откат: php rollback.php <путь к src> (использует последний backup-ui-fixes-*)");
    exit(2);
}
