# Пакет переноса: «Отправить в ЦИСЗ за день»

**Версия: 6.00.60 · Дата: 12.11.2026 · Локальная доработка (НЕ развёрнуто на боевом)**

Функция: кнопка в главном меню → окно со списком неотправленных посещений/дневников
за дату → выбор галочками → массовая отправка в ЦИСЗ.

## Состав пакета

| Файл | Назначение |
|---|---|
| `src/service/app/med/cisz/sendByDate.php` | Новый JSON-RPC-класс `med_cisz_sendByDate` (список + массовая отправка) |
| `src/desktop/build/production/{comfort,maptheme,maptouch}-ru/app/med/cisz.js` | Добавлены `Med.cisz.controller.SendByDate` + `Med.cisz.view.SendByDate` (append в конец) |
| `src/desktop/build/production/{comfort,maptheme,maptouch}-ru/app/med/cisz-model.js` | Добавлена модель `Med.cisz.model.SendByDate` (append в конец) |
| `add-menu-cisz-sendbydate.sql` | SQL для добавления пункта меню (таблица `map.SysMenu`) |

> **Структура фронтенда боевого сервера — ПЛОСКАЯ:** все модули (`cisz.js`,
> `cisz-model.js`, `homevisit.js` и т.д.) лежат в `app/med/` без подпапок. Поэтому
> виджет добавляется **append-блоком в конец `cisz.js`** (как вендор делает для
> соседних виджетов, напр. `med-cisz-setting`). Алиас `widget.med-cisz-sendbydate`
> регистрируется при загрузке `cisz.js` (он входит в скрипты задач медицины),
> поэтому `requireClass('med-cisz-sendbydate')` находит его без 404.

## Порядок развёртывания (по явной команде)

1. **Файлы** — скопировать содержимое `src/` в корень MapWebServer на боевом сервере.
   - `cisz.js` — заменить (append-блок view+controller в конце).
   - `cisz-model.js` — заменить (append-блок модели в конце).
   - `sendByDate.php` — новый файл (добавить).
2. **Пункт меню** — выполнить `add-menu-cisz-sendbydate.sql` на БД `meddb` (схема `map`).
   - ⚠️ **Кодировка:** БД в WIN1251. Имя пункта должно записаться в WIN1251
     (в SQL уже стоит `SET client_encoding TO 'WIN1251';`). Если вставить имя в UTF-8,
     `readNavigatorItems` упадёт с `22P05` и задача «Администрирование (медицина)»
     не откроется.
   - Перед этим снять бэкап `SysMenu`.
3. **Перезапуск Apache + MapWebAssist** (выполняет администратор) — чтобы webassist
   перечитал навигатор и пункт появился в меню.
4. **Кэш** — пользователи должны обновить фронтенд (Ctrl+F5).

## Проверка

- Открыть МИС → переключиться на задачу «Администрирование (медицина)» →
  раздел «Обмены» → «Отправить в ЦИСЗ за день».
- Выбрать дату → «Обновить» → отметить записи → «Отправка».
- Результат: число отправленных и ошибок по каждой записи.

## Откат

- Пункт меню: `DELETE FROM map.SysMenu WHERE ModuleFileName = 'med-cisz-sendbydate';`
- Файлы: вернуть предыдущие версии `cisz.js`/`cisz-model.js`, удалить `sendByDate.php`.
