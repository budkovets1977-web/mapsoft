<?php
 require_once(__DIR__ . '/../../init.php'); require_once('constant.php'); require_once('enums.php'); suspendJsonRpc(); require_once('api.php'); resumeJsonRpc(); require_once('traits/encounterTrait.php'); require_once('traits/patientTrait.php'); require_once('traits/practitionerTrait.php'); require_once('traits/organizationTrait.php'); require_once('traits/observationTrait.php'); require_once('traits/relatedPersonTrait.php'); require_once('traits/questionnaireResponseTrait.php'); require_once('traits/familyMemberHistoryTrait.php'); require_once('traits/prescriptionListTrait.php'); require_once('traits/serviceRequestTrait.php'); require_once('traits/carePlanTrait.php'); require_once('traits/allergyIntolerance.php'); require_once('traits/procedureTrait.php'); require_once('traits/diagnosticReportTrait.php'); require_once('traits/episodeOfCareTrait.php'); require_once('traits/medicationOrder.php'); require_once('traits/placeOfCare.php'); require_once('traits/episodeOfTemporaryDisabilityTrait.php'); require_once('traits/specimenTrait.php'); require_once('traits/adverseEventTrait.php'); require_once('traits/vaccinationTrait.php'); require_once('traits/medicalDevice.php'); require_once('traits/dicom.php'); class med_cisz_bundle { use med_cisz_encounterTrait, med_cisz_patientTrait, med_cisz_practitionerTrait, med_cisz_organizationTrait, med_cisz_observationTrait, med_cisz_relatedPersonTrait, med_cisz_questionnaireResponseTrait, med_cisz_familyMemberHistoryTrait, med_cisz_prescriptionListTrait, med_cisz_serviceRequestTrait, med_cisz_prescriptionListTrait, med_cisz_corePlanTrait, med_cisz_allergyIntolerance, med_cisz_procedureTrait, med_cisz_diagnosticReportTrait, med_cisz_episodeOfCareTrait, med_cisz_medicationOrder, med_cisz_placeOfCare, med_cisz_episodeOfTemporaryDisabilityTrait, med_cisz_specimenTrait, med_cisz_adverseEventTrait, med_cisz_vaccinationTrait, med_cisz_dicom, med_cisz_medicalDevice; private PDO_ANY $db; private object $settings; private ?int $visitPatientId = null; private ?int $patientId = null; private ?int $doctorId = null; private ?array $visitPatient = null; private object $bundle; private object $composition; private $encounter; private $encounterVKK; private $practitioner; private $patient; private $organization; private $conditions = null; private $observations = null; private $observationsMedication = null; private $observationsAllergy = null; private $relatedPersons = null; private $questionnaireResponses = null; private $familyMemberHistory = null; private $documentReference = null; private ?array $prescriptionList = null; private ?array $carePlanList = null; private $serviceRequest = null; private $procedure = null; private $procedurePatient = null; private $xRay = null; private $carePlan = null; private array $xRayDiag = [ 'serviceRequest' => null, 'carePlan' => null, 'procedure' => null ]; private $diagnosticReport = null; private $diagnosticReportSecond = null; private $funcDiagObservation = null; private $medication = null; private $medicationOrder = null; private $medicationAllergy = null; private $medicationCancelOrder = null; private ?string $entity = null; private ?string $docType = null; private $funcDiagnostic = null; private $dirTime = null; private $allergyIntolerance = null; private $allergyAnamnesis = null; private $placeOfCare = null; private $vaccination = null; private $vaccinationRecommendation = null; private $dicomDevice = null; private array $functDiag = [ 'serviceRequest' => null, 'procedure' => null, 'observation' => null, 'diagnosticReport' => null ]; private array $functImaging = [ 'serviceRequest' => null, 'procedure' => null, 'observation' => null, 'diagnosticReport' => null, 'diagnosticReportSecond' => null ]; private $funcDiagProcedure = null; private ?array $bundles = null; private ?array $hospitalisationActions = null; private ?array $temporaryDisability =null; private $contract = null; private $episodeOfCare = null; private $requests = null; private $temporaryDisabilityTrait = null; private $temporaryDisabilityFlags = null; private $placeOfCareDocuments = null; private ?array $inspect = null; private ?object $addInfo = null; public function __construct() { self::init($this); } private $specimen = null; private array $medLabStudy = [ 'serviceRequest' => null, 'specimen' => null, 'diagnosticReport' => null ]; private array $medProcudere = [ 'serviceRequest' => null, 'procedure' => null ]; private $adverseEvent = null; private $specimens = null; private $diagnosticReports = null; private $medicationOperation = null; private $medicalDevice = null; private $deviceRequest = null; private $device = null; private $deviceDispense = null; private $isInspect = false; private $addEncounter = null; private $radioIzotop = null; private $radioIzotopPatient = null; public function createBundleAndImport(?object $params = null): object { if ($params->entity === 'MedPatient' || $params->entity === 'TemporaryDisability') { $type = 1; } else { $type = 2; } switch ($params->entity){ case 'MedLog': $params->primaryKey = $params->visitPatientId; return $this->doExportToCisz($params); case 'MedLogStudy': case 'MedLogStudyLab': case 'MedLogStudyImage': { $entity = $params->entity . '/%'; break; } case 'MedDeviceHosp': { $entity = 'DeviceRequestStat'; break; } case 'MedMedicationHosp': { $entity = 'MedicationRequestStat'; break; } default: { $entity = $params->entity; break; } } if (isset($params->isInspect) && $params->isInspect) { $this->isInspect = true; } $status = selectSql($this->db, <<<SQL
        SELECT
            Status AS "status",
            TableName AS "tableName",
            Uuid AS "uuid"
        FROM CiszLink
            WHERE PrimaryKey = :id AND TableName like :entity AND Type = :type
        ORDER BY TableName
        SQL,
[ ':id' => ($params->entity === 'MedInspect' && isset($params->inspectCode)) ? $params->inspectCode : ($params->visitPatientId ?? $params->patientId), ':entity' => $entity, ':type' => $type ], PDO::FETCH_OBJ ); $this->functDiag['serviceRequest'] = (object)[ 'send' => null ]; $this->functDiag['procedure'] = (object)[ 'send' => null ]; $this->functDiag['observation'] = (object)[ 'send' => null ]; $this->functDiag['diagnosticReport'] = (object)[ 'send' => null ]; $this->medLabStudy['serviceRequest'] = (object)[ 'send' => null ]; $this->medLabStudy['specimen'] = (object)[ 'send' => null ]; $this->medLabStudy['diagnosticReport'] = (object)[ 'send' => null ]; $this->functImaging['serviceRequest'] = (object)[ 'send' => null ]; $this->functImaging['observation'] = (object)[ 'send' => null ]; $this->functImaging['diagnosticReport'] = (object)[ 'send' => null ]; $this->functImaging['procedure'] = (object)[ 'send' => null ]; $this->functImaging['diagnosticReportSecond'] = (object)[ 'send' => null ]; $this->medProcudere['serviceRequest'] = (object)[ 'send' => null ]; $this->medProcudere['procedure'] = (object)[ 'send' => null ]; $this->xRayDiag['serviceRequest'] = (object) [ 'send' => null ]; $this->xRayDiag['carePlan'] = (object) [ 'send' => null ]; $this->xRayDiag['procedure'] = (object) [ 'send' => null ]; $this->radioIzotop['serviceRequest'] = (object)[ 'send' => null ]; $this->radioIzotop['diagnosticReport'] = (object)[ 'send' => null ]; if ($params->entity === 'MedLogStudy' || $params->entity === 'MedLogStudyLab' || $params->entity === 'MedLogStudyImage') { $this->patientId = selectSql($this->db, <<<SQL
                SELECT
                    MedPatientCode AS "mpc"
                FROM MedLogStudy
                    WHERE MedLogStudyCode = :id
                SQL,
[ ':id' => $params->visitPatientId ], PDO::FETCH_OBJ )[0]->mpc; } if ($params->entity === 'MedHospitalRequest') { $this->patientId = selectSql($this->db, <<<SQL
                SELECT
                    MedPatientCode AS "mpc"
                FROM MedLogHospital
                    WHERE MedLogHospitalCode = :id
                SQL,
[ ':id' => $params->visitPatientId ], PDO::FETCH_OBJ )[0]->mpc; } if ($params->entity === 'MedLogHospital') { $this->patientId = selectSql($this->db, <<<SQL
                SELECT
                    MedPatientCode AS "mpc"
                FROM MedLog
                    WHERE MedLogCode = :id
                SQL,
[ ':id' => $params->visitPatientId ], PDO::FETCH_OBJ )[0]->mpc; } if ($params->entity === 'MedDeviceHosp') { $this->patientId = selectSql($this->db, <<<SQL
                SELECT
                    MSC.MedPatientCode AS "mpc"
                FROM
                    MedPurposeDepartment MPD
                JOIN MedPurpose M on M.MedPurposeDepartmentCode = MPD.MedPurposeDepartmentCode
                JOIN MedStatCard MSC on MSC.MedStatCardCode = MPD.MedStatCardCode
                    WHERE M.MedPurposeCode = :id
                SQL,
[ ':id' => $params->visitPatientId ], PDO::FETCH_OBJ )[0]->mpc; } $this->visitPatientId = $this->visitPatientId ?: ($params->visitPatientId ?? null); $this->patientId = $this->patientId ?: ($params->patientId ?? null); if ($params->entity !== 'DicomDevice') { if (!$this->patientId && $this->visitPatientId && $params->entity !== 'MedMedication' && $params->entity !== 'MedAllergy') { $this->patientId = (int) selectSqlValue( $this->db, "SELECT MedPatientCode FROM MedVisitPatient WHERE MedVisitPatientCode = ?", [$this->visitPatientId] ); } elseif (!$this->patientId && $this->visitPatientId && $params->entity == 'MedMedication') { $this->patientId = (int) selectSqlValue( $this->db, "SELECT MedPatientCode FROM MedDayHopsitalPurpose WHERE MedDayHopsitalPurposeCode = ?", [$this->visitPatientId] ); } elseif (!$this->patientId && $this->visitPatientId && $params->entity == 'MedAllergy') { $this->patientId = (int) selectSqlValue( $this->db, "SELECT MedPatientCode FROM MedAllergy WHERE MedAllergyCode = ?", [$this->visitPatientId] ); } } if ($status && $params->entity !== 'MedPatient') { $statusCond = false; $statusMLS = false; $MLS = false; $uuids = []; foreach ($status as $linkItem) { in_array($linkItem->uuid, $uuids) ?: (str_contains($linkItem->tableName, "MedLogStudy/") || str_contains($linkItem->tableName, "MedLogStudyLab/")) ?: $uuids[] = (object)[ 'uuid' => $linkItem->uuid, 'tableName' => $linkItem->tableName ]; $linkItem->status !== 2 || ($statusCond = true); } if ($params->entity === 'MedLogStudy'){ foreach ($status as $statusItem) { if (!$statusMLS) { if ($statusItem->tableName === 'MedLogStudy/1') { if ($statusItem->status === 2){ $this->functDiag['serviceRequest']->send = false; $this->functDiag['procedure']->send = false; $this->functDiag['observation']->send = false; $this->functDiag['diagnosticReport']->send = false; $statusMLS = true; } else { $this->functDiag['serviceRequest']->send = true; } } elseif ($statusItem->tableName === 'MedLogStudy/2') { if ($statusItem->status === 2){ $this->functDiag['procedure']->send = false; $this->functDiag['observation']->send = false; $this->functDiag['diagnosticReport']->send = false; $statusMLS = true; } else { $this->functDiag['procedure']->send = true; } } elseif ($statusItem->tableName === 'MedLogStudy/3') { if ($statusItem->status === 2){ $this->functDiag['observation']->send = false; $this->functDiag['diagnosticReport']->send = false; $statusMLS = true; } else { $this->functDiag['observation']->send = true; } } elseif ($statusItem->tableName === 'MedLogStudy/4') { if ($statusItem->status === 2){ $this->functDiag['diagnosticReport']->send = false; $statusMLS = true; } else { $this->functDiag['diagnosticReport']->send = true; } } if ($statusItem->status === 2) { $uuidItem = !(str_contains($statusItem->uuid, "(MedLogStudy/")) ? $statusItem->uuid : explode(')', $statusItem->uuid, 2)[1]; in_array($uuidItem, $uuids) ?: $uuids[] = (object)[ 'uuid' => $uuidItem, 'tableName' => $statusItem->tableName ]; foreach ($status as $findItem){ if (str_contains($findItem->uuid, $uuidItem)){ switch ($findItem->tableName){ case 'MedLogStudy/1': { $this->functDiag['serviceRequest']->send = false; break; } case 'MedLogStudy/2': { $this->functDiag['procedure']->send = false; break; } case 'MedLogStudy/3': { $this->functDiag['observation']->send = false; break; } case 'MedLogStudy/4': { $this->functDiag['diagnosticReport']->send = false; break; } } } } } } } foreach ($this->functDiag as $itemFD) { if ($itemFD->send !== true ){ $MLS = true; } } } if ($params->entity === 'MedLogStudyImage'){ foreach ($status as $statusItem) { if (!$statusMLS) { if ($statusItem->tableName === 'MedLogStudyImage/1') { if ($statusItem->status === 2){ $this->functImaging['serviceRequest']->send = false; $this->functImaging['observation']->send = false; $this->functImaging['diagnosticReport']->send = false; $this->functImaging['procedure']->send = false; $this->functImaging['diagnosticReportSecond']->send = false; $statusMLS = true; } else { $this->functImaging['serviceRequest']->send = true; } } elseif ($statusItem->tableName === 'MedLogStudyImage/2') { if ($statusItem->status === 2){ $this->functImaging['observation']->send = false; $this->functImaging['diagnosticReport']->send = false; $this->functImaging['diagnosticReportSecond']->send = false; $statusMLS = true; } else { $this->functImaging['observation']->send = true; } } elseif ($statusItem->tableName === 'MedLogStudyImage/3') { if ($statusItem->status === 2) { $this->functImaging['diagnosticReport']->send = false; $statusMLS = true; } else { $this->functImaging['diagnosticReport']->send = true; } } elseif ($statusItem->tableName === 'MedLogStudyImage/4') { if ($statusItem->status === 2) { $this->functImaging['procedure']->send = false; $statusMLS = true; } else { $this->functImaging['procedure']->send = true; } } elseif ($statusItem->tableName === 'MedLogStudyImage/5') { if ($statusItem->status === 2) { $this->functImaging['diagnosticReportSecond']->send = false; $statusMLS = true; } else { $this->functImaging['diagnosticReportSecond']->send = true; } } if ($statusItem->status === 2) { $uuidItem = !(str_contains($statusItem->uuid, "(MedLogStudyImage/")) ? $statusItem->uuid : explode(')', $statusItem->uuid, 2)[1]; in_array($uuidItem, $uuids) ?: $uuids[] = (object)[ 'uuid' => $uuidItem, 'tableName' => $statusItem->tableName ]; foreach ($status as $findItem){ if (str_contains($findItem->uuid, $uuidItem)){ switch ($findItem->tableName){ case 'MedLogStudyImage/1': { $this->functImaging['serviceRequest']->send = false; break; } case 'MedLogStudyImage/2': { $this->functImaging['observation']->send = false; break; } case 'MedLogStudyImage/3': { $this->functImaging['diagnosticReport']->send = false; break; } case 'MedLogStudyImage/4': { $this->functImaging['procedure']->send = false; break; } case 'MedLogStudyImage/5': { $this->functImaging['diagnosticReportSecond']->send = false; break; } } } } } } } foreach ($this->functImaging as $itemImg) { if ($itemImg->send !== true ){ $MLS = true; } } } if ($params->entity === 'MedLogStudyLab') { foreach ($status as $statusItem) { if (!$statusMLS) { if ($statusItem->tableName === 'MedLogStudyLab/1') { if ($statusItem->status === 2){ $this->medLabStudy['serviceRequest']->send = false; $this->medLabStudy['diagnosticReport']->send = false; $statusMLS = true; } else { $this->medLabStudy['serviceRequest']->send = true; } } elseif ($statusItem->tableName === 'MedLogStudyLab/2') { if ($statusItem->status === 2) { $this->medLabStudy['serviceRequest']->send = false; $this->medLabStudy['specimen']->send = false; $this->medLabStudy['diagnosticReport']->send = false; $statusMLS = true; } else { $this->medLabStudy['specimen']->send = true; } } elseif ($statusItem->tableName === 'MedLogStudyLab/3') { if ($statusItem->status === 2){ $this->medLabStudy['diagnosticReport']->send = false; $statusMLS = true; } else { $this->medLabStudy['diagnosticReport']->send = true; } } if ($statusItem->status === 2) { $uuidItem = !(str_contains($statusItem->uuid, "(MedLogStudyLab/")) ? $statusItem->uuid : explode(')', $statusItem->uuid, 2)[1]; in_array($uuidItem, $uuids) ?: $uuids[] = (object)[ 'uuid' => $uuidItem, 'tableName' => $statusItem->tableName ]; foreach ($status as $findItem){ if (str_contains($findItem->uuid, $uuidItem)){ switch ($findItem->tableName){ case 'MedLogStudyLab/1': { $this->medLabStudy['serviceRequest']->send = false; break; } case 'MedLogStudyLab/2': { $this->medLabStudy['specimen']->send = false; break; } case 'MedLogStudyLab/3': { $this->medLabStudy['diagnosticReport']->send = false; break; } } } } } } } foreach ($this->medLabStudy as $itemLS) { if ($itemLS->send !== true ){ $MLS = true; } } } $statusCond = (($params->entity === 'MedLogStudy') || ($params->entity === 'MedLogStudyLab') || ($params->entity === 'MedLogStudyImage')) ? $MLS : $statusCond; if ($params->entity === 'MedMedication' || $params->entity === 'MedLogHospital' || $params->entity === 'MedStatCard' || $params->entity === 'MedTherapyStom' || $params->entity === 'StomVisit' || $params->entity === 'MedXRayStat') { $statusCond = true; } if ($params->entity === 'TemporaryDisability') { foreach ($status as $item){ if ($item->status === 1) { return (object)[ 'status' => 1, ]; } } } if ($statusCond) { foreach ($uuids as $item) { if ($params->entity !== 'MedVaccinationRecommendation' && $params->entity !== 'MedMedication' && $params->entity !== 'MedProcedure' && $params->entity !== 'MedLogHospital' && $params->entity !== 'MedLogStudyImage' && $params->entity !== 'MedStatCard' && $params->entity !== 'MedMedicationHosp' && $params->entity !== 'MedTherapyStom' && $params->entity !== 'StomVisit' && $params->entity !== 'MedXRayStat' && ($params->entity !== 'MedInspect' && ($params->isInspect ?? true))) { $this->doCancelBundle($item->uuid); } } } else { return (object)[ 'status' => 1, ]; } } if (!$params) { throw new Exception( sprintf(med_cisz_constant::ERROR_INVALID_CREATE_BUNDLE_PARAMS_TEXT, 'params'), med_cisz_constant::ERROR_INVALID_CREATE_BUNDLE_PARAMS_CODE ); } $id = generateUUID(null, null, true); $this->setupBundleInfo($id,$params); if ($params->entity === 'MedLogStudy' || $params->entity === 'MedVisitPatient' || $params->entity === 'MedInspect' || ($params->entity === 'MedStatCard' && $this->funcDiagnostic) || ($params->entity === 'StomVisit' && $this->funcDiagnostic)) { if (!$this->functDiag['serviceRequest']->send && isset($this->functDiag['serviceRequest']->object) && !str_starts_with($this->functDiag['serviceRequest']->object->profile->resource->id,'sr-')) { $this->serviceRequest = $this->functDiag['serviceRequest']->object; } if (!$this->medProcudere['serviceRequest']->send && isset($this->medProcudere['serviceRequest']->object) && !str_starts_with($this->medProcudere['serviceRequest']->object->profile->resource->id,'sr-')) { $this->serviceRequest = $this->medProcudere['serviceRequest']->object; } if (!$this->functDiag['procedure']->send && isset($this->functDiag['procedure']->object)) { $this->procedure = $this->functDiag['procedure']->object; } if (!$this->functDiag['observation']->send && isset($this->functDiag['observation']->object)) { $this->funcDiagObservation = $this->functDiag['observation']->object; } if (!$this->functDiag['diagnosticReport']->send && isset($this->functDiag['diagnosticReport']->object)) { $this->diagnosticReport = $this->functDiag['diagnosticReport']->object; } if (!$this->serviceRequest && !$this->procedure && !$this->funcDiagObservation && !$this->diagnosticReport && $params->entity !== 'MedVisitPatient' && $params->entity !== 'MedInspect' && $params->entity !== 'MedStatCard' && $params->entity !== 'StomVisit' ) { return (object)[ 'status' => 1, ]; } } if ($params->entity === 'MedXRayStat') { if (!$this->xRayDiag['serviceRequest']->send && isset($this->xRayDiag['serviceRequest']->object) && !str_starts_with($this->xRayDiag['serviceRequest']->object->profile->resource->id,'sr-')) { $this->serviceRequest = $this->xRayDiag['serviceRequest']->object; } if (!$this->xRayDiag['carePlan']->send && isset($this->xRayDiag['carePlan']->object)) { $this->carePlan = $this->xRayDiag['carePlan']->object; } if (!$this->xRayDiag['procedure']->send && isset($this->xRayDiag['procedure']->object)) { $this->procedure = $this->xRayDiag['procedure']->object; } } if ($params->entity === 'MedLogStudyImage' || $params->entity === 'MedVisitPatient') { if (!$this->functImaging['serviceRequest']->send && isset($this->functImaging['serviceRequest']->object) && !str_starts_with($this->functImaging['serviceRequest']->object->profile->resource->id,'sr-')) { $this->serviceRequest = $this->functImaging['serviceRequest']->object; } if (!$this->functImaging['observation']->send && isset($this->functImaging['observation']->object)) { $this->funcDiagObservation = $this->functImaging['observation']->object; } if (!$this->functImaging['diagnosticReport']->send && isset($this->functImaging['diagnosticReport']->object)) { $this->diagnosticReport = $this->functImaging['diagnosticReport']->object; } if (!$this->functImaging['diagnosticReportSecond']->send && isset($this->functImaging['diagnosticReportSecond']->object)) { $this->diagnosticReportSecond = $this->functImaging['diagnosticReportSecond']->object; } if (!$this->functImaging['procedure']->send && isset($this->functImaging['procedure']->object)) { $this->funcDiagProcedure = $this->functImaging['procedure']->object; } if (!$this->serviceRequest && !$this->funcDiagObservation && !$this->diagnosticReport && !$this->diagnosticReportSecond && !$this->funcDiagProcedure && $params->entity !== 'MedVisitPatient') { return (object)[ 'status' => 1, ]; } } if ($params->entity === 'MedLogStudyLab' || $params->entity === 'MedVisitPatient' || (($params->entity === 'MedStatCard' || $params->entity === 'StomVisit') && (isset($this->medLabStudy['serviceRequest']->object) || isset($this->medLabStudy['specimen']->object) || isset($this->medLabStudy['diagnosticReport']->object)))) { if (!$this->medLabStudy['serviceRequest']->send && isset($this->medLabStudy['serviceRequest']->object)) { $this->serviceRequest = $this->medLabStudy['serviceRequest']->object; } if (!$this->medLabStudy['specimen']->send && isset($this->medLabStudy['specimen']->object)) { $this->specimen = $this->medLabStudy['specimen']->object; } if (!$this->medLabStudy['diagnosticReport']->send && isset($this->medLabStudy['diagnosticReport']->object)) { $this->diagnosticReport = $this->medLabStudy['diagnosticReport']->object; } if (!$this->serviceRequest && !$this->specimen && !$this->diagnosticReport && $params->entity !== 'MedVisitPatient') { return (object)[ 'status' => 1, ]; } } if ($params->entity === 'MedProcedure' || $params->entity === 'MedProcStat' || $params->entity === 'MedTherapyStom') { if (!$this->medProcudere['serviceRequest']->send && isset($this->medProcudere['serviceRequest']->object) && !str_starts_with($this->medProcudere['serviceRequest']->object->profile->resource->id,'sr-')) { $this->serviceRequest = $this->medProcudere['serviceRequest']->object; } } if ($params->entity === 'MedRadioIzotopStat' || $params->entity === 'MedRadioIzotopStom') { $hasIzotop = false; if (!$this->radioIzotop['serviceRequest']->send && isset($this->radioIzotop['serviceRequest']->object) && !str_starts_with($this->radioIzotop['serviceRequest']->object->profile->resource->id,'sr-')) { $this->serviceRequest = $this->radioIzotop['serviceRequest']->object; $hasIzotop = true; } if (!$this->radioIzotop['diagnosticReport']->send && isset($this->radioIzotop['diagnosticReport']->object)) { $this->diagnosticReport = $this->radioIzotop['diagnosticReport']->object; $hasIzotop = true; } if (!$hasIzotop) { return (object)[ 'status' => 1, ]; } } if ($params->entity === 'DicomDevice') { $this->createDicomDeviceBody($id); } else { $this->createBundleBody($id); } $bundle = $this->bundle; return $this->importBundle($bundle, $params); } public function doExportToCisz(?object $params):object { $entity = $params->entity; $registrator = new med_cisz_entityHandlers_registrator(); $handler = $registrator->get($entity); $profiles = $handler::PROFILES; $this->patientId = $handler::loadPatientId($this->db, $params); $context = $this->createDependencies(); $resultsImport = []; foreach ($profiles as $profile) { $params->profile = $profile; $profileRegistrator = new med_cisz_profileHandlerRegistry_registrator($context); $profileHandler = $profileRegistrator->get($profile); if (!$profileHandler->needSending($this->db, $params)) { continue; } $resource = $profileHandler->createResource($params); $bundle = $this->createBundle((object) [ 'resource' => $resource ], $context); $resultData = $this->doExportBundle($bundle); if ($resultData->error ?? false) { continue; } self::upsertCiszLink( $this->db, $entity, null, $params->primaryKey, 1, 1, $resultData->resourceId, strstr($profile, '_', true) ); $resultsImport[] = $resultData->result; } if (!($resultsImport[0] ?? false)) { throw new Error('Выбранные записи не нуждаются в отправке'); } return $resultsImport[0]; } public function doExportBundle(object $bundle):object { $rawBundle = clone $bundle; $reqParams = (object) [ 'url' => $this->settings->url . 'fhir/Bundle/$import', 'headers' => [ 'Content-Type' => 'application/cms', ], 'request_content' => $rawBundle, ]; $historyId = $this->history( StatusEnum::PENDING, HistoryActionTypeEnum::REGISTRATION, request: $reqParams ); $reqParams->request_content = $this->encodeAndSign($bundle); $result = self::doHttpMethodWithAuth($this->settings, $reqParams, 'POST', false); $resourceId = self::extractParameter($result, 'ResourceId'); $this->history( $resourceId ? StatusEnum::PENDING : StatusEnum::FAILED, response: $result, historyId: $historyId ); if ($resourceId) { self::historyUpdateId($this->db, $historyId, 'BundleId', $resourceId); return (object) [ 'result' => $result, 'historyId' => $historyId, 'resourceId' => $resourceId ]; } return (object) [ 'error' => self::extractErrors($result), 'details' => $result, 'bundle' => $rawBundle, ]; } private function createDependencies() { $this->createOrganization(); $this->createPatient(); if (is_string(($mapMedDoctor = getSessionValue('mapMedDoctor')))) { $mapMedDoctor = json_decode($mapMedDoctor, true); } $this->doctorId = $mapMedDoctor['MedDoctorCode'] ?? null; $this->createPractitioner(); return new med_cisz_context( $this->settings, $this->patient, $this->organization, $this->practitioner ); } public function createBundle(?object $params, med_cisz_context $ctx) { $bundleBuilder = new med_cisz_bundle_builder($ctx); $resource = $params->resource; $data = (object) [ 'entries' => [$resource], ]; return $bundleBuilder->build($data); } public function exportBundle(?object $bundle, ?object $params = null): object { $rawBundle = clone $bundle; $reqParams = (object) [ 'url' => $this->settings->url . 'fhir/Bundle/$import', 'headers' => [ 'Content-Type' => 'application/cms', ], 'request_content' => $rawBundle, ]; $historyId = $this->history( StatusEnum::PENDING, HistoryActionTypeEnum::REGISTRATION, request: $reqParams ); $reqParams->request_content = $this->encodeAndSign($bundle); $result = self::doHttpMethodWithAuth($this->settings, $reqParams, 'POST', false); $resourceId = self::extractParameter($result, 'ResourceId'); $this->history( $resourceId ? StatusEnum::PENDING : StatusEnum::FAILED, response: $result, historyId: $historyId ); if ($resourceId) { self::updateCiszLink($resourceId, $params, $historyId); return $result; } return (object) [ 'error' => self::extractErrors($result), 'details' => $result, 'bundle' => $rawBundle, ]; } public function importBundle(?object $bundle, ?object $params = null): object { $eoctdIdx = []; $flagIdx = []; foreach (($bundle->entry ?? []) as $i => $entry) { $res = $entry->resource ?? null; if (!$res) { continue; } $profile = $res->meta->profile[0] ?? ''; if (($res->resourceType ?? '') === 'EpisodeOfCare' && $profile === med_cisz_constant::$structureDefinitions['EpisodeOfTemporaryDisability']) { $eoctdIdx[] = $i; } elseif (($res->resourceType ?? '') === 'Flag' && $profile === med_cisz_constant::$structureDefinitions['FlagTemporaryDisability']) { $flagIdx[] = $i; } } if (count($eoctdIdx) <= 1) { return $this->importBundleSingle($bundle, $params); } $lastResult = null; $firstIdx = $eoctdIdx[0]; $lastIdx = end($eoctdIdx); $originalBundleId = $bundle->id ?? null; $originalIdentifier = $bundle->identifier->value ?? null; foreach ($eoctdIdx as $idx) { $sub = clone $bundle; $sub->entry = []; foreach (($bundle->entry ?? []) as $i => $entry) { if (in_array($i, $eoctdIdx, true) && $i !== $idx) { continue; } if (in_array($i, $flagIdx, true) && $idx !== $firstIdx) { continue; } $sub->entry[] = $entry; } if ($originalBundleId) { $newBundleId = generateUUID(null, null, true); $newIdentifier = 'urn:uuid:' . generateUUID(null, null, true); $subJson = json_encode($sub, JSON_UNESCAPED_UNICODE); $subJson = str_replace($originalBundleId, $newBundleId, $subJson); if ($originalIdentifier) { $subJson = str_replace($originalIdentifier, $newIdentifier, $subJson); } $sub = json_decode($subJson); $sub->id = $newBundleId; $sub->identifier->value = $newIdentifier; } $lastResult = $this->importBundleSingle($sub, $params, $idx === $lastIdx); if (!empty($lastResult->error)) { return $lastResult; } if ($idx !== $lastIdx) { sleep(2); } } return $lastResult; } private function importBundleSingle(?object $bundle, ?object $params = null, bool $updateLink = true): object { $rawBundle = clone $bundle; if ($params->entity == 'DicomDevice') { $reqParams = (object) [ 'url' => $this->settings->url . 'fhir/Bundle/$import', 'headers' => [ 'Content-Type' => 'application/json', ], 'request_content' => $rawBundle, ]; } else { $reqParams = (object) [ 'url' => $this->settings->url . 'fhir/Bundle/$import', 'headers' => [ 'Content-Type' => 'application/cms', ], 'request_content' => $rawBundle, ]; } if ($params->entity !== 'DicomDevice') { $historyId = $this->history( StatusEnum::PENDING, HistoryActionTypeEnum::REGISTRATION, request: $reqParams ); } if ($params->entity == 'DicomDevice') { $reqParams->request_content = json_encode($bundle); } else { $reqParams->request_content = $this->encodeAndSign($bundle); } $result = self::doHttpMethodWithAuth($this->settings, $reqParams, 'POST', false); $resourceId = self::extractParameter($result, 'ResourceId'); if ($params->entity !== 'DicomDevice') { $this->history( $resourceId ? StatusEnum::PENDING : StatusEnum::FAILED, response: $result, historyId: $historyId ); } if (!$updateLink) { return $resourceId ? $result : (object) [ 'error' => self::extractErrors($result), 'details' => $result, 'bundle' => $rawBundle, ]; } if ($resourceId && $params->entity === 'DicomDevice') { self::updateCiszLink($resourceId, $params); return $result; } elseif ($resourceId) { self::updateCiszLink($resourceId, $params, $historyId); return $result; } return (object) [ 'error' => self::extractErrors($result), 'details' => $result, 'bundle' => $rawBundle, ]; } public function checkBundleStatus(?object $params = null): object { if (!$params) { throw new Exception( sprintf(med_cisz_constant::ERROR_INVALID_CREATE_BUNDLE_PARAMS_TEXT, 'params'), med_cisz_constant::ERROR_INVALID_CREATE_BUNDLE_PARAMS_CODE ); } $this->entity = $params->entity ?? null; if (($this->visitPatientId = $params->visitPatientId ?? null)) { if ($params->entity == 'MedLogStudy' || $params->entity == 'MedLogStudyImage') { $this->loadStudyPatient(); } elseif ($params->entity == 'MedInspect') { $this->loadMedInspect(false, $params->isInspect ?? false); } elseif ($params->entity == 'MedLogStudyLab') { $this->loadLabStudyPatient(); } elseif ($params->entity == 'MedDayHospital') { $this->loadDayHospital(true); } elseif ($params->entity == 'MedAmbulOperation') { $this->loadMedAmbulOperation(); } elseif ($params->entity == 'MedLogSend') { $this->loadMedLogSend(); } elseif ($params->entity == 'MedMedication') { $this->loadMedication(null, $this->visitPatientId); } elseif ($params->entity == 'TemporaryDisability') { $this->loadTemporaryDisability($this->visitPatientId); } elseif ($params->entity == 'MedProcedure') { $this->entity = 'MedProcedure'; $this->loadProcProcedure(); } elseif ($params->entity == 'MedStatCard') { $this->loadVisitPatientStat(); } elseif ($params->entity == 'MedLogHospital') { $this->loadHospitalisationLog(); } elseif ($params->entity == 'MedProcStat') { $this->loadProcStat(); } elseif ($params->entity == 'MedRadioIzotopStat') { $this->loadIzotopStat(); } elseif ($params->entity == 'MedDeviceHosp') { $this->loadStatDevice(); $params->entity = 'DeviceRequestStat'; } elseif ($params->entity == 'MedMedicationHosp') { $this->loadStatMedication(); $params->entity = 'MedicationRequestStat'; } elseif ($params->entity == 'StomVisit') { $this->loadVisitPatientStom(); } elseif ($params->entity == 'MedTherapyStom') { $this->loadProcStom(); } elseif ($params->entity == 'MedRadioIzotopStom') { $this->loadIzotopStom(); } elseif ($params->entity == 'MedVaccination') { $this->loadVaccination(); } elseif ($params->entity == 'MedHospitalRequest') { $this->loadHospitalisationRequest(); } elseif ($params->entity == 'MedXRayStat') { $this->loadXRayStat(); } elseif ($params->entity === 'MedLog') { $registrator = new med_cisz_entityHandlers_registrator(); $handler = $registrator->get($params->entity); $this->patientId = $handler::loadPatientId($this->db, (object)['primaryKey' => $params->visitPatientId]); } elseif ($params->entity !== 'DicomDevice') { $this->loadVisitPatient(); } } if (!$this->patientId) { $this->patientId = $params->patientId ?? null; } $this->createOrganization(); if ($params->entity !== 'DicomDevice') { $this->createPatient(); } if ($params->entity == 'MedLogStudy' || $params->entity == 'MedLogStudyLab' || $params->entity == 'MedLogStudyImage' || $params->entity == 'MedRadioIzotopStat' || $params->entity == 'MedRadioIzotopStom') { $uuid = self::getLinkEntityStudyUUID($this->db, 2, $params->entity, $params->visitPatientId ?? $params->patientId); } else { $uuid = self::getLinkEntityUUID($this->db, 2, $params->entity, $params->visitPatientId ?? $params->patientId); } if (!$uuid) { throw new Exception( med_cisz_constant::ERROR_LINK_ENTITY_NOT_FOUND_TEXT, med_cisz_constant::ERROR_LINK_ENTITY_NOT_FOUND_CODE ); } $reqParams = (object) [ 'url' => $this->settings->url . 'fhir/Bundle/' . $uuid . '/$status', ]; if ($params->entity !== 'DicomDevice') { $historyId = $this->history( StatusEnum::PENDING, HistoryActionTypeEnum::CHECK_STATUS, request: $reqParams, bundleId: $uuid ); } $result = self::doHttpMethodWithAuth($this->settings, $reqParams); $error = null; $status = self::extractParameter($result, 'ProcessingStatus'); if ($status === StatusEnum::FAILED->name()) { $error = self::extractErrors(self::extractParameter($result, 'StatusDescription', false)->resource); } if ($status === 'Successed' && $params->entity !== 'DicomDevice' && $params->entity !== 'MedLog') { self::checkPatientUuid($this->patientId); } if ($params->entity !== 'DicomDevice') { $this->history( StatusEnum::fromString($status), response: $result, historyId: $historyId, bundleId: $uuid ); } return (object) [ 'status' => $status, 'details' => $result, 'error' => $error, ]; } public function getPatientInfo(?object $params = null): object { if (!$params) { throw new Exception( sprintf(med_cisz_constant::ERROR_INVALID_CREATE_BUNDLE_PARAMS_TEXT, 'params'), med_cisz_constant::ERROR_INVALID_CREATE_BUNDLE_PARAMS_CODE ); } $this->patientId = $params->patientId ?? null; $this->createOrganization(); if (!empty($params->patientUuid)) { $patientUuid = $params->patientUuid; } else { $patientUuid = self::getLinkEntityUUID($this->db, 1, 'MedPatient', $params->patientId); $this->createPatient(); } if (!$patientUuid) { self::checkPatientUuid($this->patientId); $patientUuid = self::getLinkEntityUUID($this->db, 1, 'MedPatient', $params->patientId); if (!$patientUuid) { throw new Exception( med_cisz_constant::ERROR_LINK_DATA_NOT_FOUND_TEXT, med_cisz_constant::ERROR_LINK_DATA_NOT_FOUND_CODE ); } } $ciszData = getSessionValue('cisz') ?? (object) []; $dateStart = new DateTime(); $dateEnd = !empty($params->finishDate) ? (new DateTime($params->finishDate))->format('Y-m-d') : $dateStart->format('Y-m-d'); $dateStart = !empty($params->startDate) ? (new DateTime($params->startDate))->format('Y-m-d') : $dateStart->sub(new DateInterval('P88D'))->format('Y-m-d'); try { $result = self::doHttpMethodWithAuth($this->settings, (object) [ 'url' => $this->settings->url . 'fhir/Patient/' . $patientUuid . '/$everything', 'param' => [ 'start' => $dateStart, 'end' => $dateEnd, ] ]); } catch (Exception $e) { if (strpos($e->getMessage(), '404') !== false || strpos($e->getMessage(), 'Not Found') !== false || $e->getCode() == med_cisz_constant::ERROR_RESPONSE_STATUS_CODE) { throw new Exception( 'Невозможно получить информацию. Пациент не зарегистрирован в ЦИСЗ', med_cisz_constant::ERROR_LINK_DATA_NOT_FOUND_CODE ); } throw $e; } $result = (object) [ 'patient' => $result, ]; { foreach ($result->patient->entry ?? [] as $entry) { $resource = $entry->resource ?? null; if (($resource->resourceType ?? false) != 'List') { continue; } foreach ($resource->entry ?? [] as $index => $entryList) { if (($reference = $entryList->item->reference ?? false)) { $value = ($resource->identifier[0]->value ?? (explode('/', $entryList->item->reference ?? '')[2] ?? '')) . '_' . ($index + 1); $data = self::doHttpMethodWithAuth($this->settings, (object) [ 'url' => $this->settings->url . 'fhir/' . $reference, ]); $result->{$value} = $data; } } } } $doProcess = isEmptyProperty($params, 'doProcess'); if ($doProcess && $result) { $patientInfo = new med_cisz_patientInfo(); $result = $patientInfo->transformPatientData($result, $dateStart, $dateEnd); } return $result; } private function createBundleBody(string $id,?string $entity = null): void { if (!isset($entity)){ $entity = 'General'; }; $values = [ 'MedHospitalLog' => (object)[ 'metaDefine' => 'BundleHospitalisation', 'identifierDefine' => 'https://minzdrav.gov.by', 'identifierValue' => null, ], 'General' => (object)[ 'metaDefine' => 'MedicationDocument', 'identifierDefine' => 'urn:ietf:rfc:3986', 'identifierValue' => 'urn:uuid:' . generateUUID(null, null, true), ] ]; $this->bundle = (object) [ 'resourceType' => 'Bundle', 'id' => $id, 'meta' => (object) [ 'profile' => [med_cisz_constant::$structureDefinitions['MedicationDocument']] ], 'identifier' => (object) [ 'system' => 'urn:ietf:rfc:3986', 'value' => 'urn:uuid:' . generateUUID(null, null, true) ], 'type' => 'document', 'timestamp' => date('c'), 'entry' => self::niceArray(array_merge( [ $this->composition ?? null, $this->patient->profile ?? null, ($this->encounter->raw ?? false) ? $this->encounter->profile : null, $this->serviceRequest->profile ?? null, $this->procedure->profile ?? null, $this->funcDiagObservation->profile ?? null, $this->diagnosticReport->profile ?? null, $this->diagnosticReportSecond->profile ?? null, $this->funcDiagProcedure->profile ?? null, $this->contract->profile ?? null, $this->episodeOfCare->profile ?? null, $this->specimen->profile ?? null, $this->adverseEvent->profile ?? null, $this->carePlan->profile ?? null ], $this->conditions ?? [], $this->encounterVKK ?? [], $this->deviceRequest ?? [], $this->device ?? [], $this->deviceDispense ?? [], $this->observations ?? [], $this->relatedPersons ?? [], $this->questionnaireResponses ?? [], $this->familyMemberHistory ?? [], $this->documentReference ?? [], $this->prescriptionList ?? [], $this->carePlanList ?? [], $this->allergyAnamnesis ?? [], $this->medicationOrder ?? [], $this->medicationCancelOrder ?? [], $this->placeOfCare ?? [], $this->requests ?? [], $this->temporaryDisabilityTrait ?? [], $this->temporaryDisabilityFlags ?? [], is_array($this->procedure) ? $this->procedure : [], $this->specimens ?? [], $this->diagnosticReports ?? [], $this->vaccination ?? [], $this->vaccinationRecommendation ?? [], $this->addEncounter ?? [] )), ]; self::cleanEntity($this->bundle); } private function createDicomDeviceBody(string $id,?string $entity = null): void { $type = 'transaction'; $system = 'https://fhir.by/AbstractArea/StructureDefinition/Bundle/OrganizationBundle'; $this->bundle = (object) [ 'resourceType' => 'Bundle', 'id' => $id, 'meta' => (object) [ 'profile' => [$system] ], 'identifier' => ($this->entity === 'DicomDevice') ? null : (object) [ 'system' => 'urn:ietf:rfc:3986', 'value' => 'urn:uuid:' . generateUUID(null, null, true) ], 'type' => $type, 'timestamp' => date('c'), 'entry' => self::niceArray(array_merge( $this->dicomDevice ?? [], )), ]; if ($this->entity === 'DicomDevice') { if (isset($this->organization) && isset($this->organization->profile)) { $orgEntry = (object) [ 'fullUrl' => 'Organization/' . ($this->organization->id ?? 'org-' . uniqid()), 'resource' => $this->organization->profile, 'request' => (object) [ 'method' => 'POST', 'url' => 'Organization' ] ]; array_unshift($this->bundle->entry, $orgEntry); } foreach ($this->bundle->entry as &$entry) { if (isset($entry->resource) && $entry->resource->resourceType === 'Device') { $entry->request = (object) [ 'method' => 'POST', 'url' => 'Device' ]; } } } self::cleanEntity($this->bundle); } private function setupBundleInfo(string $id,object $params): void { $db = $this->db ?: $this->db = connectDb(); $this->entity = isset($params->entity) ? $params->entity : null; $this->visitPatientId = $params->visitPatientId ?? null; if (empty($this->patientId)) { $this->patientId = $params->patientId ?? null; } $this->dirTime = $params->dirTime ?? null; if (is_string(($mapMedDoctor = getSessionValue('mapMedDoctor')))) { $mapMedDoctor = json_decode($mapMedDoctor, true); } $this->doctorId = $mapMedDoctor['MedDoctorCode'] ?? null; if (!$this->visitPatientId && !$this->patientId) { throw new Exception( sprintf(med_cisz_constant::ERROR_INVALID_CREATE_BUNDLE_PARAMS_TEXT, 'visitPatientId или patientId'), med_cisz_constant::ERROR_INVALID_CREATE_BUNDLE_PARAMS_CODE ); } if ($this->patientId && !$this->doctorId && $this->entity !== 'DicomDevice') { throw new Exception( sprintf(med_cisz_constant::ERROR_INVALID_CREATE_BUNDLE_PARAMS_TEXT, 'doctorId'), med_cisz_constant::ERROR_INVALID_CREATE_BUNDLE_PARAMS_CODE ); } if ($this->visitPatientId) { switch ($this->entity) { case 'MedStatCard': $this->loadVisitPatientStat(); break; case 'StomVisit': $this->loadVisitPatientStom(); break; case 'MedLogStudy': case 'MedLogStudyImage': $this->loadStudyPatient(); break; case 'MedVisitPatient': $this->loadVisitPatient(); break; case 'MedInspect': $this->loadMedInspect(false, $params->isInspect ?? false); break; case 'MedHospitalRequest': $this->loadHospitalisationRequest(); break; case 'MedLogHospital': $this->loadHospitalisationLog(); break; case 'MedLogSend': $this->loadMedLogSend(); break; case 'MedDayHospital': $this->loadDayHospital(); break; case 'TemporaryDisability': $this->loadTemporaryDisability(); break; case 'MedLogStudyLab': $this->loadLabStudyPatient(); break; case 'MedAmbulOperation': $this->loadMedAmbulOperation(); break; case 'MedVaccination': $this->loadVaccination(); break; case 'MedProcedure': $this->loadProcProcedure(); break; case 'MedProcStat': $this->loadProcStat(); break; case 'MedXRayStat': $this->loadXRayStat(); break; case 'MedRadioIzotopStat': $this->loadIzotopStat(); break; case 'MedDeviceHosp': $this->loadStatDevice(); break; case 'MedMedicationHosp': $this->loadStatMedication(); break; case 'MedTherapyStom': $this->loadProcStom(); break; case 'MedRadioIzotopStom': $this->loadIzotopStom(); break; } } $this->createOrganization(); if ($this->entity !== 'DicomDevice') { $this->createPatient(); $this->getAdditionalPatientInfo(); } $this->createPractitioner(); if ($this->entity !== 'DicomDevice') { self::checkPatientUuid($this->patientId); } if ($this->entity !== 'MedPatient' && $this->entity !== 'DicomDevice') { $status = selectSqlValue($db, <<<SQL
            SELECT
                status
            FROM
                CiszLink
            WHERE
                TableName = :entity AND PrimaryKey = :patientId
        SQL,
[ ':entity' => 'MedPatient', ':patientId' => $this->patientId, ] ); if (!$status) { throw new Exception( med_cisz_constant::$globalError['notRegisterPatient']['text'], med_cisz_constant::$globalError['notRegisterPatient']['code'] ); } } foreach ($this->patient->raw->relatives ?? [] as $relative) { if ($relative->diagnosisId ?? false) { $relatives = $relative; } } switch ($this->entity) { case 'MedPatient': $this->createPlaceOfCare(); $this->createRelatedPersons(); if (isset($relatives)) { $this->createFamilyMemberHistory($relatives); } $this->createComposition($id); break; case 'MedStatCard': $this->createEncounter(); $this->createRelatedPersons();; $this->createObservations(); $this->createQuestionnaireResponses(); $this->createMedicationOrder(); $this->createCancelMedicationOrder(); $this->createAllergyIntolerance(); $this->createEpisodeOfTemporaryDisability(); if (self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['Направление группа'])) || self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['Направление_группа']))) { if ($sends = safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['SendObj']))) { if (isset($sends->id) && isset($sends->profile)) { $srUuid = self::getPatientResource( $sends->id, self::changeDateMonths($this->visitPatient[array_key_first($this->visitPatient)]->visitDate,-2), self::changeDateMonths($this->visitPatient[array_key_first($this->visitPatient)]->visitDate,0), med_cisz_constant::$structureDefinitions[$sends->profile] ); if (isset($srUuid)) { $this->encounter->profile->resource->basedOn = [ (object)[ 'reference' => 'ServiceRequest/' . $srUuid ] ]; } } } } if (self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['Консультации группа'])) || self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['Консультации_группа']))) { if ($cons = safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['ConsObj']))) { $tmp = $this->visitPatientId; foreach ($cons as $con) { if (isset($con->id)) { $this->visitPatientId = $con->id; $this->loadMedLogSend(); $this->createServiceRequest('MedLogSend', true); } } $this->visitPatientId = $tmp; $this->loadVisitPatientStat(); } } if (self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['NSHG']))) { if ($consHosp = safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['NSHGTX1']))) { $tmp = $this->visitPatientId; if (isset($consHosp->id)) { $this->visitPatientId = $consHosp->id; $this->loadHospitalisationRequest(); $this->createServiceRequest('MedHospitalRequest', true); } $this->visitPatientId = $tmp; $this->loadVisitPatientStat(); } } if (self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['MAOJ']))) { $ambulOperation = safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData,['selectedIdsOperation'])); if (isset($ambulOperation->selectedIdsOperation)) { $tmp = $this->visitPatientId; if (is_numeric($ambulOperation->selectedIdsOperation)) { $this->visitPatientId = $ambulOperation->selectedIdsOperation; $this->loadMedStatOperation(); $this->createProcedure('MedStatOperation'); $this->createAdverseEvent('MedStatOperation'); } $this->visitPatientId = $tmp; $this->loadVisitPatientStat(); } } if (self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['Обследования']))) { if ($consRequest = safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['LBS1TX1']))) { $tmp = $this->visitPatientId; if (isset($consRequest->id)) { $this->visitPatientId = (int)$consRequest->id; $this->loadLabStudyPatient(); $this->createSpecimen('MedLogStudyLab'); $this->createServiceRequest('MedLogStudyLab', true); $this->createDiagReport('MedLogStudyLab'); $this->visitPatientId = $tmp; $this->loadVisitPatientStat(); } } } if (self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['Обследования_функциональные']))) { if ($consRequest = safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['FNS1TX1']))) { $tmp = $this->visitPatientId; if (isset($consRequest->id)) { $this->visitPatientId = (int)$consRequest->id; $this->loadStudyPatient(); $this->createServiceRequest('MedLogStudy', true); $this->createProcedure('MedLogStudy'); $this->createObservations('MedLogStudy'); $this->createDiagReport('MedLogStudy'); $this->visitPatientId = $tmp; $this->loadVisitPatientStat(); } } } if (self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['Обследования_лучевые']))) { if ($consRequest = safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['XRS1TX1']))) { $tmp = $this->visitPatientId; if (isset($consRequest->id)) { $this->visitPatientId = (int)$consRequest->id; $this->loadStudyPatient(); $this->createServiceRequest('MedLogStudyImage', true); $this->createObservations('MedLogStudyImage'); $this->createDiagReport('MedLogStudyImage'); $this->visitPatientId = $tmp; $this->loadVisitPatientStat(); } } } $this->createComposition($id); break; case 'StomVisit': $this->createEncounter(); $this->createRelatedPersons(); if (isset($relatives)) { $this->createFamilyMemberHistory($relatives); } $this->createObservations(); $this->createQuestionnaireResponses(); $this->createMedicationOrder(); $this->createCancelMedicationOrder(); $this->createAllergyIntolerance(); $this->createEpisodeOfTemporaryDisability(); $this->createDeviceOrder(); if (self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['Направление группа'])) || self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['Направление_группа']))) { if ($sends = safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['SendObj']))) { if (isset($sends->id) && isset($sends->profile)) { $srUuid = self::getPatientResource( $sends->id, self::changeDateMonths($this->visitPatient[array_key_first($this->visitPatient)]->visitDate,-2), self::changeDateMonths($this->visitPatient[array_key_first($this->visitPatient)]->visitDate,0), med_cisz_constant::$structureDefinitions[$sends->profile] ); if (isset($srUuid)) { $this->encounter->profile->resource->basedOn = [ (object)[ 'reference' => 'ServiceRequest/' . $srUuid ] ]; } } } } if (self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['Консультации группа'])) || self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['Консультации_группа']))) { if ($cons = safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['ConsObj']))) { $tmp = $this->visitPatientId; foreach ($cons as $con) { if (isset($con->id)) { $this->visitPatientId = $con->id; $this->loadMedLogSend(); $this->createServiceRequest('MedLogSend', true); } } $this->visitPatientId = $tmp; $this->loadVisitPatientStom(); } } if (self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['OVTBIMN']))) { $data = (object)[]; $device = (object)[]; $data->serialNumber = (string) safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData,['DeviceSerial'])); $data->model = self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData,['DeviceModel']); $data->productionDate = self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData,['dateManufactured']); $device->medicationProduct = safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData,['deviceObj'])); $device->medicationProduct->deviceName = $device->medicationProduct->nomenclatureGroup; self::createDeviceForPatient($data, $device); } if (self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['MAOJ']))) { $ambulOperation = safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData,['selectedIdsOperation'])); if (isset($ambulOperation->id)) { $tmp = $this->visitPatientId; if (is_numeric($ambulOperation->id)) { $this->visitPatientId = $ambulOperation->id; $this->loadMedAmbulOperation(); $this->createProcedure('MedAmbulOperation'); $this->createAdverseEvent('MedAmbulOperation'); } $this->visitPatientId = $tmp; $this->loadVisitPatientStom(); } } if (self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['Обследования']))) { if ($consRequest = safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['LBS1TX1']))) { $tmp = $this->visitPatientId; if (isset($consRequest->id)) { $this->visitPatientId = (int)$consRequest->id; $this->loadLabStudyPatient(); $this->createSpecimen('MedLogStudyLab'); $this->createServiceRequest('MedLogStudyLab', true); $this->createDiagReport('MedLogStudyLab'); $this->visitPatientId = $tmp; $this->loadVisitPatientStom(); } } } if (self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['NSHG']))) { if ($consHosp = safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['NSHGTX1']))) { $tmp = $this->visitPatientId; if (isset($consHosp->id)) { $this->visitPatientId = $consHosp->id; $this->loadHospitalisationRequest(); $this->createServiceRequest('MedHospitalRequest', true); } $this->visitPatientId = $tmp; $this->loadVisitPatientStom(); } } if (self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['Обследования_лучевые']))) { if ($consRequest = safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['XRS1TX1']))) { $tmp = $this->visitPatientId; if (isset($consRequest->id)) { $this->visitPatientId = (int)$consRequest->id; $this->loadStudyPatient(); $this->createServiceRequest('MedLogStudyImage', true); $this->createObservations('MedLogStudyImage'); $this->createDiagReport('MedLogStudyImage'); $this->visitPatientId = $tmp; $this->loadVisitPatientStom(); } } } if (self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['Обследования_функциональные']))) { if ($consRequest = safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['FNS1TX1']))) { $tmp = $this->visitPatientId; if (isset($consRequest->id)) { $this->visitPatientId = (int)$consRequest->id; $this->loadStudyPatient(); $this->createServiceRequest('MedLogStudy', true); $this->createProcedure('MedLogStudy'); $this->createObservations('MedLogStudy'); $this->createDiagReport('MedLogStudy'); $this->visitPatientId = $tmp; $this->loadVisitPatientStom(); } } } $this->createComposition($id); break; case 'MedLogStudy': $this->createServiceRequest($this->entity); $this->createProcedure($params->entity); $this->createObservations($params->entity); $this->createDiagReport($params->entity); $this->createComposition($id); break; case 'MedVisitPatient': $this->createRelatedPersons(); $this->createEncounter(); if (self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['Направление группа'])) || self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['Направление_группа']))) { if ($sends = safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['SendObj']))) { if (isset($sends->id) && isset($sends->profile)) { $srUuid = self::getPatientResource( $sends->id, self::changeDateMonths($this->visitPatient[array_key_first($this->visitPatient)]->visitDate,-2), self::changeDateMonths($this->visitPatient[array_key_first($this->visitPatient)]->visitDate,0), med_cisz_constant::$structureDefinitions[$sends->profile] ); if (isset($srUuid)) { $this->encounter->profile->resource->basedOn = [ (object)[ 'reference' => 'ServiceRequest/' . $srUuid ] ]; } } } } if (self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['Консультации группа'])) || self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['Консультации_группа']))) { if ($cons = safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['ConsObj']))) { $tmp = $this->visitPatientId; foreach ($cons as $con) { if (isset($con->id)) { $this->visitPatientId = $con->id; $this->loadMedLogSend(); $this->createServiceRequest('MedLogSend', true); } } $this->visitPatientId = $tmp; $this->loadVisitPatient(); } } if (self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['NSHG']))) { if ($consHosp = safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['NSHGTX1']))) { $tmp = $this->visitPatientId; if (isset($consHosp->id)) { $this->visitPatientId = $consHosp->id; $this->loadHospitalisationRequest(); $this->createServiceRequest('MedHospitalRequest', true); } $this->visitPatientId = $tmp; $this->loadVisitPatient(); } } if (self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['MAOJ']))) { if ($ambulOperation = safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData,['selectedIdsOperation']))) { $tmp = $this->visitPatientId; if (is_numeric($ambulOperation)) { $this->visitPatientId = $ambulOperation; $this->loadMedAmbulOperation(); $this->createProcedure('MedAmbulOperation'); $this->createAdverseEvent('MedAmbulOperation'); } $this->visitPatientId = $tmp; $this->loadVisitPatient(); } } if ($consRequest = safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['ResearchObj']))) { $tmp = $this->visitPatientId; if (isset($consRequest->code)) { $this->visitPatientId = (int)$consRequest->code; $typeStudy = $this->getTypeStudy($this->visitPatientId); switch ($typeStudy) { case 1: $this->loadLabStudyPatient(); $this->createSpecimen('MedLogStudyLab'); $this->createServiceRequest('MedLogStudyLab'); $this->createDiagReport('MedLogStudyLab'); break; case 2: $this->loadStudyPatient(); $this->createServiceRequest('MedLogStudyImage'); $this->createObservations('MedLogStudyImage'); $this->createDiagReport('MedLogStudyImage'); break; case 3: $this->loadStudyPatient(); $this->createServiceRequest('MedLogStudy'); break; } } $this->visitPatientId = $tmp; $this->loadVisitPatient(); } if ($disp = safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['inspectObj']))) { $tmp = $this->visitPatientId; if (isset($disp->code)) { $this->visitPatientId = selectSqlValue($this->db, <<<SQL
                            SELECT
                                MVD.MedVisitPatientCode
                            FROM
                                MedVisitDocument MVD
                            WHERE
                                MVD.MedInspectCode = :mic
                            SQL,
[ ':mic' => $disp->code ], PDO::FETCH_OBJ ); $this->loadMedInspect(true); if (isset($relatives)) { $this->createFamilyMemberHistory($relatives); } $this->createCarePlan(true); } $this->visitPatientId = $tmp; $this->loadVisitPatient(); } $this->createObservations(); $this->createQuestionnaireResponses(); $this->createComposition($id); $this->createMedicationOrder(); $this->createCancelMedicationOrder(); $this->createAllergyIntolerance(); $this->createEpisodeOfTemporaryDisability(); if (self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['Направление на процедуры']))) { $this->loadProcProcedure(); $this->createServiceRequest('MedProcedure'); $this->createPhysioProcedure('MedProcedure'); } $this->createDeviceOrder(); if (self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['GHG']))) { $recommendation = safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['GTX1']), JSON_OBJECT_AS_ARRAY)['code']; if ($recommendation) { $this->createVaccinationRecommendation(); } } break; case 'MedInspect': $visit = $this->visitPatient[array_key_first($this->visitPatient ?? [])] ?? $this->inspect[array_key_first($this->inspect)]; if (!isset($visit->diagnosisId)) { if ($this->hasActivityCode($visit->schemeCode, 'ad2')) { $cipherCode = 'Z00.0'; } else { $cipherCode = 'Z00.1'; } $selectDiagn = selectSql($this->db, <<<SQL
                SELECT
                    MedDiagnosisCode,
                    Cipher1
                FROM
                    MedDiagnosis
                WHERE
                    Cipher1 = ?
                LIMIT 1
                SQL,
[$cipherCode], PDO::FETCH_OBJ ); if (!empty($this->visitPatient)) { $this->visitPatient[array_key_first($this->visitPatient)]->diagnosisId = $selectDiagn[0]->meddiagnosiscode ?? null; $this->visitPatient[array_key_first($this->visitPatient)]->diagnosisCipher = $selectDiagn[0]->cipher1 ?? null; } } if (!$this->encounter) { $this->createEncounter(false); } if ($this->visitPatient[array_key_first($this->visitPatient)]->visitPatientId > 0) { if (self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['Консультации группа'])) || self::normalizeStrictBool(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['Консультации_группа']))) { if ($cons = safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['ConsObj']))) { $tmp = $this->visitPatientId; foreach ($cons as $con) { if (isset($con->id)) { $this->visitPatientId = $con->id; $this->loadMedLogSend(); $this->createServiceRequest('MedLogSend', true); } } $this->visitPatientId = $tmp; $this->loadMedInspect(); } } } if (isset($relatives)) { $this->createFamilyMemberHistory($relatives); } $this->createObservations('MedInspect'); $this->createCarePlan(!is_null($this->visitPatient[array_key_first($this->visitPatient)]->Inspectdate ?? null)); if (isset($this->requests[0])) { $this->requests[0]->resource->encounter = $this->encounter->link; if (isset($this->functDiag['serviceRequest']->object->profile->resource->reason[0]->reference)) { $this->requests[0]->resource->reason[0]->reference = $this->functDiag['serviceRequest']->object->profile->resource->reason[0]->reference; } } $this->createComposition($id); break; case 'MedHospitalRequest': $this->createServiceRequest($this->entity); $this->createComposition($id); break; case 'MedLogHospital': $this->createEpisodeOfCare($this->entity); $this->createComposition($id); break; case 'DicomDevice': $this->createDicomDevice($this->visitPatientId); break; case 'MedLogSend': $this->createServiceRequest($this->entity); $this->createComposition($id); break; case 'MedDayHospital': $this->createEpisodeOfCare($this->entity); $this->createComposition($id); break; case 'TemporaryDisability': $this->createEpisodeOfTemporaryDisability($this->entity); $this->createComposition($id); break; case 'MedLogStudyLab': $this->createSpecimen($this->entity); $this->createServiceRequest($this->entity); $this->createDiagReport($this->entity); $this->createComposition($id); break; case 'MedAmbulOperation': $this->createProcedure($params->entity); $this->createAdverseEvent($params->entity); $this->createComposition($id); break; case 'MedLogStudyImage': $type = self::checkStudyType(); if ($type === 'DiagnosticImagingStudy') { $this->createServiceRequest('DiagnosticImagingStudy'); if (self::normalizeStrictBool(self::getHtmDataValue($this->funcDiagnostic[array_key_first($this->funcDiagnostic)]->funcHtmData, ['VIDPHG1']))) { $this->createImagingStudy('DiagnosticImagingStudy'); } $this->createDiagReport('DiagnosticImagingStudy'); } else { $this->createServiceRequest($params->entity); $this->createObservations($params->entity); $this->createDiagReport($params->entity); } $this->createComposition($id); break; case 'MedVaccination': $this->createVaccination(); $this->createComposition($id); break; case 'MedVaccinationRecommendation': $this->createVaccinationRecommendation(); $this->createComposition($id); break; case 'MedMedication': $this->createMedicationOrder(); $this->createCancelMedicationOrder(); $this->createComposition($id); break; case 'MedProcedure': $this->createServiceRequest('MedProcedure'); $this->createPhysioProcedure('MedProcedure'); $this->createComposition($id); break; case 'MedMedicalDevice': $this->createDeviceOrder(); $this->createComposition($id); break; case 'MedProcStat': $this->createServiceRequest('MedProcStat'); $this->createPhysioProcedureStat('MedProcStat'); $this->createComposition($id); break; case 'MedXRayStat': $this->createComposition($id); $this->createServiceRequest('MedXRayStat'); $this->createProcedure('MedXRayStat'); $this->createXRayCarePlan(); break; case 'MedRadioIzotopStat': $this->createServiceRequest('MedRadioIzotopStat'); $this->createDiagReport('MedRadioIzotopStat'); $this->createComposition($id); break; case 'MedDeviceHosp': $this->createDeviceOrderStat(); $this->createComposition($id); break; case 'MedMedicationHosp': $this->createMedicationOrderStat(null); $this->createComposition($id); break; case 'MedTherapyStom': $this->createServiceRequest('MedTherapyStom'); $this->createPhysioProcedureStat('MedTherapyStom'); $this->createComposition($id); break; case 'MedRadioIzotopStom': $this->entity = 'StomVisit'; $this->loadVisitPatientStom($params->visitPatientId); $this->createEncounter(false); $this->entity = 'MedRadioIzotopStom'; $this->loadIzotopStom(); $this->createServiceRequest('MedRadioIzotopStom'); $this->createDiagReport('MedRadioIzotopStom'); $this->createComposition($id); break; } } private function createComposition(string $bundleId,?string $entity = null): void { $title = 'Посещение пациента'; if (!$this->visitPatientId) { $title = 'Сведения о пациенте'; } $this->composition = (object) [ 'fullUrl' => 'Composition/' . $bundleId, 'resource' => (object) [ 'resourceType' => 'Composition', 'id' => $bundleId, 'meta' => (object) [ 'profile' => [med_cisz_constant::$structureDefinitions['CompDocument']] ], 'status' => 'final', 'type' => self::getCodingStructure(med_cisz_constant::$valueSet['CompositionType'], 'general'), 'subject' => [$this->patient->link], 'date' => date('c'), 'author' => [$this->practitioner->link], 'title' => $title, 'custodian' => $this->organization->link, ], ]; } private function loadStatMedication($allergyId = null, $medicationId = null): void { if ($allergyId) { $searchField = 'MP.MedAllergyCode'; $searchValue = $allergyId; } elseif ($medicationId) { $searchField = 'MP.MedPurposeCode'; $searchValue = $medicationId; } else { $searchField = 'MP.MedPurposeCode'; $searchValue = $this->visitPatientId; } $this->medication = selectSql($this->db, <<<SQL
            SELECT
                MP.MedPurposeCode "id",
                MP.MedPurposeDepartmentCode "purposeDepartmentCode",
                MPD.MedStatCardCode "statCardId",
                MSC.MedPatientCode "patientId",
                MP.MedAllergyCode "allergyId",
                MSCD.MedDiagnosisCode "diagnosisId",
                MD.Cipher1 "diagnosisCipher",
                MPD.MedDoctorCode "doctorId",
                MP.Amount "dose",
                CRVM.Code "doseCode",
                CRVM.Name "doseUnit",
                MP.PurposeTime "purposeTime",
                MP.CancelTime "cancelTime",
                MP.MedPurposeMethodCode "methodId",
                MP.Note "note",
                MP.CreateTime "createTime",
                MP.MedDoctorCodeCancel "doctorIdCancel",
                MP.CiszResourceCodeCancelCause AS "cancelCauseId",
                CRVСANCEL.Code "rejectCode",
                CRVСANCEL.Name "rejectName",
                MP.CiszResourceCodeCategory "categoryId",
                CRVС.Code "categoryCode",
                MP.Description "description",
                MP.Instruction "instruction",
                MP.CiszResourceCodeInjectionRoute "injectionRouteId",
                CRVR.Code "injectionRouteCode",
                MP.CiszResourceCodeInjectionRate "injectionRateId",
                CRVI.Code AS "injectionRateCode",
                CRVI.Name AS "injectionRateUnit",
                MP.InjectionRate "injectionRate",
                MP.Json AS "medicationJson",
                (MP.MedDoctorCodeCancel IS NOT NULL) AS "isCanceled",
                CPD.uuid
            FROM MedPurpose MP
                LEFT JOIN MedPurposeDepartment MPD ON MPD.MedPurposeDepartmentCode = MP.MedPurposeDepartmentCode
                LEFT JOIN MedStatCard MSC ON MSC.MedStatCardCode = MPD.MedStatCardCode
                LEFT JOIN MedStatCardDiagnosis MSCD ON MSCD.MedStatCardDiagnosisCode = MP.MedStatCardDiagnosisCode
                LEFT JOIN MedDiagnosis MD ON MD.MedDiagnosisCode = MSCD.MedDiagnosisCode
                LEFT JOIN CiszResourceValue CRVM ON CRVM.CiszResourceValueCode = MP.CiszResourceCodeDoseMeasure
                LEFT JOIN CiszResourceValue CRVСANCEL ON CRVСANCEL.CiszResourceValueCode = MP.CiszResourceCodeCancelCause
                LEFT JOIN CiszResourceValue CRVС ON CRVС.CiszResourceValueCode = MP.CiszResourceCodeCategory
                LEFT JOIN CiszResourceValue CRVR ON CRVR.CiszResourceValueCode = MP.CiszResourceCodeInjectionRoute
                LEFT JOIN CiszResourceValue CRVI ON CRVI.CiszResourceValueCode = MP.CiszResourceCodeInjectionRate
                LEFT JOIN CiszPatientDignosis CPD on CPD.MedPatientCode = MSC.MedPatientCode and CPD.DiagnosisCipher = MD.Cipher1
            WHERE {$searchField} = :searchValue
        SQL,
[ ':searchValue' => $searchValue ], PDO::FETCH_OBJ ); $this->patientId = $this->patientId ?? $this->medication[0]->patientId ?? null; if ($this->medication && isset($this->medication[0]->id) && $this->medication[0]->id) { $graphAccepts = selectSql($this->db, <<<SQL
            SELECT
                MDHPGA.MedGraphAcceptCode AS "graphAcceptCode",
                MGA.Amount AS "amount",
                MGA.AmountFrom AS "amountFrom",
                MGA.AmountTill AS "amountTill",
                MGA.AmountPeriod AS "amountPeriod",
                MGA.AmountPeriodTill AS "amountPeriodTill",
                MGA.AmountPeriodTimeUnit AS "amountPeriodTimeUnit",
                MGA.WeekDayMask AS "WeekDay",
                MGA.Duration AS "duration",
                MGA.DurationTill AS "durationTill",
                MGA.DurationTimeUnit AS "durationTimeUnit",
                MGA.Note AS "note",
                MGA.Description AS "description",
                MGA.Instruction AS "instruction"
            FROM MedPurposeGraphAccept MDHPGA
            LEFT JOIN MedGraphAccept MGA ON MGA.MedGraphAcceptCode = MDHPGA.MedGraphAcceptCode
            WHERE MDHPGA.MedPurposeCode = :medicationId
        SQL,
[ ':medicationId' => $this->medication[0]->id ], PDO::FETCH_OBJ ); if ($graphAccepts) { foreach ($graphAccepts as $graphAccept) { $graphAccept->times = selectSql($this->db, <<<SQL
                    SELECT
                        Hour AS "hour",
                        Minute AS "minute"
                    FROM MedGraphAcceptTime
                    WHERE MedGraphAcceptCode = :graphAcceptCode
                SQL,
[ ':graphAcceptCode' => $graphAccept->graphAcceptCode ], PDO::FETCH_OBJ ) ?: []; } $this->medication[0]->graphAccepts = $graphAccepts; } else { $this->medication[0]->graphAccepts = []; } $vitalSigns = selectSql($this->db, <<<SQL
            SELECT
                MDHPVS.MedPurposeVitalSignsCode AS "medicationId",
                MDHPVS.Type AS "type",
                MDHPVS.ValueNumber AS "valueNumber"
            FROM MedPurposeVitalSigns AS MDHPVS
            WHERE MDHPVS.MedPurposeVitalSignsCode = :medicationId
        SQL,
[ ':medicationId' => $this->medication[0]->id ], PDO::FETCH_OBJ); $this->medication[0]->vitalSigns = $vitalSigns ?: []; } else { $this->medication = []; } } private function loadMedication($allergyId = null, $medicationId = null): void { if ($allergyId) { $searchField = 'MDHP.MedAllergyCode'; $searchValue = $allergyId; } elseif ($medicationId) { $searchField = 'MDHP.MedDayHopsitalPurposeCode'; $searchValue = $medicationId; } else { $searchField = 'MDHP.MedDayHopsitalPurposeCode'; $searchValue = $this->visitPatientId; } $this->medication = selectSql($this->db, <<<SQL
        SELECT
            MDHP.MedDayHopsitalPurposeCode AS "id",
            MDHP.MedDayHospitalCode AS "hospitalCode",
            MDHP.MedPatientCode AS "patientId",
            MDHP.MedAllergyCode AS "allergyId",
            MDHP.MedDiagnosisCode AS "diagnosisId",
            MD.Cipher1 AS "diagnosisCipher",
            MDHP.MedDoctorCode AS "doctorId",
            MDHP.Dose AS "dose",
            CRVD.Code AS "doseCode",
            CRVD.Name AS "doseUnit",
            MDHP.PurposeTime AS "purposeTime",
            MDHP.CancelTime AS "cancelTime",
            MDHP.MedPurposeMethodCode AS "methodId",
            MDHP.Note AS "note",
            MDHP.Position AS "position",
            MDHP.CreateTime AS "createTime",
            MDHP.MedDoctorCodeCancel AS "doctorIdCancel",
            MDHP.CiszResourceCodeCancelCause AS "cancelCauseId",
            MDHP.CiszResourceCodeCategory AS "categoryId",
            CRVС.Code AS "categoryCode",
            MDHP.Description AS "description",
            MDHP.Instruction AS "instruction",
            MDHP.CiszResourceCodeInjectionRoute AS "injectionRouteId",
            CRVR.Code AS "injectionRouteCode",
            MDHP.CiszResourceCodeInjectionRate AS "injectionRateId",
            MDHP.InjectionRate AS "injectionRate",
            CRVI.Code AS "injectionRateCode",
            CRVI.Name AS "injectionRateUnit",
            MDHP.Json AS "medicationJson",
            (MDHP.MedDoctorCodeCancel IS NOT NULL) AS "isCanceled",
            CRVСANCEL.Code AS "rejectCode",
            CRVСANCEL.Name AS "rejectName"
        FROM MedDayHopsitalPurpose MDHP
            LEFT JOIN CiszResourceValue CRVR ON CRVR.CiszResourceValueCode = MDHP.CiszResourceCodeInjectionRoute
            LEFT JOIN CiszResourceValue CRVI ON CRVI.CiszResourceValueCode = MDHP.CiszResourceCodeInjectionRate
            LEFT JOIN CiszResourceValue CRVС ON CRVС.CiszResourceValueCode = MDHP.CiszResourceCodeCategory
            LEFT JOIN CiszResourceValue CRVD ON CRVD.CiszResourceValueCode = MDHP.CiszResourceCodeDoseMeasure
            LEFT JOIN CiszResourceValue CRVСANCEL ON CRVСANCEL.CiszResourceValueCode = MDHP.CiszResourceCodeCancelCause
            LEFT JOIN MedDiagnosis MD ON MD.MedDiagnosisCode = MDHP.MedDiagnosisCode
        WHERE {$searchField} = :searchValue
    SQL,
[ ':searchValue' => $searchValue ], PDO::FETCH_OBJ ); if ($this->medication && isset($this->medication[0]->id) && $this->medication[0]->id) { $graphAccepts = selectSql($this->db, <<<SQL
            SELECT
                MDHPGA.MedGraphAcceptCode AS "graphAcceptCode",
                MGA.Amount AS "amount",
                MGA.AmountFrom AS "amountFrom",
                MGA.AmountTill AS "amountTill",
                MGA.AmountPeriod AS "amountPeriod",
                MGA.AmountPeriodTill AS "amountPeriodTill",
                MGA.AmountPeriodTimeUnit AS "amountPeriodTimeUnit",
                MGA.WeekDayMask AS "WeekDay",
                MGA.Duration AS "duration",
                MGA.DurationTill AS "durationTill",
                MGA.DurationTimeUnit AS "durationTimeUnit",
                MGA.Note AS "note",
                MGA.Description AS "description",
                MGA.Instruction AS "instruction"
            FROM meddayhopsitalpurposegraphaccept MDHPGA
            LEFT JOIN MedGraphAccept MGA ON MGA.MedGraphAcceptCode = MDHPGA.MedGraphAcceptCode
            WHERE MDHPGA.MedDayHopsitalPurposeCode = :medicationId
        SQL,
[ ':medicationId' => $this->medication[0]->id ], PDO::FETCH_OBJ ); if ($graphAccepts) { foreach ($graphAccepts as $graphAccept) { $graphAccept->times = selectSql($this->db, <<<SQL
                    SELECT
                        Hour AS "hour",
                        Minute AS "minute"
                    FROM MedGraphAcceptTime
                    WHERE MedGraphAcceptCode = :graphAcceptCode
                SQL,
[ ':graphAcceptCode' => $graphAccept->graphAcceptCode ], PDO::FETCH_OBJ ) ?: []; } $this->medication[0]->graphAccepts = $graphAccepts; } else { $this->medication[0]->graphAccepts = []; } $vitalSigns = selectSql($this->db, <<<SQL
            SELECT
                MDHPVS.MedDayHopsitalPurposeCode AS "medicationId",
                MDHPVS.Type AS "type",
                MDHPVS.ValueNumber AS "valueNumber"
            FROM MedDayHopsitalPurposeVitalSigns AS MDHPVS
            WHERE MDHPVS.MedDayHopsitalPurposeCode = :medicationId
        SQL,
[ ':medicationId' => $this->medication[0]->id ], PDO::FETCH_OBJ); $this->medication[0]->vitalSigns = $vitalSigns ?: []; } else { $this->medication = []; } } private function loadStatDevice(): void { $this->visitPatient = selectSql($this->db, <<<SQL
            SELECT
                M.MedPurposeCode,
                M.MedDeviceAmount "amount",
                M.MedDeviceAmountIssued "amountIssued",
                M.Json,
                MD.Cipher1 "diagCipher",
                M.MedDiagnosisCode,
                CRV.Code "device",
                CRV1.Code "deviceIssued",
                CRV2.Code "medSigns",
                CRV3.Code "cancelReason",
                CRV4.Code "issueKind",
                CRV5.Code "buyKind",
                M.InstructionIssue "instruction",
                M.DateOfUse "expireDate",
                e.CiszGuid "enterpriseSupplyGuid",
                e1.CiszGuid "enterpriseSupplyIssuedGuid",
                e2.CiszGuid "enterpriseDeviceGuid",
                M.EnterpriseSupplyText,
                M.EnterpriseSupplyTextIssued,
                M.InstructionIssue,
                M.PurposeTime "purposeDate",
                M.CancelTime "cancelDate",
                M.IssueDate,
                M.ReleaseDate,
                M.note,
                M.MedDeviceNote "deviceNote",
                M.MedRelativesCode,
                M.Model,
                M.RecordNumber,
                M.SerialNumber,
                MSC.MedPatientCode "patientId",
                CPD.uuid
            FROM
                MedPurposeDepartment MPD
            JOIN MedPurpose M on M.MedPurposeDepartmentCode = MPD.MedPurposeDepartmentCode
            LEFT JOIN MedStatCard MSC on MSC.MedStatCardCode = MPD.MedStatCardCode
            LEFT JOIN MedStatCardDiagnosis MSCD on MSCD.MedStatCardDiagnosisCode = M.MedStatCardDiagnosisCode
            LEFT JOIN MedDiagnosis MD on MD.MedDiagnosisCode = M.MedDiagnosisCode
            LEFT JOIN MedDiagnosis MD1 on MD1.MedDiagnosisCode = MSCD.MedDiagnosisCode
            LEFT JOIN EnterpriseNumber E on E.EnterpriseCode = M.EnterpriseCodeSupply
            LEFT JOIN EnterpriseNumber E1 on E1.EnterpriseCode = M.EnterpriseCodeSupplyIssued
            LEFT JOIN EnterpriseNumber E2 on E2.EnterpriseCode = M.EnterpriseCodeMedDevice
            LEFT JOIN CiszResourceValue CRV on CRV.CiszResourceValueCode = M.CiszResourceValueCodeMedDevice
            LEFT JOIN CiszResourceValue CRV1 on CRV1.CiszResourceValueCode = M.CiszResourceValueCodeMedDeviceIssued
            LEFT JOIN CiszResourceValue CRV2 on CRV2.CiszResourceValueCode = M.CiszResourceValueCodePrescribeIndication
            LEFT JOIN CiszResourceValue CRV3 on CRV3.CiszResourceValueCode = M.CiszResourceCodeCancelCause
            LEFT JOIN CiszResourceValue CRV4 on CRV4.CiszResourceValueCode = M.CiszResourceValueCodeTermOfIssue
            LEFT JOIN CiszResourceValue CRV5 on CRV5.CiszResourceValueCode = M.CiszResourceValueCodeTermOfPurchase
            LEFT JOIN CiszPatientDignosis CPD on CPD.MedPatientCode = MSC.MedPatientCode and CPD.DiagnosisCipher = MD.Cipher1
            WHERE M.MedPurposeCode = :mpc
        SQL,
[ ':mpc' => $this->visitPatientId ], PDO::FETCH_OBJ ); $this->patientId = $this->patientId ?? $this->visitPatient[0]->patientId ?? null; } private function loadVisitPatient(): void { $result = selectSql($this->db, <<<SQL
SELECT
    mvp.MedVisitPatientCode AS "visitPatientId",
    mvp.MedVisitCode AS "visitId",
    mvp.MedPatientCode AS "patientId",
    mv.VisitDate AS "visitDate",
    mv.MedDoctorCode AS "doctorId",
    mvp.MedDiagnosisCode AS "diagnosisId",
    md.Cipher1 AS "diagnosisCipher",
    nullif(mvp.Pressure, '') AS "pressure",
    CASE (coalesce(mvp.Attributes, 0) & 1) = 1
        WHEN TRUE then 4
        WHEN FALSE THEN coalesce(NULLIF(mvp.VisitPlace, 0), -1) + 2
    END AS "visitPlace",
    coalesce(mvp.AttendantDiagnosis, 0) AS "attendantDiagnosis",
    coalesce(mvp.ServiceForm, 1) AS "serviceForm",
    coalesce(mvp.VisitMarkNew, 1) AS "visitMark",
    coalesce(mvp.VisitCaseNew, 1) AS "visitCase",
    cl.uuid,
    mvd.CreateTime AS "createTime",
    mvd.MedVisitDocumentCode AS "visitDocumentId"
FROM
    MedVisitPatient mvp
    JOIN MedVisit mv ON mv.MedVisitCode = mvp.MedVisitCode
    LEFT JOIN ciszLink cl ON cl.Type = 1
        AND cl.TableName = 'MedVisitPatient'
        AND cl.PrimaryKey = mvp.MedVisitPatientCode
    LEFT JOIN MedDiagnosis md ON md.MedDiagnosisCode = mvp.MedDiagnosisCode
    LEFT JOIN MedVisitDocument mvd ON mvd.MedVisitPatientCode = mvp.MedVisitPatientCode
WHERE
    mvp.MedVisitPatientCode = :visitPatientId
    AND coalesce(mvp.AttendantDiagnosis, 0) = 0
SQL,
[ ':visitPatientId' => $this->visitPatientId ], PDO::FETCH_OBJ ); if (!$result) { throw new Exception( med_cisz_constant::ERROR_VISIT_NOT_EXIST_TEXT, med_cisz_constant::ERROR_VISIT_NOT_EXIST_CODE ); } $additionalDiagnoses = selectSql($this->db, <<<SQL
            SELECT
                mvp1.MedVisitPatientCode AS "additionalDiagnosisId",
                mvp1.MedDiagnosisCode AS "diagnosisId",
                md1.Cipher1 AS "diagnosisCipher",
                mvp1.AttendantDiagnosis AS "attendantDiagnosis"
            FROM
                MedVisitPatient mvp1
                LEFT JOIN MedDiagnosis md1
                        ON md1.MedDiagnosisCode = mvp1.MedDiagnosisCode
            WHERE
                mvp1.MedVisitCode = :visitId
                AND mvp1.MedPatientCode = :patientId
                AND mvp1.MedVisitPatientCode <> :visitPatientId
                AND coalesce(mvp1.AttendantDiagnosis, 0) = 1
            SQL,
[ ':visitId' => $result[0]->visitId, ':patientId' => $result[0]->patientId, ':visitPatientId' => $this->visitPatientId ], PDO::FETCH_OBJ ); $result[0]->additionalDiagnoses = $additionalDiagnoses ?: []; $result[0]->htmData = selectSql($this->db, <<<SQL
SELECT
    mvd.MedVisitDocumentCode AS "visitDocumentId",
    hp.Name AS "documentName",
    hu.Name,
    hu.RowIndex AS "rowIndex",
    coalesce(nullif(hu.LongValue, ''), hu.Value) AS "value"
FROM (
    SELECT
        *
    FROM
        MedVisitDocument
    WHERE
        MedVisitPatientCode = :visitPatientId
    ORDER BY CreateTime DESC
    LIMIT 1
) mvd
    JOIN htmPage hp ON hp.htmPageCode = mvd.htmPageCode
    JOIN htmUnit hu ON hu.htmPageCode = mvd.htmPageCode
ORDER BY mvd.CreateTime DESC,
         mvd.ChangeTime DESC,
         coalesce(hu.RowIndex, 0),
         hu.RowIndex
SQL,
[ ':visitPatientId' => $this->visitPatientId ], PDO::FETCH_OBJ ); $this->visitPatient = $result; } private function loadMedInspect(bool $final = false, $inspectCode = false): void { if ($inspectCode) { $this->inspect = $this->visitPatient = selectSql($this->db, <<<SQL
                SELECT
                    MI.*,
                    MI.MedPatientCode                                     "patientId",
                    CRV.CiszResourceValueCode                             "schemeId",
                    CRV.Code                                              "schemeCode",
                    CRV.Name                                              "schemeName",
                    COALESCE(MI.InspectDate, MI.PlanDate)                 "visitDate",
                    (
                        SELECT
                            ValueDate
                        FROM
                            MedInspectOther
                        WHERE
                            MedInspectCode = MI.MedInspectCode
                            AND Type = 13
                        LIMIT 1
                    )                                                     "aOneDate",
                    COALESCE(MVD.MedVisitPatientCode,0)                   "visitPatientId",
                    CASE (COALESCE(MVP.Attributes, 0) & 1) = 1
                        WHEN TRUE then 4
                        WHEN FALSE THEN COALESCE(NULLIF(mvp.VisitPlace, 0), -1) + 2
                    END                                                   "visitPlace",
                    COALESCE(MVP.AttendantDiagnosis, 0)                   "attendantDiagnosis",
                    COALESCE(MVP.ServiceForm, 1)                          "serviceForm",
                    COALESCE(MVP.VisitMarkNew, 1)                         "visitMark",
                    COALESCE(MVP.VisitCaseNew, 1)                         "visitCase",
                    null                                                  "vitalSigns",
                    MI.MedInspectCode                                     "inspectCode",
                    MP.Json                                               "patientJson",
                    MI.CiszResourceValueCodeRejectCause                   "rejectionId",
                    MI.Conclusion                                         "conclusion",
                    MVP.MedDiagnosisCode                                  "diagnosisId",
                    MD.Cipher1                                            "diagnosisCipher"
                FROM
                     MedInspect MI
                JOIN MedPrevent MPR
                   ON MPR.MedPreventCode = MI.MedPreventCode
                LEFT JOIN MedVisitDocument MVD
                        ON MVD.MedInspectCode = MI.MedInspectCode
                LEFT JOIN MedVisitPatient MVP
                        ON MVP.MedVisitPatientCode = MVD.MedVisitPatientCode
                LEFT JOIN CiszResource CR
                        ON CR.Source = 33
                LEFT JOIN CiszResourceValue CRV
                        ON CRV.CiszResourceCode = CR.CiszResourceCode
                           AND CRV.SourceCode = MI.MedPreventCode
                LEFT JOIN MedDiagnosis MD
                            ON MD.MedDiagnosisCode = MVP.MedDiagnosisCode
                LEFT JOIN MedPatient MP ON MP.MedPatientCode = MI.MedPatientCode
                WHERE
                    MI.MedInspectCode = :mic
                LIMIT 1
                SQL,
[ ':mic' => $this->visitPatientId ], PDO::FETCH_OBJ ); } if (!$final && !$inspectCode) { $this->visitPatient = selectSql($this->db, <<<SQL
                SELECT
                    MVP.MedVisitPatientCode                              "visitPatientId",
                    MVP.MedVisitCode                                     "visitId",
                    MVP.MedPatientCode                                   "patientId",
                    MV.VisitDate                                         "visitDate",
                    MV.MedDoctorCode                                     "doctorId",
                    MVP.MedDiagnosisCode                                 "diagnosisId",
                    MD.Cipher1                                           "diagnosisCipher",
                    NULLIF(MVP.Pressure, '')                             "pressure",
                    CASE (COALESCE(MVP.Attributes, 0) & 1) = 1
                        WHEN TRUE THEN 4
                        WHEN FALSE THEN COALESCE(NULLIF(mvp.VisitPlace, 0), -1) + 2
                    END                                                  "visitPlace",
                    COALESCE(MVP.AttendantDiagnosis, 0)                  "attendantDiagnosis",
                    COALESCE(MVP.ServiceForm, 1)                         "serviceForm",
                    COALESCE(MVP.VisitMarkNew, 1)                        "visitMark",
                    COALESCE(MVP.VisitCaseNew, 1)                        "visitCase",
                    MVP_ADD.*,
                    CL.Uuid,
                    COALESCE(MVD.MedInspectCode, 0)                      "inspectCode",
                    MP.Json                                              "patientJson",
                    CRV.CiszResourceValueCode                             "schemeId",
                    CRV.Code                                              "schemeCode",
                    CRV.Name                                              "schemeName"
                FROM
                    MedVisitPatient MVP
                    JOIN MedVisit MV ON MV.MedVisitCode = MVP.MedVisitCode
                    LEFT JOIN CiszLink CL
                            ON CL.Type = 1
                               AND CL.TableName = 'MedVisitPatient'
                               AND CL.PrimaryKey = MVP.MedVisitPatientCode
                    LEFT JOIN MedDiagnosis MD
                            ON MD.MedDiagnosisCode = MVP.MedDiagnosisCode
                    LEFT JOIN MedVisitDocument MVD
                            ON MVD.MedVisitPatientCode = MVP.MedVisitPatientCode
                    LEFT JOIN LATERAL (
                        SELECT
                            MVP1.MedDiagnosisCode  "addDiagnosisId",
                            MD1.Cipher1            "addDiagnosisCipher"
                        FROM
                            MedVisitPatient MVP1
                            LEFT JOIN MedDiagnosis MD1
                                    ON MD1.MedDiagnosisCode = MVP1.MedDiagnosisCode
                        WHERE
                            MVP1.MedVisitCode = MVP.MedVisitCode
                            AND MVP1.MedPatientCode = MVP.MedPatientCode
                            AND MVP1.MedVisitPatientCode <> MVP.MedVisitPatientCode
                            AND COALESCE(MVP1.AttendantDiagnosis, 0) = 1
                    ) AS MVP_ADD ON TRUE
                LEFT JOIN MedPatient MP ON MP.MedPatientCode = MVP.MedPatientCode
                LEFT JOIN MedInspect MI ON MI.MedInspectCode = MVD.MedInspectCode
                LEFT JOIN CiszResource CR
                        ON CR.Source = 33
                LEFT JOIN CiszResourceValue CRV
                        ON CRV.CiszResourceCode = CR.CiszResourceCode
                           AND CRV.SourceCode = MI.MedPreventCode
                WHERE
                    MVP.MedVisitPatientCode = :visitPatientId
                    AND COALESCE(MVP.AttendantDiagnosis, 0) = 0
                SQL,
[ ':visitPatientId' => $this->visitPatientId ], PDO::FETCH_OBJ ); } $inspect = null; $inspectId = null; if (!$inspectCode && !empty($this->visitPatient)) { $inspect = $this->visitPatient[array_key_first($this->visitPatient)]; $inspectId = $inspect->inspectCode ?? null; } elseif (!empty($this->inspect)) { $inspect = $this->inspect[array_key_first($this->inspect)]; $inspectId = $this->visitPatientId ?? null; } if ($inspectId) { $vitalSigns = selectSql($this->db, <<<SQL
                SELECT
                  MIO.MedInspectOtherCode "idPart",
                  MIO.Type                "type",
                  MIO.ValueDate           "date",
                  MIO.ValueNumber         "value",
                  MIO.ValueString         "valueStr",
                  CRV.Code                "valueCodeCisz"
                FROM
                    MedInspectOther MIO
                    LEFT JOIN CiszResourceValue CRV ON CRV.CiszResourceValueCode = MIO.CiszResourceValueCodeCentile
                WHERE
                    MIO.MedInspectCode = :mic
                    AND (MIO.ValueDate IS NOT NULL
                        OR MIO.ValueNumber IS NOT NULL
                        OR MIO.ValueString IS NOT NULL
                        OR MIO.ValueString IS NOT NULL
                        OR MIO.CiszResourceValueCodeCentile IS NOT NULL
                        OR MIO.Type IN (11, 12))
                SQL,
[ ':mic' => $inspectId ], PDO::FETCH_OBJ ); if (!$inspectCode && !empty($this->visitPatient)) { $this->visitPatient[array_key_first($this->visitPatient)]->vitalSigns = $vitalSigns; } elseif (!empty($this->inspect)) { $this->inspect[array_key_first($this->inspect)]->vitalSigns = $vitalSigns; } } if (!$this->visitPatient && !$this->inspect) { throw new Exception( med_cisz_constant::ERROR_VISIT_NOT_EXIST_TEXT, med_cisz_constant::ERROR_VISIT_NOT_EXIST_CODE ); } if (!$inspectCode || $this->inspect[array_key_first($this->inspect)]->visitPatientId !== 0) { $this->visitPatient[array_key_first($this->visitPatient)]->htmData = selectSql($this->db, <<<SQL
                SELECT
                    MVD.MedVisitDocumentCode                        "visitDocumentId",
                    HP.Name                                         "documentName",
                    HU.Name                                         "name",
                    COALESCE(NULLIF(HU.LongValue, ''), HU.Value)    "value"
                FROM
                    (
                        SELECT
                            *
                        FROM
                            MedVisitDocument
                        WHERE
                            MedVisitPatientCode = :visitPatientId
                        ORDER BY CreateTime DESC
                        LIMIT 1
                    ) MVD
                    JOIN HtmPage HP
                        ON HP.HtmPageCode = MVD.HtmPageCode
                    JOIN HtmUnit HU
                        ON HU.HtmPageCode = MVD.HtmPageCode
                ORDER BY MVD.CreateTime DESC,
                         MVD.ChangeTime DESC,
                         COALESCE(HU.RowIndex, 0)
                SQL,
[ ':visitPatientId' => $this->visitPatient[array_key_first($this->visitPatient)]->visitPatientId ], PDO::FETCH_OBJ ); } if (!$this->patientId) { $this->patientId = $this->visitPatient[array_key_first($this->visitPatient)]->patientId; } } private function loadStudyPatient(): void { $this->funcDiagnostic = selectSql( $this->db, <<<SQL
            SELECT
                mls.MedLogStudyCode AS "visitFuncDiagId",
                mls.MedPatientCode AS "patientId",
                mls.MedStudyCode AS "medStudyId",
                mls.DirTime AS "visitDate",
                mls.DirTime AS "startDate",
                mls.MedDoctorCode AS "doctorId",
                mls.MedDiagnosisCode AS "diagnosisId",
                md.Cipher1 AS "diagnosisCipher",
                mls.DepartmentCodeExec AS "visitPlace",
                CS.CiszResourceValueCode AS "diagnosticMethodId",
                CRVM.Code AS "diagnosticMethodCode",
                CS.CiszResourceValueCodeCategory AS "categoryId",
                CRVC.Code AS "categoryCode",
                CS.CiszResourceValueCodeServiceType AS "serviceTypeId",
                CRVT.Code AS "serviceTypeCode"
            FROM
                MedLogStudy mls
                LEFT JOIN MedStudy MS ON MS.MedStudyCode = mls.MedStudyCode
                LEFT JOIN CiszStudyList MSL ON MSL.MedStudyCode = MS.MedStudyCode
                LEFT JOIN CiszStudy CS ON CS.CiszStudyCode = MSL.CiszStudyCode
                LEFT JOIN CiszResourceValue CRVM ON CRVM.CiszResourceValueCode = CS.CiszResourceValueCode
                LEFT JOIN CiszResourceValue CRVC ON CRVC.CiszResourceValueCode = CS.CiszResourceValueCodeCategory
                LEFT JOIN CiszResourceValue CRVT ON CRVT.CiszResourceValueCode = CS.CiszResourceValueCodeServiceType
                LEFT JOIN MedDiagnosis md ON md.MedDiagnosisCode = mls.MedDiagnosisCode
            WHERE mls.MedLogStudyCode = :medlogId
            SQL,
[ ':medlogId' => $this->visitPatientId, ], PDO::FETCH_OBJ ); $firstKey = array_key_first($this->funcDiagnostic); $this->funcDiagnostic[$firstKey]->serviceForm = 1; $this->funcDiagnostic[$firstKey]->visitMark = 1; $this->funcDiagnostic[$firstKey]->visitCase = 1; $this->funcDiagnostic[$firstKey]->visitPlace = 1; $this->funcDiagnostic[$firstKey]->funcHtmData = selectSql($this->db, <<<SQL
        SELECT
            mls.MedLogStudyCode as "visitFuncDiagId",
            hp.Name AS "documentName",
            hu.Name,
            coalesce(nullif(hu.LongValue, ''), hu.Value) AS value,
            coalesce(hu.RowIndex, 0) as "rowIndex",
            HP.Html AS "fullHtml"
        FROM (
            SELECT
                *
            FROM
                MedLogStudy
            WHERE
                MedLogStudyCode = :medlogId
                AND Type in (3,2)
            LIMIT 1
        ) mls
            JOIN htmPage hp ON hp.htmPageCode = mls.htmPageCode
            JOIN htmUnit hu ON hu.htmPageCode = mls.htmPageCode
        ORDER BY hp.CreateTime DESC, coalesce(hu.RowIndex, 0)
        SQL,
[ ':medlogId' => $this->visitPatientId, ], PDO::FETCH_OBJ ); if (self::getHtmDataValue($this->funcDiagnostic[array_key_first($this->funcDiagnostic)]->funcHtmData,['Number_Study'])) { $this->funcDiagnostic[array_key_first($this->funcDiagnostic)]->funcHtmCode = self::getHtmDataValue($this->funcDiagnostic[array_key_first($this->funcDiagnostic)]->funcHtmData,['Number_Study']); } } private function loadLabStudyPatient(): void { $this->visitPatient = selectSql( $this->db, <<<SQL
            SELECT
                mls.MedLogStudyCode AS "visitPatientId",
                mls.MedPatientCode AS "patientId",
                mls.DirTime AS "visitDate",
                mls.DirTime AS "startDate",
                mls.MedDoctorCode AS "doctorId",
                mls.MedDiagnosisCode AS "diagnosisId",
                mls.MedDiagnosisCode AS "diagnosisFinalId",
                md.Cipher1 AS "diagnosisCipher",
                mls.DepartmentCodeExec AS "visitPlace"
            FROM
                MedLogStudy mls
                LEFT JOIN MedDiagnosis md ON md.MedDiagnosisCode = mls.MedDiagnosisCode
            WHERE mls.MedLogStudyCode = :medlogId
            SQL,
[ ':medlogId' => $this->visitPatientId, ], PDO::FETCH_OBJ ); $this->visitPatient[array_key_first($this->visitPatient)]->htmData = selectSql($this->db, <<<SQL
        SELECT
            mls.MedLogStudyCode as "visitPatientId",
            hp.Name AS "documentName",
            hu.Name,
            coalesce(nullif(hu.LongValue, ''), hu.Value) AS value,
            coalesce(hu.RowIndex, 0) as "rowIndex"
        FROM (
            SELECT
                *
            FROM
                MedLogStudy
            WHERE
                MedLogStudyCode = :medlogId
                AND Type = 1
            LIMIT 1
        ) mls
            JOIN htmPage hp ON hp.htmPageCode = mls.htmPageCode
            JOIN htmUnit hu ON hu.htmPageCode = mls.htmPageCode
        ORDER BY hp.CreateTime DESC, coalesce(hu.RowIndex, 0)
        SQL,
[ ':medlogId' => $this->visitPatientId, ], PDO::FETCH_OBJ ); } private function getTypeStudy($medLogId){ $result = selectSql( $this->db, <<<SQL
        SELECT
            mls.Type
        FROM
            MedLogStudy mls
        WHERE mls.MedLogStudyCode = :medlogId
        SQL,
[ ':medlogId' => $medLogId, ], PDO::FETCH_COLUMN ); return $result[0] ?? null; } private function loadVisitPatientStat(): void { $this->visitPatient = selectSql( $this->db, <<<SQL
SELECT
    mscd.medstatcarddoccode AS "visitPatientId",
    mscd.medstatcardcode AS "visitId",
    msc.MedPatientcode AS "patientId",
    coalesce((select fn_htmpagegetvalue(FN_htmPageGetUnits(mscd.htmpagecode, 'DateVisit'), 'DateVisit')), mscd.documentDate) AS "visitDate",
    mscd.MedDoctorCode AS "doctorId",
    mscd.HtmPageCode AS "htmPageCode",
    coalesce(
        coalesce((select fn_htmpagegetvalue(FN_htmPageGetUnits(mscd.htmpagecode, 'diagnosis'), 'diagnosis')),
                (select fn_htmpagegetvalue(FN_htmPageGetUnits(mscd.htmpagecode, 'diagnosis_NEW'), 'diagnosis_NEW'))), 0) AS "diagnosisId",
    coalesce((select fn_htmpagegetvalue(FN_htmPageGetUnits(mscd.htmpagecode, 'diagnosis_cipher'), 'diagnosis_cipher')),
                (select fn_htmpagegetvalue(FN_htmPageGetUnits(mscd.htmpagecode, 'diagnosis_cipher_NEW'), 'diagnosis_cipher_NEW'))) AS "diagnosisCipher",
    (select fn_htmpagegetvalue(FN_htmPageGetUnits(htmpagecode, 'ZPT1TX2'), 'ZPT1TX2')) +'/' +
      (select fn_htmpagegetvalue(FN_htmPageGetUnits(htmpagecode, 'ZPT1TX3'), 'ZPT1TX3'))  AS "pressure",
    coalesce((select fn_htmpagegetvalue(FN_htmPageGetUnits(mscd.htmpagecode, 'diagnosis_1'), 'diagnosis_1')), 0) AS "attendantDiagnosis",
    (select fn_htmpagegetvalue(FN_htmPageGetUnits(mscd.htmpagecode, 'objDiagComplication'), 'objDiagComplication'))AS "complicationDiagnosesStac",
    (select fn_htmpagegetvalue(FN_htmPageGetUnits(mscd.htmpagecode, 'objDiagAttendant'), 'objDiagAttendant')) AS "additionalDiagnosesStac",
    coalesce(msc.medhelpkindcode, 0) AS "visitPlace",
    1 AS "serviceForm",
    1 AS "visitMark",
    1 AS "visitCase",
    cl.uuid,
    null AS "additionalDoc"
FROM
    MedStatcarddoc mscd
    INNER JOIN Medstatcard msc ON msc.Medstatcardcode = mscd.medstatcardcode
    LEFT JOIN ciszLink cl ON cl.Type = 1
        AND cl.TableName = 'MedStatCard'
        AND cl.PrimaryKey = mscd.Medstatcarddoccode
WHERE
    mscd.Medstatcarddoccode = :visitPatientId
SQL,
[ ':visitPatientId' => $this->visitPatientId ], PDO::FETCH_OBJ ); $additionalDiagnoses = selectSql($this->db, <<<SQL
            SELECT
                D.MedDiagnosisCode AS "diagnosisId",
                D.Cipher1 AS "diagnosisCipher"
            FROM htmUnit U
            LEFT JOIN MedDiagnosis D
                        ON D.MedDiagnosisCode = U.value
            WHERE U.htmpagecode = :pageCode
            AND U.name = 'diagnosis_1'
            AND D.MedDiagnosisCode is not null
            ORDER BY U.RowIndex
            SQL,
[ ':pageCode' => $this->visitPatient[0]->htmPageCode, ], PDO::FETCH_OBJ ); $this->visitPatient[0]->additionalDiagnoses = $additionalDiagnoses ?: []; if (!$this->visitPatient) { throw new Exception( med_cisz_constant::ERROR_VISIT_NOT_EXIST_TEXT, med_cisz_constant::ERROR_VISIT_NOT_EXIST_CODE ); } else { $this->patientId = $this->visitPatient[0]->patientId; } $this->visitPatient[array_key_first($this->visitPatient)]->htmData = selectSql( $this->db, <<<SQL
SELECT
    mscd.medstatcarddoccode AS "visitDocumentId",
    hp."name" AS "documentName",
    hu."name",
    coalesce(hu.RowIndex, 0) as "rowIndex",
    coalesce(nullif(hu.LongValue, ''), hu.Value) AS value
FROM medstatcardDoc mscd
    JOIN htmPage hp ON hp.htmPageCode = mscd.htmPageCode
    JOIN htmUnit hu ON hu.htmPageCode = mscd.htmPageCode
where mscd.medstatcarddoccode = :visitPatientId
ORDER BY mscd.documentdate desc, coalesce(hu.RowIndex, 0)
SQL,
[ ':visitPatientId' => $this->visitPatientId ], PDO::FETCH_OBJ ); $this->visitPatient[array_key_first($this->visitPatient)]->additionalDoc = selectSql( $this->db, <<<SQL
            SELECT
                MEFT.MedExternalFileCode "fileCode"
            FROM
                MedExternalFileT MEFT
            WHERE
                MEFT.Source = 41
                AND MEFT.SourceCode = :visitPatientId
            SQL,
[ ':visitPatientId' => $this->visitPatientId ], PDO::FETCH_OBJ ); } private function loadVisitPatientStom($docId = null): void { $where = 'SV.StomVisitCode = :visitPatientId'; $params = [ ':visitPatientId' => $this->visitPatientId, ]; if ($docId !== null) { $where = "(
            SV.StomVisitCode = :visitPatientId
            OR D.MedVisitDocumentCode = :docId
        )"; $params[':docId'] = $docId; } $this->visitPatient = selectSql( $this->db, <<<SQL
SELECT
    SV.StomVisitCode AS "visitPatientId",
    D.MedVisitDocumentCode AS "visitDocumentId",
    ST.MedPatientcode AS "patientId",
    SV.VisitDate AS "visitDate",
    SV.VisitTime AS "visitTime",
    SV.MedDoctorCode AS "doctorId",
    D.HtmPageCode AS "htmPageCode",
    SV.MedDiagnosisCode AS "diagnosisId",
    MD.Cipher1 AS "diagnosisCipher",
    (select fn_htmpagegetvalue(FN_htmPageGetUnits(htmpagecode, 'ZPT1TX2'), 'ZPT1TX2')) +'/' +
      (select fn_htmpagegetvalue(FN_htmPageGetUnits(htmpagecode, 'ZPT1TX3'), 'ZPT1TX3'))  AS "pressure",
    --SV.AttendantDiagnosis AS "attendantDiagnosis",
    --coalesce(msc.medhelpkindcode, 0) AS "visitPlace",
    1 AS "serviceForm",
    1 AS "visitMark",
    1 AS "visitCase",
    CL.Uuid,
    null AS "additionalDoc"
FROM
    StomVisit SV
    JOIN StomCard ST ON ST.StomCardCode = SV.StomCardCode
    JOIN MedVisitDocument D ON D.StomVisitCode = SV.StomVisitCode
    LEFT JOIN MedDiagnosis MD ON MD.MedDiagnosisCode = SV.MedDiagnosisCode
    LEFT JOIN ciszLink CL ON CL.Type = 1
        AND CL.TableName = 'StomVisit'
        AND CL.PrimaryKey = SV.StomVisitCode
WHERE $where
SQL,
$params, PDO::FETCH_OBJ ); $additionalDiagnoses = selectSql($this->db, <<<SQL
            SELECT
                D.MedDiagnosisCode AS "diagnosisId",
                D.Cipher1 AS "diagnosisCipher"
            FROM htmUnit U
            LEFT JOIN MedDiagnosis D
                        ON D.MedDiagnosisCode = U.value
            WHERE U.htmpagecode = :pageCode
            AND U.name = 'diagnosis_1'
            AND D.MedDiagnosisCode is not null
            ORDER BY U.RowIndex
            SQL,
[ ':pageCode' => $this->visitPatient[0]->htmPageCode, ], PDO::FETCH_OBJ ); $this->visitPatient[0]->additionalDiagnoses = $additionalDiagnoses ?: []; if (!$this->visitPatient) { throw new Exception( med_cisz_constant::ERROR_VISIT_NOT_EXIST_TEXT, med_cisz_constant::ERROR_VISIT_NOT_EXIST_CODE ); } else { $this->patientId = $this->visitPatient[0]->patientId; } $this->visitPatient[array_key_first($this->visitPatient)]->htmData = selectSql( $this->db, <<<SQL
SELECT
    MVD.MedVisitDocumentCode AS "visitDocumentId",
    HP.Name AS "documentName",
    HU.Name,
    HU.RowIndex AS "rowIndex",
    coalesce(nullif(HU.LongValue, ''), HU.Value) AS "value"
FROM (
    SELECT
        *
    FROM
        MedVisitDocument
    WHERE
        StomVisitCode = :visitPatientId
    ORDER BY CreateTime DESC
    LIMIT 1
) MVD
    JOIN htmPage HP ON HP.htmPageCode = MVD.htmPageCode
    JOIN htmUnit HU ON HU.htmPageCode = MVD.htmPageCode
ORDER BY MVD.CreateTime DESC,
         MVD.ChangeTime DESC,
         COALESCE(HU.RowIndex, 0),
         HU.RowIndex
SQL,
[ ':visitPatientId' => $this->visitPatientId ], PDO::FETCH_OBJ ); } public function loadHospitalisationRequest(): void { $this->visitPatient = selectSql( $this->db, <<<SQL
            SELECT
       MLH.MedLogHospitalCode  "visitPatientId",
       MLH.NumberOrder "number",
       MLH.MedDoctorCode "medDoctorCode",
       MLH.MedDoctorCodeRegistry "medDoctorCodeRegistry",
       MLH.MedPatientCode "mpc",
       FN_cmFIO(MD.ManCode,1) "doctorFIO",
       FN_cmFIO(MD3.ManCode,1) "doctorRegistryFIO",
       FN_cmFIO(MP.ManCode,1) "patientFIO",
       FN_cmFIO(MP.ManCode) "patientFIOFull",
       FN_cmFIO(MD.ManCode) "doctorFIOFull",
       MLH.HospitalKind "hospitalKind",
       MLH.HospitalKind "visitCase",
       0 "serviceForm",
       1 "visitPlace",
       3 "visitMark",
       CASE
           WHEN MLH.HospitalKind = 1 THEN 'Плановая'
           ELSE 'Экстренная'
       END "kindName",
       MLH.FailReason "failReason",
       MLH.MedProfileCode "medProfileCode",
       MPr.name "medProfileName",
       MLH.DirectDate "visitDate",
       MLH.HospitalDate "hospitalDate",
       MLH.OutDate "outHospitalDate",
       MLH.EpicrisisDate "epicrisisDate",
       MLH.EpicrisisDateRefined "epicrisisDateRefined",
       MLH.EnterpriseCodeHospital "enterpriseCodeHospital",
       E.Name "enterpriseHospital",
       MLH.MedDiagnosisCodeDirect "medDiagnosisCodeDirect",
       MLH.MedDiagnosisCodeClinic "medDiagnosisCodeClinic",
       COALESCE(MLH.MedDiagnosisCodeDirect,MLH.MedDiagnosisCodeClinic) "diagnosisId",
       MLH.SicknessKind "sicknessKind",
       MT.MedTraumaCode "traumaId",
       MT.Name "traumaDisplay",
       MT.Code "traumaCode",
       MD2.Name "DiagnosisClinicName",
       MD2.Cipher1 "diagnosisClinic",
       MD4.Cipher1 "diagnosisCipher",
       MLH.UniDictCodeResult "uniDictCodeResult",
       MLH.EnterpriseCode "enterpriseCode",
       UD.Value "hospitalResult",
       MLH.medStatCardCode "statCardId",
       MLH.AgreedWith "agreedWith",
       MLH.CiszResourceValueCodeSpecialization "specializationCode",
       CRV_SPEC.code "speciality",
       MLH.CiszResourceValueCodeMedServCat "healthCareCode",
       CRV_CAT.code "healthCare",
       MLH.CiszResourceValueCodeHospGoal "goal",
       MLH.ConfirmationDate "confirmationDate",
       MLH.Note "note",
       MLH.RejectDate "refusalDate",
       MLH.RejectBy "refusalBy",
       MLH.CiszResourceValueCodeRejectCause "refusalReasonCode",
       CRV_REJECT.code "refusalCode",
       MLH.PlanDate "planStartDate",
       MLH.PlanDateFinish "planFinishDate",
       MLH.patientinstruction "instruction",
       MLH.departmentCode "department",
       MLH.enterpriseCode "enterprise"
        FROM MedLogHospital MLH
       LEFT JOIN MedDoctor MD ON MD.MedDoctorCode = MLH.MedDoctorCode
       LEFT JOIN MedProfile MPr ON MPr.MedProfileCode = MLH.MedProfileCode
       LEFT JOIN MedDoctor MD3 ON MD3.MedDoctorCode = MLH.MedDoctorCodeRegistry
       LEFT JOIN MedPatient MP ON MP.MedPatientCode = MLH.MedPatientCode
       LEFT JOIN Enterprise E ON E.EnterpriseCode = MLH.EnterpriseCodeHospital
       LEFT JOIN MedDiagnosis MD2 ON MD2.MedDiagnosisCode = MLH.MedDiagnosisCodeClinic
       LEFT JOIN MedDiagnosis MD4 ON MD4.MedDiagnosisCode = MLH.MedDiagnosisCodeDirect
       LEFT JOIN MedTrauma MT ON MT.MedTraumaCode = MLH.MedTraumaCode
       LEFT JOIN UniDict UD ON (UD.UniDictCode=MLH.UnidictCodeResult AND UD.DictNumber=38)
       LEFT JOIN CiszResourceValue CRV_SPEC ON CRV_SPEC.CiszResourceValueCode = MLH.CiszResourceValueCodeSpecialization
       LEFT JOIN CiszResourceValue CRV_CAT ON CRV_CAT.CiszResourceValueCode = MLH.CiszResourceValueCodeMedServCat
       LEFT JOIN CiszResourceValue CRV_REJECT ON CRV_REJECT.CiszResourceValueCode = MLH.CiszResourceValueCodeRejectCause
        WHERE MLH.MedLogHospitalCode = :mlhc
SQL,
[ ':mlhc' => $this->visitPatientId ], PDO::FETCH_OBJ ); if (isset($this->visitPatient)) { $this->patientId = $this->visitPatient[0]->mpc; } $this->hospitalisationActions = selectSql( $this->db, <<<SQL
            SELECT
                crv.code "code",
                crv.name "description"
            FROM
                MedLogHospitalAction MLHA
            JOIN CiszResourceValue CRV on crv.ciszResourceValueCode = MLHA.ciszresourcevaluecodeaction
            WHERE MLHA.MedLogHospitalCode = :mlhc
SQL,
[ ':mlhc' => $this->visitPatientId ], PDO::FETCH_OBJ ); } private function loadHospitalisationLog(): void { $this->visitPatient = selectSql( $this->db, <<<SQL
            SELECT
                ml.MedLogCode "visitPatientId",
                ml.MedPatientCode "patientId",
                ml.MedDoctorCodeReception "careManagerId",
                ml.IncomeDate "periodStart",
                ml.MedHelpKindCode "helpKind",
                ml.MedStatCardCode "medStatCardId",
                ml.Note "note",
                ml.NumberHistory "numberHistory",
                COALESCE(ml.Refused,0) "refused",
                ml.IncomeDate "visitDate",
                CASE COALESCE(msc.TimeAfter,3)
                    WHEN 1 THEN 6
                    WHEN 2 THEN 12
                    WHEN 3 THEN 24
                END "timeAfter",
                CRV.Code "typeCare",
                CRV1.Code "typeHosp",
                ml.HospitalizationReason "hospReason",
                ml.HospitalizationTerm "hospTerm",
                ml.RejectBy "rejectInitiator",
                msc.CotDay "cotDay",
                CASE COALESCE(msc.FirstInYear, 1)
                    WHEN 3 then 1
                    ELSE COALESCE(msc.FirstInYear, 1)
                END "countHospYear",
                msc.InDate "inDate",
                msc.OutDate "outDate",
                null "violations",
                null "moves",
                null "preleminaryDiag",
                null "clinicalDiag",
                null "finalDiag",
                null "pathoDiag",
                null "diagCipher",
                null "addDiagCipher",
                null "diagnosisId",
                null "previousDiag",
                NULLIF(ML.MedLogDiagnosis, '') "reasonText",
                CASE coalesce(MSCE.BloodType, 0)
                    WHEN 0 THEN 'no'
                    WHEN 1 THEN '0'
                    WHEN 2 THEN 'A'
                    WHEN 3 THEN 'B'
                    WHEN 4 THEN 'AB'
                        END "bloodType",
                CASE coalesce(MSCE.BloodTypeKell, 0)
                    WHEN 0 THEN 'no'
                    WHEN 1 THEN 'Kell-neg'
                    WHEN 2 THEN 'Kell-pos'
                        END "bloodTypeKell",
                CASE coalesce(MSCE.RhFactor, -1)
                    WHEN -1 THEN 'no'
                    WHEN 0 THEN 'Rh-neg'
                    WHEN 1 THEN 'Rh-pos'
                        END "rhFactor",
                null "transfusiology",
                CASE coalesce(MSCE.ViralHepatitisResult, 0)
                    WHEN 0 then False
                    WHEN 1 Then True
                END "hepatitis",
                ML.DiffDiagnosis,
                null "diagNote",
                D.CiszGuid "departmentUuid",
                ML.InitialDiagnosis "preNote",
                ML.MedLogDiagnosis "clinicalNote",
                null "IMN",
                null "medications",
                CDE.json "jsonRequest"
            FROM MedLog ML
            LEFT JOIN MedStatCard MSC on MSC.MedStatCardCode = ML.MedStatCardCode
            LEFT JOIN MedStatCardExt MSCE on MSC.MedStatCardCode = MSCE.MedStatCardCode
            LEFT JOIN CiszResourceValue CRV on CRV.CiszResourceValueCode = ML.CiszResourceValueCodeTypeOfMedCare
            LEFT JOIN CiszResourceValue CRV1 on CRV1.CiszResourceValueCode = ML.CiszResourceValueCodeHospType
            LEFT JOIN Department D on D.DepartmentCode = ML.DepartmentCodeReceived
            LEFT JOIN CiszDocExtra CDE on CDE.MedLogCode = ML.MedLogCode
            WHERE ML.MedLogCode = :mlc
            SQL,
[ ':mlc' => $this->visitPatientId ], PDO::FETCH_OBJ ); if ($this->visitPatient[0]->jsonRequest) { $this->visitPatient[0]->jsonRequest = safe_json_decode($this->visitPatient[0]->jsonRequest); } if ($this->visitPatient[0]->medStatCardId) { $this->visitPatient[0]->violations = selectSql( $this->db, <<<SQL
            SELECT
                MSCV.note "note",
                MSCV.violationTime "violationDate"
            FROM
                MedStatCardViolation MSCV
            WHERE MSCV.MedStatCardCode = :mscc
            SQL,
[ ':mscc' => $this->visitPatient[0]->medStatCardId ], PDO::FETCH_OBJ ); $this->visitPatient[0]->moves = selectSql( $this->db, <<<SQL
            SELECT
                coalesce(MSCMP.departmetCode, MSM.departmentCode) "departmentCode",
                MSM.moveDate "moveDate",
                MSCMP.medDoctorCode "medDoctorCode",
                MSCMP.moveType "moveType",
                D.ciszGuid "uuid",
                case MSM.MedProfileCode
                    WHEN 1 THEN 'short-therapeutic'
                    WHEN 3 THEN 'short-surgical'
                    WHEN 9 THEN 'short-intensive'
                END "bedProfile",
                case MSCMP.moveType
                    WHEN 6 THEN '0'
                    WHEN 4 THEN '1'
                    WHEN 5 THEN '2'
                    WHEN 3 THEN '3'
                END "outcome"
            FROM
                MedStatMovePatient MSCMP
            LEFT JOIN MedStatMove MSM on MSM.MedStatMoveCode = MSCMP.MedStatMoveCode
            LEFT JOIN Department D on D.DepartmentCode = MSM.departmentCode
            WHERE MSCMP.MedStatCardCode = :mscc AND D.CiszGuid is not null
            SQL,
[ ':mscc' => $this->visitPatient[0]->medStatCardId ], PDO::FETCH_OBJ ); $this->visitPatient[0]->transfusiology = selectSql( $this->db, <<<SQL
            SELECT
               MPT.Indication "indicator",
               MPT.Name "nameByPatient",
               CRV.code "name",
               MPT.transfusionDate "transDate",
               MPTC.description "complication",
               MPTC.complicationMedium "complicationPlacePatient",
               CRV1.code "severity",
               CRV2.code "complicationPlace",
               MPTC.complicationDate "complicationDate",
               MPTC.medDiagnosisCode "diagCode",
               MD.cipher1 "diagCipher"
            FROM
                MedPatientTransfusion MPT
            LEFT JOIN MedPatientTransfusionIn MPTI on MPTI.MedPatientTransfusionCode = MPT.MedPatientTransfusionCode
            LEFT JOIN CiszResourceValue CRV on CRV.CiszResourceValueCode = MPTI.CiszResourceValueCodeTransfusion
            LEFT JOIN MedPatientTransfusionComplication MPTC on MPTC.MedPatientTransfusionCode = MPT.MedPatientTransfusionCode
            LEFT JOIN CiszResourceValue CRV1 on CRV1.CiszResourceValueCode = MPTC.CiszResourceValueCodeSeverity
            LEFT JOIN MedPatientTransfusionComplicationIn MPTCI on MPTCI.MedPatientTransfusionComplicationCode = MPTC.MedPatientTransfusionComplicationCode
            LEFT JOIN CiszResourceValue CRV2 on CRV2.CiszResourceValueCode = MPTCI.CiszResourceValueCodeMedium
            LEFT JOIN MedDiagnosis MD on MD.MedDiagnosisCode = MPTC.MedDiagnosisCode
            WHERE MPT.MedPatientCode = :mpc
            SQL,
[ ':mpc' => $this->visitPatient[0]->patientId ], PDO::FETCH_OBJ ); $this->visitPatient[0]->IMN = selectSql( $this->db, <<<SQL
            SELECT
                M.MedPurposeCode,
                M.MedDeviceAmount "amount",
                M.MedDeviceAmountIssued "amountIssued",
                M.Json,
                MD.Cipher1 "diagCipher",
                M.MedDiagnosisCode,
                CRV.Code "device",
                CRV1.Code "deviceIssued",
                CRV2.Code "medSigns",
                CRV3.Code "cancelReason",
                CRV4.Code "issueKind",
                CRV5.Code "buyKind",
                M.InstructionIssue "instruction",
                M.DateOfUse "expireDate",
                e.CiszGuid "enterpriseSupplyGuid",
                e1.CiszGuid "enterpriseSupplyIssuedGuid",
                e2.CiszGuid "enterpriseDeviceGuid",
                M.EnterpriseSupplyText,
                M.EnterpriseSupplyTextIssued,
                M.InstructionIssue,
                M.PurposeTime "purposeDate",
                M.CancelTime "cancelDate",
                M.IssueDate,
                M.ReleaseDate,
                M.note,
                M.MedDeviceNote "deviceNote",
                M.MedRelativesCode,
                M.Model,
                M.RecordNumber,
                M.SerialNumber,
                Cl.uuid,
                1 "receiverId"
            FROM
                MedPurposeDepartment MPD
            JOIN MedPurpose M on M.MedPurposeDepartmentCode = MPD.MedPurposeDepartmentCode
            LEFT JOIN MedStatCardDiagnosis MSCD on MSCD.MedStatCardDiagnosisCode = M.MedStatCardDiagnosisCode
            LEFT JOIN MedDiagnosis MD on MD.MedDiagnosisCode = M.MedDiagnosisCode
            LEFT JOIN EnterpriseNumber E on E.EnterpriseCode = M.EnterpriseCodeSupply
            LEFT JOIN EnterpriseNumber E1 on E1.EnterpriseCode = M.EnterpriseCodeSupplyIssued
            LEFT JOIN EnterpriseNumber E2 on E2.EnterpriseCode = M.EnterpriseCodeMedDevice
            LEFT JOIN CiszResourceValue CRV on CRV.CiszResourceValueCode = M.CiszResourceValueCodeMedDevice
            LEFT JOIN CiszResourceValue CRV1 on CRV1.CiszResourceValueCode = M.CiszResourceValueCodeMedDeviceIssued
            LEFT JOIN CiszResourceValue CRV2 on CRV2.CiszResourceValueCode = M.CiszResourceValueCodePrescribeIndication
            LEFT JOIN CiszResourceValue CRV3 on CRV3.CiszResourceValueCode = M.CiszResourceCodeCancelCause
            LEFT JOIN CiszResourceValue CRV4 on CRV4.CiszResourceValueCode = M.CiszResourceValueCodeTermOfIssue
            LEFT JOIN CiszResourceValue CRV5 on CRV5.CiszResourceValueCode = M.CiszResourceValueCodeTermOfPurchase
            LEFT JOIN CiszLink CL on CL.TableName = 'DeviceRequestStat' and CL.PrimaryKey = M.MedPurposeCode and CL.Type = 1
            WHERE MPD.MedStatCardCode = :mscc and M.MedDeviceAmount is not null
            SQL,
[ ':mscc' => $this->visitPatient[0]->medStatCardId ], PDO::FETCH_OBJ ); if (!empty($this->visitPatient[0]->IMN)) { foreach ($this->visitPatient[0]->IMN as $imn) { $imn->json = safe_json_decode(str_replace(["\n", "\r", "\t"],"", $imn->json)); $imn->json->serialNumber = $imn->serialnumber; $imn->json->model = $imn->model; $imn->json->dateManufactured = $imn->releasedate; } } $this->visitPatient[0]->medications = selectSql( $this->db, <<<SQL
            SELECT
                M.MedPurposeCode "id",
                cl.uuid,
                CRVСANCEL.code "rejectCode",
                M.json
            FROM
                MedPurposeDepartment MPD
            JOIN MedPurpose M on M.MedPurposeDepartmentCode = MPD.MedPurposeDepartmentCode
            LEFT JOIN CiszResourceValue CRVСANCEL ON CRVСANCEL.CiszResourceValueCode = M.CiszResourceCodeCancelCause
            LEFT JOIN CiszLink CL on CL.TableName = 'MedicationRequestStat' and CL.PrimaryKey = M.MedPurposeCode and CL.Type = 1
            WHERE MPD.MedStatCardCode = :mscc and M.Amount is not null
            SQL,
[ ':mscc' => $this->visitPatient[0]->medStatCardId ], PDO::FETCH_OBJ ); if (!empty($this->visitPatient[0]->medications)) { foreach ($this->visitPatient[0]->medications as $medication) { $medication->json = safe_json_decode(str_replace(["\n", "\r", "\t"],"", $medication->json)); } } $diags = selectSql( $this->db, <<<SQL
            SELECT
                MLG.diagnosisType - 1 "diagType",
                MD1.cipher1 "diagnosisCipher",
                MLG.medDiagnosisCode "diagnosisId",
                null "note"
            FROM
                MedLogDiagnosis MLG
            JOIN MedDiagnosis MD1 on MD1.medDiagnosisCode = MLG.medDiagnosisCode
            WHERE MLG.medLogCode = :mlg
            UNION ALL
            SELECT
                MSCD.diagnosisType "diagType",
                MD.cipher1 "diagnosisCipher",
                MSCD.medDiagnosisCode "diagnosisId",
                MSCD.clinicaldiagnosis "note"
            FROM
                MedStatCardDiagnosis MSCD
            JOIN MedDiagnosis MD on MD.medDiagnosisCode = MSCD.medDiagnosisCode
            WHERE MSCD.medStatCardCode = :mscc
            SQL,
[ ':mlg' => $this->visitPatientId, ':mscc' => $this->visitPatient[0]->medStatCardId ], PDO::FETCH_OBJ ); foreach ($diags as $diag) { switch ($diag->diagType) { case 1: $this->visitPatient[0]->preleminaryDiag ?? $this->visitPatient[0]->preleminaryDiag = new stdClass(); $this->visitPatient[0]->preleminaryDiag->main = $diag->diagnosisCipher; $this->visitPatient[0]->preleminaryDiag->diagnosisId = $diag->diagnosisId; $this->visitPatient[0]->preleminaryDiag->note = $this->visitPatient[0]->clinicalNote; $this->visitPatient[0]->preleminaryDiag->diagDate = ((new DateTime($this->visitPatient[0]->visitDate))->setTime(0, 0, 0))->format('c'); break; case 2: case 3: if ($this->visitPatient[0]->outDate) { $this->visitPatient[0]->finalDiag ?? $this->visitPatient[0]->finalDiag = new stdClass(); $this->visitPatient[0]->finalDiag->main = $diag->diagnosisCipher; $this->visitPatient[0]->finalDiag->diagnosisId = $diag->diagnosisId; $this->visitPatient[0]->finalDiag->note = $diag->note; $this->visitPatient[0]->finalDiag->diagDate = ((new DateTime($this->visitPatient[0]->visitDate))->setTime(0, 0, 0))->format('c'); } $this->visitPatient[0]->clinicalDiag ?? $this->visitPatient[0]->clinicalDiag = new stdClass(); $this->visitPatient[0]->clinicalDiag->main = $diag->diagnosisCipher; $this->visitPatient[0]->clinicalDiag->diagnosisId = $diag->diagnosisId; $this->visitPatient[0]->clinicalDiag->note = $diag->note; $this->visitPatient[0]->clinicalDiag->diagDate = ((new DateTime($this->visitPatient[0]->visitDate))->setTime(0, 0, 0))->format('c'); break; case 4: break; case 5: $this->visitPatient[0]->pathoDiag ?? $this->visitPatient[0]->pathoDiag = new stdClass(); $this->visitPatient[0]->pathoDiag->main = $diag->diagnosisCipher; $this->visitPatient[0]->pathoDiag->diagnosisId = $diag->diagnosisId; $this->visitPatient[0]->pathoDiag->note = $diag->note; break; case 6: $this->visitPatient[0]->pathoDiag ?? $this->visitPatient[0]->pathoDiag = new stdClass(); $this->visitPatient[0]->pathoDiag->additional = $diag->diagnosisCipher; $this->visitPatient[0]->pathoDiag->diagnosisId = $diag->diagnosisId; $this->visitPatient[0]->pathoDiag->note = $diag->note; break; case 0: $this->visitPatient[0]->previousDiag ?? $this->visitPatient[0]->previousDiag = new stdClass(); $this->visitPatient[0]->previousDiag->main = $diag->diagnosisCipher; $this->visitPatient[0]->previousDiag->diagnosisId = $diag->diagnosisId; $this->visitPatient[0]->previousDiag->note = $this->visitPatient[0]->preNote; $this->visitPatient[0]->previousDiag->diagDate = (((new DateTime($this->visitPatient[0]->visitDate))->modify('-1 day'))->setTime(0, 0, 0))->format('c'); break; } } $this->patientId = $this->visitPatient[0]->patientId; } } public function loadMedLogSend(): void { $this->visitPatient = selectSql( $this->db, <<<SQL
            SELECT
                MLS.MedLogSendCode "visitPatientId",
                MLS.documentDate "visitDate",
                MLS.medPatientCode "mpc",
                MLS.sendgoal "goal",
                MLS.medDoctorCode "doctorId",
                MLS.sendtype "type",
                MLS.note "note",
                MLS.startactiondate "periodStart",
                MLS.finishactiondate "periodEnd",
                CRV.code "serviceCode",
                CRV1.code "serviceCategory",
                CRV2.code "speciality",
                MLS.patientInstruction "patientInstruction",
                case coalesce(MLS.priority,1)
                    WHEN 1 then 'routine'
                    WHEN 2 then 'urgent'
                    WHEN 3 then 'asap'
                end "priority",
                null "addService",
                1 "visitCase",
                1 "visitMark",
                1 "serviceForm",
                1 "visitPlace",
                MD.Cipher1 "diagnosisCipher",
                MLS.medDiagnosisCode "diagnosisId",
                CRV3.Code "refusalCode",
                MLS.rejectDate "refusalDate",
                MLS.sendType "sendType",
                MLS.medPatientCode "patientId",
                MLS.departmentCodeStudy "department",
                MLS.EnterpriseCode "enterprise",
                MC.OnDate "couponDate",
                MC.VisitTime "couponTime",
                MC.MedDoctorCode "couponDoctorId"
            FROM
                MedLogSend MLS
            LEFT JOIN CiszResourceValue CRV on crv.ciszResourceValueCode = MLS.ciszresourcevaluecodeService
            LEFT JOIN CiszResourceValue CRV1 on crv1.ciszResourceValueCode = MLS.ciszresourcevaluecodeServiceCategory
            LEFT JOIN CiszResourceValue CRV2 on crv2.ciszResourceValueCode = MLS.ciszresourcevaluecodeSpecialization
            LEFT JOIN CiszResourceValue CRV3 on CRV3.ciszResourceValueCode = MLS.ciszresourcevaluecoderejectcause
            LEFT JOIN MedDiagnosis MD on MD.medDiagnosisCode = MLS.medDiagnosisCode
            LEFT JOIN MedCoupon MC ON MC.MedCouponCode = MLS.MedCouponCode
            WHERE MLS.MedLogSendCode = :mls
SQL,
[ ':mls' => $this->visitPatientId ], PDO::FETCH_OBJ ); if (isset($this->visitPatient)) { $this->patientId = $this->visitPatient[0]->mpc; } $this->visitPatient[0]->addService = selectSql( $this->db, <<<SQL
            SELECT
                crv.code "code",
                crv.name "description"
            FROM
                MedLogSendAddService MLSAS
            JOIN CiszResourceValue CRV on crv.ciszResourceValueCode = MLSAS.ciszresourcevaluecodeaddService
            WHERE MLSAS.MedLogSendcode = :mlsc
SQL,
[ ':mlsc' => $this->visitPatientId ], PDO::FETCH_OBJ ); if ($this->visitPatient[0]->couponDoctorId) { $this->visitPatient[array_key_first($this->visitPatient)]->practitioners = selectSql($this->db, <<<SQL
        SELECT
            MD.MedDoctorCode AS "doctorId",
            MD.ManCode AS "manId",
            M.SurName AS "surName",
            M.Name AS "name",
            M.SecondName AS "secondName",
            MPS.PersonalNumber AS "personalNumber",
            MPS.dateofissue AS "dateOfIssue",
            coalesce(MPS.sex, 0) AS sex,
            MPS.DateOfBirth AS "dateOfBirth",
            MPS.PersonalNumber AS "identificationNumber"
        FROM MedDoctor MD
            JOIN Man M ON M.ManCode = MD.ManCode
            LEFT JOIN ManPassport MPS ON MPS.ManCode = M.ManCode
        WHERE
            MD.MedDoctorCode = :doctorId
        SQL,
[ ':doctorId' => $this->visitPatient[0]->couponDoctorId ], PDO::FETCH_OBJ ); } } public function loadMedStatOperation():void { $this->visitPatient = selectSql( $this->db, <<<SQL
            SELECT
                MSCO.MedStatCardOperationCode "visitPatientId",
                MSC.MedPatientCode "patientId",
                MO.CipherNCSP "operationCodeCisz",
                MSCO.Note "note",
                MD.Cipher1 "diagnosisBeforeCipher",
                MD2.Cipher1 "diagnosisAfterCipher",
                MSCO.OperationStartTime "startDate",
                MSCO.OperationTime "endDate",
                MSCO.MedDiagnosisCodeBefore "diagBeforeId",
                MSCO.MedDiagnosisCodeAfter "diagAfterId",
                MSCO.CiszDiagnosisExtraCodeBefore "diagBeforeExtraId",
                MSCO.CiszDiagnosisExtraCodeAfter "diagAfterExtraId",
                MSCO.CiszResourceValueCodeAnesthesiaType "anesthesiaId",
                MO.Name "operationName",
                MSCO.OperationStartTime::date "visitDate",
                1 "visitCase",
                1 "visitMark",
                1 "serviceForm",
                1 "visitPlace",
                D.CiszGuid "locationUuid"
            FROM MedStatCardOperation MSCO
                JOIN MedOperation MO ON MO.MedOperationCode = MSCO.MedOperationCode
                LEFT JOIN MedDiagnosis MD ON MD.MedDiagnosisCode = MSCO.MedDiagnosisCodeBefore
                LEFT JOIN MedStatCard MSC ON MSC.MedStatCardCode = MSCO.MedStatCardCode
                LEFT JOIN MedDiagnosis MD2 ON MD2.MedDiagnosisCode = MSCO.MedDiagnosisCodeAfter
                LEFT JOIN Department D ON D.DepartmentCode = MSCO.DepartmentCode
            WHERE MSCO.MedStatCardOperationCode = :mao
            SQL,
[ ':mao' => $this->visitPatientId ], PDO::FETCH_OBJ); $this->patientId = $this->visitPatient[0]->patientId; $this->visitPatient[array_key_first($this->visitPatient)]->htmData = selectSql($this->db, <<<SQL
        SELECT
            MAO.MedStatCardOperationCode AS "visitPatientId",
            HP.Name AS "documentName",
            HU.Name AS "name",
            coalesce(nullif(hu.LongValue, ''), HU.Value) AS "value",
            coalesce(HU.RowIndex, 0) AS "rowIndex"
        FROM (
            SELECT
                *
            FROM
                MedVisitDocument
            WHERE
                MedStatCardOperationCode = :mao
            LIMIT 1
        ) MAO
            JOIN HtmPage HP ON HP.HtmPageCode = MAO.HtmPageCode
            JOIN HtmUnit HU ON HU.HtmPageCode = MAO.HtmPageCode
        ORDER BY HP.CreateTime DESC, coalesce(HU.RowIndex, 0)
        SQL,
[ ':mao' => $this->visitPatientId ], PDO::FETCH_OBJ ); $this->visitPatient[array_key_first($this->visitPatient)]->practitioners = selectSql($this->db, <<<SQL
        SELECT
            MD.MedDoctorCode AS "doctorId",
            MD.ManCode AS "manId",
            M.SurName AS "surName",
            M.Name AS "name",
            M.SecondName AS "secondName",
            MPS.PersonalNumber AS "personalNumber",
            MPS.dateofissue AS "dateOfIssue",
            coalesce(MPS.sex, 0) AS sex,
            MPS.DateOfBirth AS "dateOfBirth",
            MAOT.ciszresourcevaluecoderole AS "role",
            MAOT.StartTime AS "startTime",
            MAOT.FinishTime AS "finishTime",
            false AS "isNurse",
            MPS.PersonalNumber AS "identificationNumber"
        FROM
            MedStatCardOperationTeam MAOT
            JOIN MedDoctor MD ON MD.MedDoctorCode = MAOT.MedDoctorCode
            JOIN Man M ON M.ManCode = MD.ManCode
            LEFT JOIN ManPassport MPS ON MPS.ManCode = M.ManCode
        WHERE
            MAOT.MedStatCardOperationCode = :mao

            UNION ALL

        SELECT
            MD.BuhMolCode AS "doctorId",
            MD.ManCode AS "manId",
            M.SurName AS "surName",
            M.Name AS "name",
            M.SecondName AS "secondName",
            MPS.PersonalNumber AS "personalNumber",
            MPS.dateofissue AS "dateOfIssue",
            coalesce(MPS.sex, 0) AS sex,
            MPS.DateOfBirth AS "dateOfBirth",
            MAOT.ciszresourcevaluecoderole AS "role",
            MAOT.StartTime AS "startTime",
            MAOT.FinishTime AS "finishTime",
            true AS "isNurse",
            MPS.PersonalNumber AS "identificationNumber"
        FROM
            MedStatCardOperationTeam MAOT
            JOIN BuhMol MD ON MD.BuhMolCode = MAOT.BuhMolCode
            JOIN Man M ON M.ManCode = MD.ManCode
            LEFT JOIN ManPassport MPS ON MPS.ManCode = M.ManCode
        WHERE
            MAOT.MedStatCardOperationCode = :mao
        SQL,
[ ':mao' => $this->visitPatientId ], PDO::FETCH_OBJ ); } public function loadMedAmbulOperation(): void { $this->visitPatient = selectSql( $this->db, <<<SQL
            SELECT
                MAO.MedAmbulOperationCode               "visitPatientId",
                MAO.MedPatientCode                      "patientId",
                MO.CipherNCSP                           "operationCodeCisz",
                MAO.Description                         "note",
                MD.Cipher1                              "diagnosisBeforeCipher",
                MD2.Cipher1                             "diagnosisAfterCipher",
                MAO.OperationDate                       "startDate",
                MAO.OperationDateFinish                 "endDate",
                MAO.MedDiagnosisCode                    "diagBeforeId",
                MAO.MedDiagnosisCodeAfter               "diagAfterId",
                MAO.CiszDiagnosisExtraCode              "diagBeforeExtraId",
                MAO.CiszDiagnosisExtraCodeAfter         "diagAfterExtraId",
                MAO.ciszresourcevaluecodeanesthesiatype "anesthesiaId",
                MO.Name                                 "operationName",
                MAO.OperationDate::date                 "visitDate",
                1                                       "visitCase",
                1                                       "visitMark",
                1                                       "serviceForm",
                1                                       "visitPlace",
                D.CiszGuid                              "locationUuid"
            FROM
                MedAmbulOperation MAO
            JOIN MedOperation MO ON MO.MedOperationCode = MAO.MedOperationCode
                AND EXISTS(
                    SELECT
                    CRV.Code
                    FROM CiszResourceValue CRV
                    JOIN CiszResource CR ON CR.CiszResourceCode = CRV.CiszResourceCode AND CR.Identifier = 'SurgicalInterventions'
                    WHERE CRV.Code = MO.CipherNCSP
                )
            LEFT JOIN MedDiagnosis MD ON MD.MedDiagnosisCode = MAO.MedDiagnosisCode
            LEFT JOIN MedDiagnosis MD2 ON MD2.MedDiagnosisCode = MAO.MedDiagnosisCodeAfter
            LEFT JOIN Department D ON D.DepartmentCode = MAO.DepartmentCode
            WHERE MAO.MedAmbulOperationCode = :mao
SQL,
[ ':mao' => $this->visitPatientId ], PDO::FETCH_OBJ ); $this->patientId = $this->visitPatient[0]->patientId; $this->visitPatient[array_key_first($this->visitPatient)]->htmData = selectSql($this->db, <<<SQL
        SELECT
            MAO.MedAmbulOperationCode AS "visitPatientId",
            HP.Name AS "documentName",
            HU.Name AS "name",
            coalesce(nullif(hu.LongValue, ''), HU.Value) AS "value",
            coalesce(HU.RowIndex, 0) AS "rowIndex"
        FROM (
            SELECT
                *
            FROM
                MedVisitDocument
            WHERE
                MedAmbulOperationCode = :mao
            LIMIT 1
        ) MAO
            JOIN HtmPage HP ON HP.HtmPageCode = MAO.HtmPageCode
            JOIN HtmUnit HU ON HU.HtmPageCode = MAO.HtmPageCode
        ORDER BY HP.CreateTime DESC, coalesce(HU.RowIndex, 0)
        SQL,
[ ':mao' => $this->visitPatientId ], PDO::FETCH_OBJ ); $this->visitPatient[array_key_first($this->visitPatient)]->practitioners = selectSql($this->db, <<<SQL
        SELECT
            MD.MedDoctorCode AS "doctorId",
            MD.ManCode AS "manId",
            M.SurName AS "surName",
            M.Name AS "name",
            M.SecondName AS "secondName",
            MPS.PersonalNumber AS "personalNumber",
            MPS.dateofissue AS "dateOfIssue",
            coalesce(MPS.sex, 0) AS sex,
            MPS.DateOfBirth AS "dateOfBirth",
            MAOT.ciszresourcevaluecoderole AS "role",
            MAOT.StartTime AS "startTime",
            MAOT.FinishTime AS "finishTime",
            false AS "isNurse",
            MPS.PersonalNumber AS "identificationNumber"
        FROM
            MedAmbulOperationTeam MAOT
            JOIN MedDoctor MD ON MD.MedDoctorCode = MAOT.MedDoctorCode
            JOIN Man M ON M.ManCode = MD.ManCode
            LEFT JOIN ManPassport MPS ON MPS.ManCode = M.ManCode
        WHERE
            MAOT.MedAmbulOperationCode = :mao

            UNION ALL

        SELECT
            MD.BuhMolCode AS "doctorId",
            MD.ManCode AS "manId",
            M.SurName AS "surName",
            M.Name AS "name",
            M.SecondName AS "secondName",
            MPS.PersonalNumber AS "personalNumber",
            MPS.dateofissue AS "dateOfIssue",
            coalesce(MPS.sex, 0) AS sex,
            MPS.DateOfBirth AS "dateOfBirth",
            MAOT.ciszresourcevaluecoderole AS "role",
            MAOT.StartTime AS "startTime",
            MAOT.FinishTime AS "finishTime",
            true AS "isNurse",
            MPS.PersonalNumber AS "identificationNumber"
        FROM
            MedAmbulOperationTeam MAOT
            JOIN BuhMol MD ON MD.BuhMolCode = MAOT.BuhMolCode
            JOIN Man M ON M.ManCode = MD.ManCode
            LEFT JOIN ManPassport MPS ON MPS.ManCode = M.ManCode
        WHERE
            MAOT.MedAmbulOperationCode = :mao
        SQL,
[ ':mao' => $this->visitPatientId ], PDO::FETCH_OBJ ); } public function loadTemporaryDisability($temporaryDisabilityId = null) { $this->temporaryDisability = selectSql( $this->db, <<<SQL
            SELECT
                MH.MedHospitalCode AS "id",
                MH.EnterpriseCode AS "enterpriseId",
                MH.HospitalType AS "hospitalType",
                MH.MedPatientCode AS "patientId",
                MH.MedDoctorOpenCode AS "doctorOpenCode",
                MH.MedDoctorCloseCode AS "doctorCloseCode",
                MH.StartDate AS "startDate",
                MH.FinishDate AS "finishDate",
                MH.HospitalDay AS "hospitalDay",
                MH.MedDiagnosisPrimaryCode AS "diagnosisPrimaryId",
                MD_Primary.Cipher1 AS "primaryDiagCipher",
                MH.MedDiagnosisFinalCode AS "diagnosisFinalId",
                MD_Final.Cipher1 AS "finalDiagCipher",
                MH.MedDiagnosisTerminalCode AS "diagnosisTerminalId",
                MD_Terminal.Cipher AS "diagnosisTerminalCode",
                MH.EnterpriseCodeOut AS "enterpriseOutId",
                MH.MedHelpKindCode AS "helpTypeId",
                MH.DepartmentCode AS "departmentId",
                MH.GiveDate AS "giveDate",
                MH.FioReceived AS "fioReceived",
                MH.EnterpriseCodeReceived AS "enterpriseReceivedId",
                MH.UniDictCodeProfessionReceived AS "professionReceivedId",
                MH.CasesCount AS "casesCount",
                MH.MedPhantomCode AS "phantomId",
                MH.StartHospitalDate AS "startHospitalDate",
                MH.Checked AS "checked",
                MH.ManCodeReceived AS "manReceivedId",
                MH.ChangeTime AS "changeTime",
                MH.Result AS "result",
                MH.WorkStartDate AS "workStartDate",
                MH.MeetKindStart AS "meetKindStart",
                MH.MeetKindFinish AS "meetKindFinish",
                MH.PatientEmployment AS "patientEmployment",
                MH.MedHospitalCodePrior AS "hospitalCodePrior",
                MH.UniDictCodeTempDisabilityType AS "tempDisabilityType",
                UD.Code AS "tempDisabilityTypeCode",
                MH.StartDateMse AS "startDateMse",
                MH.FinishDateMse AS "finishDateMse",
                MH.ConclusionMrec AS "conclusionMrec",
                MH.MedDoctorCodeChiefMrec AS "doctorIdChiefMrec",
                MH.MedDoctorChiefMrec_Fio AS "doctorChiefMrecFio",
                MH.Note AS "note",
                MHN.DocumentSeries "documentSeries",
                MHN.DocumentNumber "documentNumber",
                MH.MedDoctorCodeChief "chiefId",
                MPass.PersonalNumber "chiefPersonalNumber",
                MHN.TreatmentMode "treatmentId"
            FROM MedHospital MH
                LEFT JOIN MedHospitalNext MHN ON MHN.MedHospitalCode = MH.MedHospitalCode
                                  AND MHN.Position = 0
                lEFT JOIN MedDiagnosisTerminal MDT ON MDT.MedDiagnosisTerminalCode = MH.MedDiagnosisTerminalCode
                LEFT JOIN MedDiagnosis MD_Primary ON MD_Primary.MedDiagnosisCode = MH.MedDiagnosisPrimaryCode
                LEFT JOIN MedDiagnosis MD_Final ON MD_Final.MedDiagnosisCode = MH.MedDiagnosisFinalCode
                LEFT JOIN MedDiagnosisTerminal MD_Terminal ON MD_Terminal.MedDiagnosisTerminalCode = MH.MedDiagnosisTerminalCode
                lEFT JOIN UniDict UD ON UD.UniDictCode = MH.UniDictCodeTempDisabilityType AND UD.DictNumber = 54
                LEFT JOIN MedDoctor MDCC ON MDCC.MedDoctorCode = MH.MedDoctorCodeChief
                LEFT JOIN ManPassport MPass ON MPass.ManCode = MDCC.ManCode
            WHERE MH.MedHospitalCode = :id
            SQL,
[ ':id' => $temporaryDisabilityId ? $temporaryDisabilityId : $this->visitPatientId ], PDO::FETCH_OBJ ); $this->patientId = $this->temporaryDisability[0]->patientId; } public function loadDayHospital(bool $isCheck = false) { $this->visitPatient = selectSql( $this->db, <<<SQL
            SELECT
                MDH.MedDayHospitalCode AS "visitPatientId",
                MDH.MedPatientCode AS "patientId",
                MDH.DirectDate AS "visitDate",
                MDH.MedDoctorCode AS "doctorId",
                MDH.MedDiagnosisCode AS "diagnosisId",
                MDH.MedDiagnosisCodeFinal AS "diagnosisIdFinal",
                MDH.StartDate "occurrenceStart",
                MDH.FinishDate "occurrenceEnd",
                MDH.CotDay "cotDay",
                null "purpose",
                null "preleminaryDiag",
                null "clinicalDiag",
                null "finalDiag",
                null "diagCipher",
                null "addDiagCipher",
                CRV.Code "payType",
                CRV1.Code "cancerStage",
                CRV2.Code "medCareType",
                MDH.InsuranceStartDate "insuranceStart",
                MDH.InsuranceFinishDate "insuranceFinish",
                MDH.InsuranceNumber "insuranceNumber",
                MDH.InsuranceOrganization "insuranceOrg",
                MDH.InsuranceIssueDate "insuranceIssue",
                MDH.Note "note",
                MDH.SendGoalText "reasonText",
                null "violation",
                MD.Cipher1 "cipherClinical",
                MD1.Cipher1 "cipherFinal",
                MDH.MedLogSendCode "requestCode",
                MDH.Issue "issue"
            FROM
                MedDayHospital MDH
                LEFT JOIN MedDiagnosis MD ON md.MedDiagnosisCode = MDH.MedDiagnosisCode
                LEFT JOIN MedDiagnosis MD1 on md1.MedDiagnosisCode = MDH.MedDiagnosisCodeFinal
                LEFT JOIN CiszResourceValue CRV on CRV.CiszResourceValueCode = MDH.CiszResourceValueCodePayType
                LEFT JOIN CiszResourceValue CRV1 on CRV.CiszResourceValueCode = MDH.CiszResourceValueCodeCancerStage
                LEFT JOIN CiszResourceValue CRV2 on CRV.CiszResourceValueCode = MDH.CiszResourceValueCodeMedCareType
            WHERE MDH.MedDayHospitalCode = :mdhc
            SQL,
[ ':mdhc' => $this->visitPatientId, ], PDO::FETCH_OBJ ); $this->visitPatient[0]->violation = selectSql( $this->db, <<<SQL
            SELECT
               MDHV.note "note",
               MDHV.violationTime "violationDate"
            FROM
                MedDayHospitalViolation MDHV
            WHERE MDHV.MedDayHospitalCode = :mdhc
            ORDER BY 2
            SQL,
[ ':mdhc' => $this->visitPatientId, ], PDO::FETCH_OBJ ); $this->visitPatient[0]->purpose = selectSql( $this->db, <<<SQL
            SELECT
               MDHP.meddayhopsitalpurposecode "purposeId"
            FROM
                MedDayHopsitalPurpose MDHP
            WHERE MDHP.MedDayHospitalCode = :mdhc
            SQL,
[ ':mdhc' => $this->visitPatientId, ], PDO::FETCH_OBJ ); $this->patientId = $this->visitPatient[0]->patientId; if ($this->visitPatient[0]->purpose && !$isCheck){ $tmp = $this->visitPatientId; foreach ($this->visitPatient[0]->purpose as $purp) { $this->visitPatientId = $purp->purposeId; $this->createOrganization(); $this->createPatient(); $this->createPractitioner(); self::loadMedication(); self::createMedicationOrder(); self::createCancelMedicationOrder(); $this->medication = null; } $this->visitPatientId = $tmp; } $this->visitPatient[0]->clinicalDiag = (object)[ 'main' => $this->visitPatient[0]->cipherClinical ?? null, 'diagnosisId' => $this->visitPatient[0]->diagnosisId, 'additional' => null, ]; $this->visitPatient[0]->finalDiag = (object)[ 'main' => $this->visitPatient[0]->cipherFinal ?? null, 'diagnosisId' => $this->visitPatient[0]->diagnosisIdFinal, 'additional' => null, ]; } public function loadVaccination() { $this->visitPatient = selectSql( $this->db, <<<SQL
                SELECT
                    MIL.MedInoculateLogCode "id",
                    MIL.PlanDate "planDate",
                    MIL.MedInoculateCode "medInoculateCode",
                    MIL.MedPatientCode "patientId",
                    MIL.RuleDate "ruleDate",
                    MIL.InoculateDate "inoculateDate",
                    MIL.InputPlace "inputPlace",
                    MIL.InoculateReason "inoculateReason",
                    MIL.ReactionResult "reactionResult",
                    MIL.TestResult "testResult",
                    MIL.FailReason "failReason",
                    MIL.TestTypeResult "testTypeResult",
                    MIL.TubVaccineResult "tubVaccineResult",
                    MIL.ValueResult "valueResult",
                    MIL.BuhMolCode "buhMolCode",
                    MIL.InoculateDateIndividual "dateIndividual",
                    MIL.InputPlaceSide "inputPlaceSide",
                    MIL.Note "note",
                    MIL.Phone "phone",
                    MIL.PhoneRefusal "phoneRefusal",
                    MIL.DepartmentCode "departmentId",
                    MIL.CiszResourceValueCodeInjectionSite "ciszInjectionSiteId",
                    CRIS.Code "ciszInjectionSiteCode",
                    MIL.CiszResourceValueCodeInjectionMethod "ciszInjectionMethodId",
                    CRIM.Code "ciszInjectionMethodCode",
                    MIL.CiszResourceValueCodePaid "ciszPaidId",
                    CRP.Code "ciszPaidCode",
                    MIL.reaction30min "reaction30min",
                    MIL.RecommendedDoseCount "recomendedDose",
                    MIL.CiszResourceValueCodeStatus "recomendationStatusId",
                    CRR.Code "recomendationStatusCode",
                    MIL.Description "recNote",
                    COALESCE(OS.ObservationsObjective, '[]') "objectiveExaminations",
                    COALESCE(VS.VitalSigns, '[]') "vitalSigns",
                    COALESCE(I.Infections, '[]') "infections",
                    MIL.RuleDateFinish  "ruleDateFinish",
                    MVP. MedVaccinePartyCode "vaccinePartyId",
                    MV.MedVaccineCode "vaccineId",
                    MVP.ControlNumber "controlNumber",
                    MVP.Serial "serial",
                    MVP.validTerm "expireDate",
                    MVM.Amount "doseSize",
                    MV.DoseSize "doseSizeVaccine",
                    MV.doseMeasure "doseMeasure",
                    MV.Json "json",
                    CRI.Code "inoculateTypeId"
                FROM MedInoculateLog MIL
                LEFT JOIN CiszResourceValue CRIS ON CRIS.CiszResourceValueCode = MIL.CiszResourceValueCodeInjectionSite
                LEFT JOIN CiszResourceValue CRIM ON CRIM.CiszResourceValueCode = MIL.CiszResourceValueCodeInjectionMethod
                LEFT JOIN CiszResourceValue CRP ON CRP.CiszResourceValueCode = MIL.CiszResourceValueCodePaid
                LEFT JOIN CiszResourceValue CRVS ON CRVS.CiszResourceValueCode = MIL.CiszResourceValueCodeStatus
                LEFT JOIN EnterpriseStructureInfo ESIP ON ESIP.EnterpriseStructureInfoCode = MIL.DepartmentCode
                LEFT JOIN MedVaccineMove MVM ON MVM.MedInoculateLogCode = MIL.MedInoculateLogCode
                LEFT JOIN MedVaccineParty MVP ON MVP.MedVaccinePartyCode = MVM.MedVaccinePartyCode
                LEFT JOIN MedVaccine MV ON MV.MedVaccineCode = MVP.MedVaccineCode
                LEFT JOIN MedInoculate MI ON MI.MedInoculateCode = MIL.MedInoculateCode
                LEFT JOIN CiszResourceValue CRI ON CRI.CiszResourceValueCode = MI.CiszResourceValueCodeType
                LEFT JOIN CiszResourceValue CRR ON CRR.CiszResourceValueCode = MIL.CiszResourceValueCodeStatus
                LEFT JOIN LATERAL (
                    SELECT json_agg(
                        json_build_object(
                            'observationObjectiveId', MILI.MedInoculateLogInspectionCode,
                            'observationObjectiveType', MILI.Type,
                            'observationObjectiveLogId', MILI.MedInoculateLogCode,
                            'observationObjectiveString', MILI.Description
                        )
                    ) AS ObservationsObjective
                    FROM MedInoculateLogInspection MILI
                    WHERE MILI.MedInoculateLogCode = MIL.MedInoculateLogCode
                ) OS ON TRUE
                LEFT JOIN LATERAL (
                     SELECT json_agg(
                         json_build_object(
                             'vitalSignId', MILVS.MedInoculateLogVitalSignsCode,
                             'vitalSignType', MILVS.Type,
                             'vitalSignLogId', MILVS.MedInoculateLogCode,
                             'vitalSignNumber', MILVS.ValueNumber
                         )
                     ) AS VitalSigns
                     FROM MedInoculateLogVitalSigns MILVS
                     WHERE MILVS.MedInoculateLogCode = MIL.MedInoculateLogCode
                ) VS ON TRUE
                LEFT JOIN LATERAL (
                    SELECT json_agg(
                        json_build_object(
                            'infectionCode', MINF.MedInfectionCode,
                            'ciszResourceValueInfectionCode', MINF.CiszResourceValueCodeInfection
                        )
                    ) AS Infections
                    FROM MedInoculateInfection MIF
                    LEFT JOIN MedInfection MINF ON MINF.MedInfectionCode = MIF.MedInfectionCode
                    WHERE MIF.MedInoculateCode = MI.MedInoculateCode
                ) I ON TRUE
                WHERE MIL.MedInoculateLogCode = :id
            SQL,
[ ':id' => $this->visitPatientId, ], PDO::FETCH_OBJ ); $this->patientId = $this->visitPatient[0]->patientId; } public function loadProcProcedure() { if ($this->entity === 'MedProcedure') { $procedureId = $this->visitPatientId; } else { $procedure = safe_json_decode(self::getHtmDataValue($this->visitPatient[array_key_first($this->visitPatient)]->htmData, ['ProcedureObj'])); $procedureId = $procedure->id; } if (!isset($procedureId)) { return; } $result = selectSql( $this->db, <<<SQL
        SELECT
            MSPL.MedSanProcLogCode "id",
            MSPL.DocumentNumber "documentNumber",
            MSPL.MedPatientCode "patientId",
            MSPL.DocumentDate "visitDate",
            MSLR.CiszResourceValueCodeServiceCategory "healthCareId",
            CRV.Code "healthCareCode",
            MSPL.StartDate "startDate",
            MSPL.FinishDate "finishDate",
            MSLR.DepartmentCode "departmentId",
            D.CiszGuid "departmentGuid",
            MSLR.MedDiagnosisCode "diagnosisId",
            MD.Cipher1 "diagnosisCode",
            MSP.Name "procedureName",
            MSLR.Amount "amount",
            MSP.AmountPerCourse "amountPerCourse",
            MSPLRA2.AnatomicCodes "anatomic",
            MAX(60/MWFP.VisitNumberOnHour) AS "visitTime",
            MSP.CiszResourceValueCodeMedicalServiceType "ciszNameId",
            MSLR.CiszResourceValueCodeProcResult "resultId",
            CRVRE.Code "resultCode",
            CRVT.Code "ciszNameCode",
            MSLR.Conclusion "recommendation",
            MSLR.Note "note",
            COALESCE(
                (
                SELECT JSONB_AGG(
                    JSONB_BUILD_OBJECT(
                        'paramId', MSPR.CiszResourceValueCodePhysParam,
                        'paramCode', CRVR.Code,
                        'unit', MSPR.CiszResourceValueCodeUnit,
                        'unitCode', CRVU.Code,
                        'paramValue', MSPR.ValueNumber,
                        'operator', MSPR.Comparator
                    )
                )
                FROM MedSanProcRule MSPR
                LEFT JOIN CiszResourceValue CRVR ON CRVR.CiszResourceValueCode = MSPR.CiszResourceValueCodePhysParam
                LEFT JOIN CiszResourceValue CRVU ON CRVU.CiszResourceValueCode = MSPR.CiszResourceValueCodeUnit
                WHERE MSPR.MedSanProcCode = MSP.MedSanProcCode
                ),
                '[]'::jsonb
            ) AS "parameters",
            (MSPL.Attributes & 2) <> 0 "allFinished"
        FROM MedSanProcLog MSPL
        LEFT JOIN MedSanProcLogRow MSLR ON MSPL.MedSanProcLogCode = MSLR.MedSanProcLogCode
        LEFT JOIN CiszResourceValue CRV ON CRV.CiszResourceValueCode = MSLR.CiszResourceValueCodeServiceCategory
        LEFT JOIN MedDiagnosis MD ON MD.MedDiagnosisCode = MSLR.MedDiagnosisCode
        LEFT JOIN MedSanProc MSP ON MSLR.MedSanProcCode = MSP.MedSanProcCode
        LEFT JOIN MedSanProcRule MSPR ON MSPR.MedSanProcCode = MSP.MedSanProcCode
        LEFT JOIN CiszResourceValue CRVR ON CRVR.CiszResourceValueCode = MSPR.CiszResourceValueCodePhysParam
        LEFT JOIN CiszResourceValue CRVT ON CRVT.CiszResourceValueCode = MSP.CiszResourceValueCodeMedicalServiceType
        LEFT JOIN CiszResourceValue CRVU ON CRVU.CiszResourceValueCode = MSPR.CiszResourceValueCodeUnit
        LEFT JOIN CiszResourceValue CRVRE ON CRVRE.CiszResourceValueCode = MSLR.CiszResourceValueCodeProcResult
        LEFT JOIN MedSanProcFeature MSF ON MSF.MedSanProcCode = MSP.MedSanProcCode
        LEFT JOIN MedCouponWorkProf MWFP ON MWFP.MedProfessionCode = MSF.MedProfessionCode
        LEFT JOIN MedCouponWork MW ON MW.MedCouponWorkCode = MWFP.MedCouponWorkCode
        LEFT JOIN Department D ON D.DepartmentCode = MSLR.DepartmentCode
        LEFT JOIN (
            SELECT
                MSPLRA.MedSanProcLogRowCode,
                string_agg(
                    MSPLRA.CiszResourceValueCodeAnatomic, ';'
                    ORDER BY MSPLRA.MedSanProcLogRowCode
                ) AS AnatomicCodes
            FROM MedSanProcLogRowAnatomic MSPLRA
            GROUP BY MSPLRA.MedSanProcLogRowCode
        ) MSPLRA2 ON MSPLRA2.MedSanProcLogRowCode = MSLR.MedSanProcLogRowCode
        WHERE MSPL.MedSanProcLogCode = :id
        GROUP BY
            MSPL.MedSanProcLogCode,
            MSPL.DocumentNumber,
            MSPL.DocumentDate,
            MSLR.CiszResourceValueCodeServiceCategory,
            CRV.Code,
            MSPL.StartDate,
            MSPL.FinishDate,
            MSLR.DepartmentCode,
            D.CiszGuid,
            MSLR.MedDiagnosisCode,
            MD.Cipher1,
            MSP.Name,
            MSLR.Amount,
            MSP.AmountPerCourse,
            MSP.CiszResourceValueCodeMedicalServiceType,
            MSLR.CiszResourceValueCodeProcResult,
            CRVRE.Code,
            CRVT.Code,
            MSLR.Conclusion,
            MSLR.Note,
            MSPLRA2.AnatomicCodes,
            MSP.MedSanProcCode,
            MSPL.Attributes
        SQL,
[':id' => $procedureId], PDO::FETCH_OBJ ); $this->patientId = $result[array_key_first($result)]->patientId; $this->procedurePatient = $result; } public function loadXRayStat() { $xRayId = $this->visitPatientId; $result = selectSql( $this->db, <<<SQL
                SELECT
                    CDE.CiszDocExtraCode "visitPatientId",
                    CDE.MedStatCardDocCode "statCardId",
                    CDE.DocumentType "docType",
                    CDE.Json "json",
                    MSC.MedPatientCode "patientId"
                FROM CiszDocExtra CDE
                INNER JOIN MedStatCardDoc MSCD ON MSCD.MedStatCardDocCode = CDE.MedStatCardDocCode
                INNER JOIN MedStatCard MSC ON MSC.MedStatCardCode = MSCD.MedStatCardCode
                WHERE CDE.MedStatCardDocCode = :id
            SQL,
[':id' => $xRayId], PDO::FETCH_OBJ ); $this->patientId = $result[array_key_first($result)]->patientId; $this->xRay = $result; $this->xRay[array_key_first($this->xRay)]->htmData = selectSql( $this->db, <<<SQL
                SELECT
                    mscd.medstatcarddoccode AS "visitDocumentId",
                    hp."name" AS "documentName",
                    hu."name",
                    coalesce(hu.RowIndex, 0) as "rowIndex",
                    coalesce(nullif(hu.LongValue, ''), hu.Value) AS value
                FROM medstatcardDoc mscd
                    JOIN htmPage hp ON hp.htmPageCode = mscd.htmPageCode
                    JOIN htmUnit hu ON hu.htmPageCode = mscd.htmPageCode
                where mscd.medstatcarddoccode = :visitPatientId
                ORDER BY mscd.documentdate desc, coalesce(hu.RowIndex, 0)
                SQL,
[ ':visitPatientId' => $this->visitPatientId ], PDO::FETCH_OBJ); } public function loadProcStat() { $procedureId = $this->visitPatientId; $result = selectSql( $this->db, <<<SQL
        SELECT
            MSPL.MedSanProcLogCode "id",
            MSPL.DocumentDate "documetDate",
            MSPL.DocumentNumber "documentNumber",
            MSPL.EnterpriseCode "enterpriseId",
            MSPL.Json "json",
            MSPL.MedDoctorCode "doctorId",
            MSPL.MedPatientCode "patientId"
        FROM MedSanProcLog MSPL
        WHERE MSPL.MedSanProcLogCode = :id
        SQL,
[':id' => $procedureId], PDO::FETCH_OBJ ); $this->patientId = $result[array_key_first($result)]->patientId; $this->procedurePatient = $result; } public function loadIzotopStat() { $result = selectSql( $this->db, <<<SQL
SELECT
    MSCD.MedStatcardDocCode AS "visitPatientId",
    CDE.Json AS "json",
    MSC.MedPatientCode AS "patientId"
FROM
    MedStatcardDoc MSCD
    JOIN MedStatCard MSC ON MSC.MedStatCardCode = MSCD.MedStatCardCode
    JOIN CiszDocExtra CDE ON CDE.MedStatcardDocCode = MSCD.MedStatcardDocCode AND CDE.DocumentType = 2
WHERE
    MSCD.MedStatcardDocCode = :visitPatientId
SQL,
[ ':visitPatientId' => $this->visitPatientId ], PDO::FETCH_OBJ ); $this->patientId = $result[array_key_first($result)]->patientId; $this->radioIzotopPatient = $result; } public function loadIzotopStom() { $result = selectSql( $this->db, <<<SQL
SELECT
    MVD.MedVisitDocumentCode AS "visitPatientId",
    CDE.Json AS "json",
    SC.MedPatientCode AS "patientId"
FROM
    MedVisitDocument MVD
    JOIN StomVisit SV ON SV.StomVisitCode = MVD.StomVisitCode
    Join StomCard SC ON SC.StomCardCode = SV.StomCardCode
    JOIN CiszDocExtra CDE ON CDE.MedVisitDocumentCode = MVD.MedVisitDocumentCode AND CDE.DocumentType = 2
WHERE
    MVD.MedVisitDocumentCode = :visitPatientId
SQL,
[ ':visitPatientId' => $this->visitPatientId ], PDO::FETCH_OBJ ); $this->patientId = $result[array_key_first($result)]->patientId; $this->radioIzotopPatient = $result; } public function loadMedicalDevice($code) { $result = selectSql( $this->db, <<<SQL
        SELECT
            MDHP.MedDayHopsitalPurposeCode "id",
            MDHP.MedPatientCode "patientId",
            MDHP.PurposeTime "createDate",
            MDHP.CancelTime "finishDate",
            MDHP.MedDiagnosisCode "diagnosisId",
            MD.Cipher1 "diagnosisCode",
            MDHP.CiszResourceValueCodePrescribeIndication "indicationId",
            CRV_I.Code "indicationCode",
            MDHP.CiszResourceValueCodeMedDevice "nomenclatureId",
            CRV_N.Code "nomenclatureCode",
            MDHP.CiszResourceValueCodeTermOfPurchase "termsId",
            CRV_TP.Code "termsCode",
            MDHP.MedDeviceAmount "amount",
            MDHP.Json "json",
            MDHP.CancelTime "finishDate",
            MDHP.EnterpriseSupplyText "enterpriseText",
            MDHP.EnterpriseCodeSupply "enterpriseId",
            EN.CiszGuid "enterpriseGiud",
            MDHP.Note "note",
            MDHP.MedDoctorCodeCancel IS NOT NULL "isCanceled",
            MDHP.CiszResourceCodeCancelCause "rejectId",
            CRV_C.Code "rejectCode",
            MDHP.IssueDate IS NOT NULL "isSupplied",
            MDHP.DateOfUse "serviceDate",
            MDHP.RecordNumber "logNumber",
            MDHP.CiszResourceValueCodeMedDeviceIssued "nomenclatureSupId",
            CRV_D.Code "nomenclatureSupCode",
            MDHP.ReleaseDate "productionDate",
            MDHP.SerialNumber "serialNumber",
            MDHP.Model "model",
            MDHP.MedDeviceNote "noteDevice",
            CASE WHEN MDHP.MedRelativesCode IS NOT NULL THEN 2 ELSE 1 END "receiverId",
            MDHP.MedRelativesCode "relativeId",
            PR.PassportNumber "passportNumber",
            MDHP.EnterpriseCodeSupplyIssued "organizationIdSup",
            MDHP.EnterpriseSupplyTextIssued "organizationTextSup",
            ENI.CiszGuid "enterpriseSupGiud",
            MDHP.CiszResourceValueCodeTermOfIssue "termsSupId",
            CRV_S.Code "termsSupCode",
            MDHP.MedDeviceAmountIssued "amountSup",
            MDHP.IssueDate "supplyDate",
            MDHP.InstructionIssue "instruction"
        FROM MedDayHopsitalPurpose MDHP
        LEFT JOIN CiszResourceValue CRV_TP ON CRV_TP.CiszResourceValueCode = MDHP.CiszResourceValueCodeTermOfPurchase
        LEFT JOIN CiszResourceValue CRV_N ON CRV_N.CiszResourceValueCode = MDHP.CiszResourceValueCodeMedDevice
        LEFT JOIN CiszResourceValue CRV_C ON CRV_C.CiszResourceValueCode = MDHP.CiszResourceCodeCancelCause
        LEFT JOIN CiszResourceValue CRV_D ON CRV_D.CiszResourceValueCode = MDHP.CiszResourceValueCodeMedDeviceIssued
        LEFT JOIN CiszResourceValue CRV_S ON CRV_S.CiszResourceValueCode = MDHP.CiszResourceValueCodeTermOfIssue
        LEFT JOIN CiszResourceValue CRV_I ON CRV_I.CiszResourceValueCode = MDHP.CiszResourceValueCodePrescribeIndication
        LEFT JOIN EnterpriseNumber EN ON EN.EnterpriseCode = MDHP.EnterpriseCodeSupply
        LEFT JOIN EnterpriseNumber ENI ON ENI.EnterpriseCode = MDHP.EnterpriseCodeSupplyIssued
        LEFT JOIN MedDiagnosis MD ON MD.MedDiagnosisCode = MDHP.MedDiagnosisCode
        LEFT JOIN MedRelatives MR ON MR.MedRelativesCode = MDHP.MedRelativesCode
        LEFT JOIN ManPassport PR ON PR.ManCode = MR.ManCode
        WHERE MDHP.MedDayHopsitalPurposeCode = :id
        SQL,
[':id' => $code], PDO::FETCH_OBJ ); $this->patientId = $result[array_key_first($result)]->patientId; $this->medicalDevice = $result; } public function loadProcStom() { $procedureId = $this->visitPatientId; $result = selectSql( $this->db, <<<SQL
        SELECT
            MVD.MedVisitDocumentCode "id",
            SV.VisitDate "documetDate",
            null "documentNumber",
            SC.EnterpriseCode "enterpriseId",
            CDE.Json "json",
            SV.MedDoctorCode "doctorId",
            SC.MedPatientCode "patientId"
        FROM MedVisitDocument MVD
        JOIN CiszDocExtra CDE ON CDE.MedVisitDocumentCode = MVD.MedVisitDocumentCode AND CDE.DocumentType = 3
        JOIN StomVisit SV ON SV.StomVisitCode = MVD.StomVisitCode
        JOIN StomCard SC ON SC.StomCardCode = SV.StomCardCode
        WHERE MVD.MedVisitDocumentCode = :id
        SQL,
[':id' => $procedureId], PDO::FETCH_OBJ ); $this->patientId = $result[array_key_first($result)]->patientId; $this->procedurePatient = $result; } public function getDocNumberByType(string $docType): string { $request = self::doHttpMethodWithAuth($this->settings,(object)[ 'url' => $this->settings->url . 'fhir/'. '$get-document-id', 'request_content' => json_encode((object)[ 'resourceType' => 'Parameters', 'parameter' => [ (object)[ 'name' => 'document-code', 'valueCoding' => (object)[ 'system' => med_cisz_constant::$valueSet['DigitalDocumentKind'], 'code' => $docType ] ] ] ]) ],'POST'); if (isset($request->parameter)){ return $request->parameter[0]->valueString; } else { return $request->issue[0]->diagnostics; } } public function cancelBundleImport(?object $params = null): object { if (!$params) { throw new Exception( sprintf(med_cisz_constant::ERROR_INVALID_CREATE_BUNDLE_PARAMS_TEXT, 'params'), med_cisz_constant::ERROR_INVALID_CREATE_BUNDLE_PARAMS_CODE ); } $result = null; $this->patientId = $params->patientId ?? null; $this->entity = $params->entity ?? null; if ($params->entity !== 'MedVaccinationRecommendation') { $this->visitPatientId = $params->visitPatientId; } switch ($params->entity) { case 'MedPatient': break; case 'MedVisitPatient': case 'MedInspect': case 'MedDayHospital': case 'MedLogHospital': case 'MedStatCard': case 'StomVisit': case 'MedTherapyStom': case 'MedAmbulOperation': case 'MedVaccinationRecommendation': case 'MedHospitalRequest': case 'MedMedication': case 'MedXRayStat': $bundleId = self::getLinkEntityUUID($this->db, 2, $params->entity, $params->visitPatientId ?? $params->patientId); if (!$bundleId) { throw new Exception( med_cisz_constant::ERROR_LINK_ENTITY_NOT_FOUND_TEXT, med_cisz_constant::ERROR_LINK_ENTITY_NOT_FOUND_CODE ); } $result = $this->doCancelBundle($bundleId); if ($result && !self::extractErrors($result)) { self::deleteLinkUnique($this->db, $params->entity, $params->visitPatientId ?? $params->patientId); } break; case 'MedLogStudyLab': case 'MedLogStudy': case 'MedLogStudyImage': if (!$this->patientId) { $this->patientId = selectSql($this->db, <<<SQL
                        SELECT MedPatientCode "mpc"
                        FROM MedLogStudy
                        WHERE MedLogStudyCode = :mlsc
                    SQL,
[ ':mlsc' => $params->visitPatientId ], PDO::FETCH_OBJ)[0]->mpc; } $data = selectSql($this->db, <<<SQL
                        SELECT Uuid "bundleId",
                               PrimaryKey "primaryKey"
                        FROM CiszLink
                        WHERE TableName LIKE :entity AND PrimaryKey = :id AND Status = 1
                    SQL,
[ ':entity' => ($params->entity === 'MedLogStudy' || $params->entity === 'MedLogStudyLab' || $params->entity === 'MedLogStudyImage') ? $params->entity . '/%' : $params->entity, ':id' => $params->visitPatientId ?? $params->patientId, ], PDO::FETCH_OBJ); foreach ($data as $row) { if (!$row->bundleId) { throw new Exception( med_cisz_constant::ERROR_LINK_ENTITY_NOT_FOUND_TEXT, med_cisz_constant::ERROR_LINK_ENTITY_NOT_FOUND_CODE ); } if (!str_contains($row->bundleId, "(MedLogStudy/") && !str_contains($row->bundleId, "(MedLogStudyLab/") && !str_contains($row->bundleId, "(MedLogStudyImage/")) { $result = $this->doCancelBundle($row->bundleId); } if ($result &&!self::extractErrors($result)) { self::deleteLinkUnique($this->db, $params->entity, $row->primaryKey); } } break; case 'MedProcedure': $data = selectSql($this->db, <<<SQL
                        SELECT Uuid "bundleId",
                               PrimaryKey "primaryKey"
                        FROM CiszLink
                        WHERE TableName LIKE :entity AND PrimaryKey = :id AND Status = 1
                    SQL,
[ ':entity' => 'MedProcedure%', ':id' => $params->visitPatientId, ], PDO::FETCH_OBJ); foreach ($data as $row) { if (!$row->bundleId) { throw new Exception( med_cisz_constant::ERROR_LINK_ENTITY_NOT_FOUND_TEXT, med_cisz_constant::ERROR_LINK_ENTITY_NOT_FOUND_CODE ); } if (!str_contains($row->bundleId, "(MedLogStudy/") && !str_contains($row->bundleId, "(MedLogStudyLab/")) { $result = $this->doCancelBundle($row->bundleId); } if ($result &&!self::extractErrors($result)) { self::deleteLinkUnique($this->db, $params->entity, $row->primaryKey); } } break; case 'MedRadioIzotopStat': case 'MedRadioIzotopStom': $data = selectSql($this->db, <<<SQL
                        SELECT Uuid "bundleId",
                               PrimaryKey "primaryKey"
                        FROM CiszLink
                        WHERE TableName LIKE :entity AND PrimaryKey = :id AND Status = 1
                    SQL,
[ ':entity' => $params->entity . '/%', ':id' => $params->visitPatientId, ], PDO::FETCH_OBJ); foreach ($data as $row) { if (!$row->bundleId) { throw new Exception( med_cisz_constant::ERROR_LINK_ENTITY_NOT_FOUND_TEXT, med_cisz_constant::ERROR_LINK_ENTITY_NOT_FOUND_CODE ); } $result = $this->doCancelBundle($row->bundleId); if ($result &&!self::extractErrors($result)) { self::deleteLinkUnique($this->db, $params->entity, $row->primaryKey); } } break; } return (object) [ 'error' => self::extractErrors($result), 'details' => $result, ]; } public function encodeAndSign(object $data): string { $result = base64_encode(json_encode($data)); $response = self::doHttpMethod($this->settings, (object) [ 'url' => 'http://' . self::getClientIp() . ':8084/sign', 'request_content' => json_encode((object) [ 'data' => $result ]), ], 'POST'); return $response->cms; } public function getNewPatient(?object $params = null) { $identifier = isEmptyProperty($params, 'patientIdentifier'); $patientUuid = isEmptyProperty($params, 'patientUuid'); $type = isEmptyProperty($params, 'docType'); $birthday = isEmptyProperty($params, 'birthday'); $fio = isEmptyProperty($params, 'fio'); $patientOnly = isEmptyProperty($params, 'patientOnly'); if (isEmptyProperty($params, 'finishDate')) { $dateEnd = (new DateTime($params->finishDate))->format('Y-m-t'); } $parameters = []; if ($patientUuid) { $parameters['_id'] = $patientUuid; } if ($identifier) { if ($type) { $parameters['identifier:of-type'] = med_cisz_constant::$valueSet['PersonalDocumentType'] . '|' . $type . '|' . $identifier; } else { $parameters['identifier'] = $identifier; } } if ($birthday) { $parameters['birthdate'] = self::changeDateMonths($birthday, 0); } if ($fio) { $parameters['name'] = trim($fio); } $patientResource = self::doHttpMethodWithAuth($this->settings, (object) [ 'url' => $this->settings->url . 'fhir/Patient', 'param' => $parameters ]); if (($patientResource->total ?? 0) > 1) { $patients = []; $patientInfo = new med_cisz_patientInfo(); foreach ($patientResource->entry ?? [] as $entry) { if (($entry->resource->resourceType ?? null) === 'Patient') { $patientBundle = (object) [ 'id' => $entry->resource->id ?? null, 'entry' => [$entry] ]; $patients[] = $patientInfo->parsePatientGeneral($patientBundle); } } return (object) [ 'isMultiple' => true, 'patients' => $patients ]; } if (($patientResource = self::extractResourceFromBundle($patientResource, 'Patient'))) { $ciszData = getSessionValue('cisz') ?? (object) []; $ciszData->{$patientResource->id} = $patientResource; setSessionValue('cisz', $ciszData); $params->patientUuid = $patientResource->id; if ($patientOnly) { $patientInfo = new med_cisz_patientInfo(); return $patientInfo->parsePatientProfile($patientResource); } return $this->getPatientInfo($params); } return false; } public function getHospitalisationRequests(?object $params = null): array { $identifier = isEmptyProperty($params, 'patientIdentifier'); try { $patientUUID = $this->getPatientUuidFromCisz($identifier, 'personalNumber'); } catch (Exception $e) { if (strpos($e->getMessage(), '404') !== false || strpos($e->getMessage(), 'Not Found') !== false || $e->getCode() == med_cisz_constant::ERROR_RESPONSE_STATUS_CODE) { throw new Exception( 'Невозможно получить информацию. Пациент не зарегистрирован в ЦИСЗ', med_cisz_constant::ERROR_LINK_DATA_NOT_FOUND_CODE ); } throw $e; } if (!$patientUUID) { throw new Exception( 'Невозможно получить информацию. Пациент не зарегистрирован в ЦИСЗ', med_cisz_constant::ERROR_LINK_DATA_NOT_FOUND_CODE ); } $ciszData = getSessionValue('cisz') ?? (object) []; $organizationId = $ciszData->organization_id; $bundle = self::doHttpMethodWithAuth($this->settings, (object) [ 'url' => $this->settings->url . 'fhir/Patient/' . $patientUUID . '/ServiceRequest?', 'param' => [ '_profile' => med_cisz_constant::$structureDefinitions['ServiceRequestHospitalisation'], 'performer' => $organizationId, 'status' => 'active' ] ]); $result = []; $patientInfo = new med_cisz_patientInfo(); foreach ($bundle->entry ?? [] as $entry) { if (($entry->resource->resourceType ?? false) == 'ServiceRequest') { $result[] = $patientInfo->parsePatientHospitalizationReferral($entry->resource); } } return $result; } public function createCiszPatientByIdentifier(object $params): ?array { $identifier = isEmptyProperty($params, 'patientIdentifier'); $patientResource = self::doHttpMethodWithAuth($this->settings, (object) [ 'url' => $this->settings->url . 'fhir/Patient', 'param' => [ 'identifier' => $identifier ] ]); $patientInfo = new med_cisz_patientInfo(); $parsedPatientData = $patientInfo->parsePatientGeneral($patientResource); $preparedData = $patientInfo->prepareTransformedDataToSave($parsedPatientData, $params); $saverClass = new med_cisz_receiveNewPatient(); return $saverClass->saveNewPatient($preparedData); } public function importResource (?object $params = null) { $resourceType = $params->resourceType ?? ''; $data = safe_json_decode($params->data); switch ($resourceType) { case 'ServiceRequestHospitalisation': $importer = new med_cisz_serviceRequest_hospitalisation_importer(); return $importer->import($data); } } public function ciszRequest(?object $setup = null, bool $useThrow = true): object|string|null { $paramsArr = []; if (isset($setup->params)){ foreach ($setup->params as $param){ if ($param && isset($param->name) && isset($param->value)){ $paramsArr[$param->name] = $param->value; } } } $result = self::doHttpMethodWithAuth($this->settings, (object) [ 'url' => $this->settings->url . 'fhir/'. $setup->url, 'param' => $paramsArr, 'headers' => isset($setup->headers) ? (array)$setup->headers : [], 'GET', $useThrow ]); return $result; } public function readPatientStatusCisz($params = null) { $db = $this->db ?: $this->db = connectDb(); $id = isEmptyProperty($params, 'patientId'); $result = selectSql($db, <<<SQL
        SELECT
            COALESCE(MAX(CL.Status), 0) AS Status
        FROM CiszLink CL
        WHERE CL.TableName = 'MedPatient'
          AND CL.PrimaryKey = :id
          AND CL.Type = 1
    SQL,
[ ':id' => $id ]); return $result; } private function doCancelBundle(string $id): object|string|null { $reqParams = (object) [ 'url' => $this->settings->url . 'fhir/Bundle/' . $id . '/$cancel', ]; $historyId = $this->history( StatusEnum::PENDING, HistoryActionTypeEnum::CANCEL, request: $reqParams, bundleId: $id ); $result = self::doHttpMethodWithAuth($this->settings, $reqParams, 'POST', false); $this->history( self::extractParameter($result, 'ResourceId') ? StatusEnum::CANCELLED : StatusEnum::FAILED, response: $result, historyId: $historyId, bundleId: $id ); return $result; } private function updateCiszLink(string $resourceId, object $params, ?int $historyId = null) { $db = $this->db ?: $this->db = connectDb(); if ($resourceId) { if (($params->patientId ?? false) && (!isset($params->visitPatientId))) { if ($this->entity !== 'MedVaccinationRecommendation') { if ($this->patient->raw->personalNumber) { $patientUuid = self::getPatientUuidFromCisz($this->patient->raw->personalNumber, 'personalNumber'); } else if ($this->patient->raw->passportNumber) { $patientUuid = self::getPatientUuidFromCisz($this->patient->raw->passportNumber, 'passportNumber'); } else if ($this->patient->raw->docNumber) { $patientUuid = self::getPatientUuidFromCisz($this->patient->raw->docNumber, 'docNumber'); } else { throw new Exception("Не указаны данные пациента для поиска"); } if (!$patientUuid){ self::storeLinkUniqueByPk($this->db, $params->entity, null, $this->visitPatientId ?? $this->patientId, 1, 1); self::storeLinkUniqueByPk($this->db, $params->entity, $resourceId, $this->visitPatientId ?? $this->patientId, 2, 1); if ($historyId) { self::historyUpdateId($this->db, $historyId, 'RecordId', "Patient/inProgress"); self::historyUpdateId($this->db, $historyId, 'BundleId', $resourceId); } return true; } if ($patientUuid && $params->entity ?? false) { self::upsertContract($patientUuid); self::storeLinkUniqueByPk($this->db, $params->entity, $patientUuid, $this->visitPatientId ?? $this->patientId, 1, 1); self::storeLinkUniqueByPk($this->db, $params->entity, $resourceId, $this->visitPatientId ?? $this->patientId, 2, 1); if ($historyId) { self::historyUpdateId($this->db, $historyId, 'RecordId', "Patient/$patientUuid"); self::historyUpdateId($this->db, $historyId, 'BundleId', $resourceId); } } } else { self::storeLinkUniqueByPk($this->db, $this->entity, $resourceId, $this->patientId, 2, 1); } } else if ($params->visitPatientId ?? false) { if ($historyId) { self::historyUpdateId($this->db, $historyId, 'BundleId', $resourceId); } $data = self::doHttpMethodWithAuth($this->settings, (object) [ 'url' => $this->settings->url . 'fhir/Bundle/' . $resourceId, ]); foreach ($data->entry as $item) { $resourceType = $item->resource->resourceType; if ($resourceType === 'Encounter' ) { if ($this->entity == 'MedVisitPatient') { self::storeLinkUniqueByPk($this->db, $this->entity, $item->resource->id, $this->visitPatientId, 1, 1); self::storeLinkUniqueByPk($this->db, $this->entity, $resourceId, $this->visitPatientId, 2, 1); } elseif ($this->entity == 'MedLogStudy') { !isset($this->functDiag['serviceRequest']->object) ?: ($this->functDiag['serviceRequest']->send) ?: $entityMLS[] = ($this->entity . '/1'); !isset($this->functDiag['procedure']->object) ?: ($this->functDiag['procedure']->send) ?: $entityMLS[] = ($this->entity . '/2'); !isset($this->functDiag['observation']->object) ?: ($this->functDiag['observation']->send) ?: $entityMLS[] = ($this->entity . '/3'); !isset($this->functDiag['diagnosticReport']->object) ?: ($this->functDiag['diagnosticReport']->send) ?: $entityMLS[] = ($this->entity . '/4'); if (!empty($entityMLS)) { self::storeLinkUniqueByPk($this->db, $entityMLS[0], $resourceId, $this->visitPatientId, 2, 1); foreach ($entityMLS as $entityEx){ if ((self::getLinkEntityUUID($this->db, 2, $entityEx, $this->visitPatientId) && str_contains(self::getLinkEntityUUID($this->db, 2, $entityEx, $this->visitPatientId), "(MedLogStudy/")) || !self::getLinkEntityUUID($this->db, 2, $entityEx, $this->visitPatientId)) self::storeLinkUniqueByPk($this->db, $entityEx, '(' . $entityEx . ')' . $resourceId, $this->visitPatientId, 2, 1); } } } elseif( $this->entity == 'MedInspect') { self::storeLinkUniqueByPk($this->db, $this->entity, $resourceId, $this->visitPatient[array_key_first($this->visitPatient)]->inspectCode, 2, 1); } elseif( $this->entity == 'MedAmbulOperation') { if (!self::getLinkEntityUUID($this->db,2, $this->entity,$this->visitPatientId)) { self::storeLinkUniqueByPk($this->db, $this->entity, $resourceId, $this->visitPatientId, 2, 1); } } elseif ($this->entity == 'MedStatCard'){ self::storeLinkUniqueByPk($this->db, $this->entity, $item->resource->id, $this->visitPatientId, 1, 1); self::storeLinkUniqueByPk($this->db, $this->entity, $resourceId, $this->visitPatientId, 2, 1); } elseif ($this->entity === 'MedLogStudyImage') { !isset($this->functImaging['serviceRequest']->object) ?: ($this->functImaging['serviceRequest']->send) ?: $entityMLS[] = ($this->entity . '/1'); !isset($this->functImaging['observation']->object) ?: ($this->functImaging['observation']->send) ?: $entityMLS[] = ($this->entity . '/2'); !isset($this->functImaging['diagnosticReport']->object) ?: ($this->functImaging['diagnosticReport']->send) ?: $entityMLS[] = ($this->entity . '/3'); if (!empty($entityMLS)) { self::storeLinkUniqueByPk($this->db, $entityMLS[0], $resourceId, $this->visitPatientId, 2, 1); foreach ($entityMLS as $entityEx) { if ((self::getLinkEntityUUID($this->db, 2, $entityEx, $this->visitPatientId) && str_contains(self::getLinkEntityUUID($this->db, 2, $entityEx, $this->visitPatientId), "(MedLogStudyImage/")) || !self::getLinkEntityUUID($this->db, 2, $entityEx, $this->visitPatientId)) self::storeLinkUniqueByPk($this->db, $entityEx, '(' . $entityEx . ')' . $resourceId, $this->visitPatientId, 2, 1); } } } elseif ($this->entity == 'StomVisit') { self::storeLinkUniqueByPk($this->db, $this->entity, $item->resource->id, $this->visitPatientId, 1, 1); self::storeLinkUniqueByPk($this->db, $this->entity, $resourceId, $this->visitPatientId, 2, 1); } elseif ($this->entity == 'MedTherapyStom') { self::storeLinkUniqueByPk($this->db, $this->entity, $item->resource->id, $this->visitPatientId, 1, 1); self::storeLinkUniqueByPk($this->db, $this->entity, $resourceId, $this->visitPatientId, 2, 1); } } else if ($resourceType === 'Patient' || $resourceType === 'Composition'|| $resourceType === 'DocumentReference') { continue; } elseif ($resourceType === 'DeviceRequest') { if ($this->entity === 'MedDeviceHosp') { self::storeLinkUniqueByPk($this->db, 'DeviceRequestStat', $item->resource->id, $this->visitPatientId, 1, 1); self::storeLinkUniqueByPk($this->db, 'DeviceRequestStat', $resourceId, $this->visitPatientId, 2, 1); } } elseif ($resourceType === 'MedicationRequest') { if ($this->entity === 'MedMedicationHosp') { self::storeLinkUniqueByPk($this->db, 'MedicationRequestStat', $item->resource->id, $this->visitPatientId, 1, 1); self::storeLinkUniqueByPk($this->db, 'MedicationRequestStat', $resourceId, $this->visitPatientId, 2, 1); } } elseif ($resourceType === 'EpisodeOfCare') { if ($this->entity === 'TemporaryDisability') { self::storeLinkUniqueByPk($this->db,'TemporaryDisability', $item->resource->id, $this->visitPatientId, 1, 1); self::storeLinkUniqueByPk($this->db, 'TemporaryDisability', $resourceId, $this->visitPatientId, 2, 1); } elseif ($this->entity === 'MedLogHospital') { self::storeLinkUniqueByPk($this->db, 'MedLogHospital', $item->resource->id, $this->visitPatientId, 1, 1); self::storeLinkUniqueByPk($this->db, 'MedLogHospital', $resourceId, $this->visitPatientId, 2, 1); } elseif ($this->entity === 'MedDayHospital') { self::storeLinkUniqueByPk($this->db, $this->entity, $item->resource->id, $this->visitPatientId, 1, 1); self::storeLinkUniqueByPk($this->db, $this->entity, $resourceId, $this->visitPatientId, 2, 1); } else { self::storeLinkUniqueByPk($this->db,'TemporaryDisability', $item->resource->id, $this->visitPatientId, 1, 1); } } elseif ($resourceType === 'MedicationRequest') { if ($this->entity === 'MedMedication') { self::storeLinkUniqueByPk($this->db,'MedMedication', $item->resource->id, $this->visitPatientId, 1, 1); self::storeLinkUniqueByPk($this->db, 'MedMedication', $resourceId, $this->visitPatientId, 2, 1); } else { } } elseif ($resourceType === 'Procedure') { if ($this->entity === 'MedProcedure') { self::storeLinkUniqueByPk($this->db,'MedProcedure', $item->resource->id, $this->procedurePatient[array_key_first($this->procedurePatient)]->id, 1, 1); self::storeLinkUniqueByPk($this->db, 'MedProcedure', $resourceId, $this->procedurePatient[array_key_first($this->procedurePatient)]->id, 2, 1); } else { !isset($this->procedurePatient) ?: self::storeLinkUniqueByPk($this->db, 'MedProcedure', $item->resource->id, $this->procedurePatient[array_key_first($this->procedurePatient)]->id, 1, 1); } } elseif ($resourceType === 'Device') { if (($this->entity !== 'MedStatCard') && ($this->entity !== 'MedLogHospital') && ($this->entity !== 'StomVisit')) { self::storeLinkUniqueByPk($this->db, 'DicomDevice', $item->resource->id, $this->visitPatientId, 1, 1); self::storeLinkUniqueByPk($this->db, 'DicomDevice', $resourceId, $this->visitPatientId, 2, 1); } } elseif ($resourceType === 'ImmunizationRecommendation') { self::storeLinkUniqueByPk($this->db, 'MedVaccinationRecommendation', $item->resource->id, $this->patientId, 2, 1); } elseif ($resourceType === 'ImagingStudy') { self::storeLinkUniqueByPk($this->db,'MedLogStudyImage/4', $item->resource->id, $this->visitPatientId, 2, 1); } elseif ($resourceType === 'DiagnosticReport' && $this->entity !== 'MedLogStudy') { if (isset($this->diagnosticReport->type)) { if ($this->diagnosticReport->type === 1) { self::storeLinkUniqueByPk($this->db,'MedLogStudyImage/3', $item->resource->id, $this->visitPatientId, 2, 1); } elseif ($this->diagnosticReport->type === 2) { self::storeLinkUniqueByPk($this->db,'MedLogStudyImage/5', $item->resource->id, $this->visitPatientId, 2, 1); } } else if ($this->entity == 'MedRadioIzotopStat' ) { self::storeLinkUniqueByPk($this->db,'MedRadioIzotopStat/2', $item->resource->id, $this->visitPatientId, 2, 1); } else if ($this->entity == 'MedRadioIzotopStom' ) { self::storeLinkUniqueByPk($this->db,'MedRadioIzotopStom/2', $item->resource->id, $this->visitPatientId, 2, 1); } else if (basename($item->resource->meta->profile[0]) == 'UltrasoundDiagnosticReport' && isset($this->functImaging['diagnosticReport']->object->raw->visitFuncDiagId) && $this->entity !== 'MedLogStudyImage') { self::storeLinkUniqueByPk($this->db,'MedLogStudyImage/3', '(MedLogStudyImage/3)' . $item->resource->id, $this->functImaging['diagnosticReport']->object->raw->visitFuncDiagId, 2, 1); } } elseif ($resourceType === 'Observation') { if (basename($item->resource->meta->profile[0]) == 'ObservationUltrasound' && isset($this->functImaging['observation']->object->raw->visitFuncDiagId) && $this->entity !== 'MedLogStudyImage') { self::storeLinkUniqueByPk($this->db, 'MedLogStudyImage/2', '(MedLogStudyImage/2)' . $item->resource->id, $this->functImaging['observation']->object->raw->visitFuncDiagId, 2, 1); } } else { if ($resourceType == 'ServiceRequest') { switch ($this->entity){ case 'MedVisitPatient': { switch (basename($item->resource->meta->profile[0])) { case 'ServiceRequestConsult': { self::storeLinkUniqueByPk($this->db, 'MedLogSend', $item->resource->id, (int)$item->resource->identifier[0]->value, 1, 1); break; } case 'ServiceRequestPhysiotherapy': { self::storeLinkUniqueByPk($this->db, 'MedProcedure', $item->resource->id, (int)($this->procedurePatient[0]->id ?? $item->resource->identifier[0]->value), 1, 1); continue 3; } case 'ServiceRequestUltrasound': { $ultrasoundRequestId = $this->functImaging['observation']->object->raw->visitFuncDiagId ?? null; if ($ultrasoundRequestId && $this->entity !== 'MedLogStudyImage') { self::storeLinkUniqueByPk($this->db, 'MedLogStudyImage/1', '(MedLogStudyImage/1)' . $item->resource->id, $ultrasoundRequestId, 2, 1); } break; } } break; } case 'MedHospitalRequest': case 'MedLogSend': { self::storeLinkUniqueByPk($this->db, $this->entity, $item->resource->id, $this->visitPatientId, 1, 1); self::storeLinkUniqueByPk($this->db, $this->entity, $resourceId, $this->visitPatientId, 2, 1); break; } case 'MedProcedure': { self::storeLinkUniqueByPk($this->db, $this->entity, $item->resource->id, $this->visitPatientId, 1, 1); self::storeLinkUniqueByPk($this->db, $this->entity, $resourceId, $this->visitPatientId, 2, 1); return true; } case 'MedRadioIzotopStat': case 'MedRadioIzotopStom': { self::storeLinkUniqueByPk($this->db, $this->entity . '/1', $resourceId, $this->visitPatientId, 2, 1); break; } } } if ($this->entity == 'MedLogStudy') { !isset($this->functDiag['serviceRequest']->object) ?: ($this->functDiag['serviceRequest']->send) ?: $entityMLS[] = ($this->entity . '/1'); !isset($this->functDiag['procedure']->object) ?: ($this->functDiag['procedure']->send) ?: $entityMLS[] = ($this->entity . '/2'); !isset($this->functDiag['observation']->object) ?: ($this->functDiag['observation']->send) ?: $entityMLS[] = ($this->entity . '/3'); !isset($this->functDiag['diagnosticReport']->object) ?: ($this->functDiag['diagnosticReport']->send) ?: $entityMLS[] = ($this->entity . '/4'); if (!empty($entityMLS)) { self::storeLinkUniqueByPk($this->db, $entityMLS[0], $resourceId, $this->visitPatientId, 2, 1); foreach ($entityMLS as $entityEx) { if ((self::getLinkEntityUUID($this->db, 2, $entityEx, $this->visitPatientId) && str_contains(self::getLinkEntityUUID($this->db, 2, $entityEx, $this->visitPatientId), "(MedLogStudy/")) || !self::getLinkEntityUUID($this->db, 2, $entityEx, $this->visitPatientId)) self::storeLinkUniqueByPk($this->db, $entityEx, '(' . $entityEx . ')' . $resourceId, $this->visitPatientId, 2, 1); } break; } } if ($resourceType === 'Immunization') { $uuid = self::getLinkEntityUUID($this->db,2, $this->entity, $this->visitPatientId); if (!$uuid) { self::storeLinkUniqueByPk($this->db, $this->entity, $resourceId, $this->visitPatientId, 2, 1); } } if ($this->entity === 'MedDayHospital') { if ($resourceType === 'EpisodeOfCare') { self::storeLinkUniqueByPk($this->db, $this->entity, $item->resource->id, $this->visitPatientId, 1, 1); self::storeLinkUniqueByPk($this->db, $this->entity, $resourceId, $this->visitPatientId, 2, 1); break; } } if ($this->entity === 'MedMedication') { if ($resourceType === 'MedicationRequest') { self::storeLinkUniqueByPk($this->db, $this->entity, $item->resource->id, $this->visitPatientId, 1, 1); self::storeLinkUniqueByPk($this->db, $this->entity, $resourceId, $this->visitPatientId, 2, 1); break; } } if ($resourceType === 'Condition') { self::addDiagnosisFromCisz($item->resource, $this->doctorId, $this->patientId); } if ($resourceType == 'ServiceRequest' || $resourceType == 'Procedure' || $resourceType === 'CarePlan' || $resourceType === 'Specimen') { $suffix = isset($item->resource->identifier) ? $item->resource->identifier[0]->value : $item->resource->code->concept->coding[0]->code; } else { if (isset($item->resource->code)) { $suffix = $item->resource->code->coding[0]->code; } else { $suffix = ''; } } $tableName = $this->entity . '_' . $resourceType . '_' . $suffix; self::storeLinkUnique($this->db, $tableName, $item->resource->id, $this->visitPatientId, 2); } if ($this->entity === 'MedLogStudyLab') { !isset($this->medLabStudy['serviceRequest']->id) ?: ($this->medLabStudy['serviceRequest']->send) ?: $entityMLSL[] = ($this->entity . '/1'); !isset($this->medLabStudy['specimen']->id) ?: ($this->medLabStudy['specimen']->send) ?: $entityMLSL[] = ($this->entity . '/2'); !isset($this->medLabStudy['diagnosticReport']->id) ?: ($this->medLabStudy['diagnosticReport']->send) ?: $entityMLSL[] = ($this->entity . '/3'); if (!empty($entityMLSL)) { self::storeLinkUniqueByPk($this->db, $entityMLSL[0], $resourceId, $this->visitPatientId, 2, 1); foreach ($entityMLSL as $entityEx) { if ((self::getLinkEntityUUID($this->db, 2, $entityEx, $this->visitPatientId) && str_contains(self::getLinkEntityUUID($this->db, 2, $entityEx, $this->visitPatientId), "(MedLogStudyLab/")) || !self::getLinkEntityUUID($this->db, 2, $entityEx, $this->visitPatientId)) self::storeLinkUniqueByPk($this->db, $entityEx, '(' . $entityEx . ')' . $resourceId, $this->visitPatientId, 2, 1); } } } } } return true; } } private function history( StatusEnum $status, ?HistoryActionTypeEnum $actionType = null, string|object|null $request = null, string|object|null $response = null, ?int $historyId = null, ?string $bundleId = null, ): ?int { if (!$request && !$response) { throw new Exception( med_cisz_constant::ERROR_HISTORY_DATA_NOT_EXISTS, med_cisz_constant::ERROR_HISTORY_DATA_NOT_EXISTS_CODE ); } if (!$historyId && !$actionType) { throw new Exception( med_cisz_constant::ERROR_HISTORY_ACTION_TYPE_NOT_EXISTS, med_cisz_constant::ERROR_HISTORY_ACTION_TYPE_NOT_EXISTS_CODE ); } if (!$this->doctorId) { if (is_string(($mapMedDoctor = getSessionValue('mapMedDoctor')))) { $mapMedDoctor = json_decode($mapMedDoctor, true); } $this->doctorId = $mapMedDoctor['MedDoctorCode'] ?? null; } if (!($userId = (int) getSessionValue('mapUserCode'))) { $userId = (int) selectSqlValue( $this->db, "SELECT UserCode FROM MedDoctor WHERE MedDoctorCode = ?", [$this->doctorId] ); setSessionValue('mapUserCode', $userId); } $type = null; $recordId = null; if (!($this->bundle?->id ?? false)) { if ($bundleId) { $row = selectSql($this->db, <<<SQL
                    SELECT
                        Type AS type,
                        BundleId AS "bundleId",
                        RecordId AS "recordId"
                    FROM
                        ciszHistory
                    WHERE
                        (BundleId = :bundleId OR RecordId = :recordId)
                        AND UserCode = :userId
                    ORDER BY RequestTime DESC
                    LIMIT 1
                SQL,
[ ':bundleId' => $bundleId, ':recordId' => $bundleId, ':userId' => $userId ], PDO::FETCH_OBJ ); $row = reset($row); if ($row) { $type = HistoryTypeEnum::tryFrom($row->type) ?? null; $bundleId = $row->bundleId ?? $bundleId; $recordId = $row->recordId; } else { $recordId = $bundleId; } } } if (!($patientId = $this->patient?->raw?->patientId ?? $this->patientId ?? false)) { throw new Exception( med_cisz_constant::ERROR_HISTORY_PATIENT_NOT_EXISTS, med_cisz_constant::ERROR_HISTORY_PATIENT_NOT_EXISTS_CODE ); } if ($this->bundle ?? false) { $type = HistoryTypeEnum::PATIENT; $profile = null; foreach ($this->bundle->entry as $item) { if ($item->resource->resourceType == 'Composition') { continue; } if ($item->resource->resourceType == 'Contract') { continue; } if ($item->resource->resourceType != 'Patient') { $type = HistoryTypeEnum::ENCOUNTER; $profile = $item; break; } } $recordId = match ($type) { HistoryTypeEnum::ENCOUNTER => $profile?->fullUrl ?? null, default => $this->patient->profile->fullUrl, }; } else { $type = $type ?: ($this->encounter ? HistoryTypeEnum::ENCOUNTER : HistoryTypeEnum::PATIENT); if (!$recordId) { if ($this->encounter) { $recordId = $this->encounter->profile->fullUrl; } elseif ($this->patient) { $recordId = $this->patient->profile->fullUrl; } } } if (!$historyId) { if (!$recordId) { throw new Exception( med_cisz_constant::ERROR_HISTORY_BUNDLE_NOT_EXISTS, med_cisz_constant::ERROR_HISTORY_BUNDLE_NOT_EXISTS_CODE ); } if ($type == HistoryTypeEnum::PATIENT && !str_starts_with($recordId, 'Patient/')) { $recordId = "Patient/$recordId"; } elseif ($type == HistoryTypeEnum::ENCOUNTER && !str_starts_with($recordId, 'Encounter/')) { $recordId = "Encounter/$recordId"; } executeSql($this->db, <<<SQL
                INSERT INTO ciszHistory (Type, UserCode, BundleId, RecordId, ActionType, RequestTime, Status, MedPatientCode, RequestJSON, 
                                         MedDoctorCode, TableName, PrimaryKey)
                VALUES (:type, :userId, :bundleId, :recordId, :actionType, now(), :status, :patientId, :request,
                        :doctorId, :tableName, :primaryKey)
            SQL,
[ ':type' => $type->value, ':userId' => $userId, ':bundleId' => $this->bundle?->id ?? $bundleId, ':recordId' => $recordId, ':actionType' => $actionType->value, ':status' => $status->value, ':patientId' => $patientId, ':request' => base64_encode(is_string($request) ? $request : json_encode($request, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)), ':doctorId' => $this->doctorId ?? null, ':tableName' => $this->entity, ':primaryKey' => $this->visitPatientId ] ); return (int) $this->db->lastInsertId('seq_ciszhistory'); } executeSql($this->db, <<<SQL
            UPDATE ciszHistory SET
                Status = :status,
                ResponseTime = now(),
                ResponseJson = :response
            WHERE
                ciszHistoryCode = :historyId
        SQL,
[ ':status' => $status->value, ':response' => base64_encode(is_string($response) ? $response : json_encode($response, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)), ':historyId' => $historyId, ] ); return null; } public function ciszRequestAllergy($params) { $patientUuid = self::getLinkEntityUUID($this->db, 1, 'MedPatient', $params->patientId); if (!$patientUuid) { throw new Exception('Пациент не зарегистрирован в ЦИСЗ'); } $result = self::doHttpMethodWithAuth($this->settings, (object) [ 'url' => $this->settings->url . 'fhir/Patient/' . $patientUuid . '/QuestionnaireResponse?patient=' . $patientUuid . '&_profile=' . med_cisz_constant::$structureDefinitions['QRAllergicReaction'] . '&_profile=' . med_cisz_constant::$structureDefinitions['QRUnwantedReaction'], ]); $resultObject = new stdClass(); $i = 1; foreach ($result->entry ?? [] as $entry) { $resource = $entry->resource ?? null; if (($resource->resourceType ?? false) != 'QuestionnaireResponse') { continue; } $resultObject->{"resource$i"} = $resource; $i++; } $result = $resultObject; $patientInfo = new med_cisz_patientInfo(); $result = $patientInfo->transformPatientData($result); return array_values((array) $result->questionnaires); } public function cancellationContract($params) { $db = $this->db ?: $this->db = connectDb(); $ciszData = getSessionValue('cisz') ?? (object) []; $organizationId = $ciszData->organization_id; $registrationUuid = selectSqlValue($db, <<<SQL
            SELECT
                CL.Uuid AS "uuid"
            FROM CiszLink CL
            WHERE CL.PrimaryKey = :registrationId AND CL.TableName = :entity
        SQL,
[ ':registrationId' => $params->registrationId, ':entity' => $params->entity, ]); if ($registrationUuid) { $body = json_encode([ 'resourceType' => 'Parameters', 'parameter' => [ [ 'name' => 'status', 'valueCode' => 'rejected' ] ] ]); $reqParams = (object) [ 'url' => $this->settings->url . 'fhir/Organization/' . $organizationId . '/Contract/' . $registrationUuid . '/$set-status', 'headers' => [ 'Content-Type' => 'application/json', ], 'request_content' => $body, ]; $result = self::doHttpMethodWithAuth($this->settings, $reqParams, 'POST', false); if ($result) { self::deleteLinkUnique($db, 'MedPatientRegistration', $params->registrationId); } } } public function setRequestStatus(int $id, int $status, string $tableName = 'MedLogSend'): string { $db = $this->db ?: $this->db = connectDb(); $ciszData = getSessionValue('cisz') ?? (object) []; $organizationId = $ciszData->organization_id; $key = 'MLS.' . $tableName . 'Code'; $dateD = 'MLS.' . ($tableName === 'MedLogStudy' ? 'dirTime' : 'documentDate'); $type = $tableName === 'MedLogStudy' ? 'MLS.type' : 0; $dirNumber = $tableName === 'MedLogStudy' ? 'MLS.Dirnumber' : 0; $row = selectSql($db, <<<SQL
            SELECT
                MLS.medPatientCode "patientCode",
                $dateD "date",
                $dirNumber "dirId",
                $type "type"
            FROM $tableName MLS
            WHERE $key = :mlsc
        SQL,
[ ':mlsc' => $id, ], PDO::FETCH_OBJ); $this->patientId = $row[0]->patientCode; $dateVisit = $row[0]->date; $dirNumber = (int)$row[0]->dirId === 0 ? $id : (int)$row[0]->dirId; $type = $row[0]->type; if (!isset($this->patientId)) { return 'Пациент не найден'; } $body = json_encode([ 'resourceType' => 'Parameters', 'parameter' => [ [ 'name' => 'status', 'valueCode' => $status === 0 ? 'revoked' : 'completed' ] ] ]); switch ($tableName) { case 'MedLogSend': $profile = med_cisz_constant::$structureDefinitions['ServiceRequestConsult']; break; case 'MedLogStudy': if ($type === 3) { $profile = med_cisz_constant::$structureDefinitions['ServiceRequestFunctDiagn']; } elseif ($type === 2) { $profile = med_cisz_constant::$structureDefinitions['ServiceRequestUltrasound']; } elseif ($type === 1) { $profile = med_cisz_constant::$structureDefinitions['ServiceRequestBioMatResearch']; } break; } $srUuid = self::getPatientResource($dirNumber, self::changeDateMonths($dateVisit,-1), self::changeDateMonths($dateVisit,1), $profile); if (!$srUuid) { $srUuid = self::getPatientResource($dirNumber, self::changeDateMonths($dateVisit,-1), self::changeDateMonths($dateVisit,1), med_cisz_constant::$structureDefinitions['ServiceRequestHospitalisation']); } if ($srUuid) { $reqParams = (object)[ 'url' => $this->settings->url . 'fhir/Organization/' . $organizationId . '/ServiceRequest/' . $srUuid . '/$set-status', 'headers' => [ 'Content-Type' => 'application/json', ], 'request_content' => $body, ]; $result = self::doHttpMethodWithAuth($this->settings, $reqParams, 'POST', false); return $result->issue[0]->details->text; } else { return 'Данное направление не зарегистрировано в ЦИСЗ'; } } public function updateCurrentOrganization() { $db = $this->db ?: $this->db = connectDb(); $settings = readExtraSettings($db, med_cisz_constant::SETTING_NAME); $this->createOrganization(); if ($settings->organizationId) { $orgUUid = str_replace('Organization/', '', $this->organization->link->reference); $org = selectSqlValue($db, <<<SQL
                    SELECT EnterpriseCode "ciszEnterpriseId"
                    FROM EnterpriseNumber
                    WHERE CiszGuid = :uuid
            SQL,
[ ':uuid' => $orgUUid ]); if ($settings->organizationId === $org) { return; } else { $sqlDelCiszEnterprise = <<<SQL
                                DELETE FROM Enterprise where EnterpriseCode = :enterpriseCode
                            SQL;
$stmtDelCiszEnterprise = $db->prepare($sqlDelCiszEnterprise); $stmtDelCiszEnterprise->execute([ 'enterpriseCode' => $org ]); $sqlUpCurrEnterprise = <<<SQL
                    INSERT INTO EnterpriseNumber (EnterpriseCode, CiszGuid)
                        VALUES (:enterpriseCode, :uuid)
                    ON CONFLICT (EnterpriseCode)
                    DO UPDATE SET
                        CiszGuid = EXCLUDED.CiszGuid
                SQL;
$stmtUpdateCurrEnterprise = $db->prepare($sqlUpCurrEnterprise); $stmtUpdateCurrEnterprise->execute([ 'uuid' => $orgUUid, 'enterpriseCode' => $settings->organizationId ]); } } else { throw new Exception( med_cisz_constant::$patientError['currentOrganization']['text'], med_cisz_constant::$patientError['currentOrganization']['code'] ); } } public function ciszRequestDisabilityList($params) { $patientUuid = self::getLinkEntityUUID($this->db, 1, 'MedPatient', $params->patientId); if (!$patientUuid) { throw new Exception('Пациент не зарегистрирован в ЦИСЗ'); } $result = self::doHttpMethodWithAuth($this->settings, (object) [ 'url' => $this->settings->url . 'fhir/Patient/' . $patientUuid . '/EpisodeOfCare?_profile=' . med_cisz_constant::$structureDefinitions['EpisodeOfTemporaryDisabilitySum'] . '&status=active', ]); $resultObject = new stdClass(); $i = 1; foreach ($result->entry ?? [] as $entry) { $resource = $entry->resource ?? null; if (($resource->resourceType ?? false) != 'EpisodeOfCare') { continue; } $resultObject->{"resource$i"} = $resource; $i++; } $result = $resultObject; $patientInfo = new med_cisz_patientInfo(); $result = $patientInfo->transformPatientData($result); return array_values((array) $result->disabilityLists); } public function ciszRequestHospitalisation($params) { $patientUuid = isEmptyProperty($params, 'patientUuid'); $refferalId = isEmptyProperty($params, 'refferalId'); $refferal = self::doHttpMethodWithAuth($this->settings, (object) [ 'url' => $this->settings->url . 'fhir/Patient/' . $patientUuid . '/ServiceRequest/' . $refferalId ]); $hospitalisationFromRefferal = null; $rejectionFromRefferal = null; $encounter = null; if ($refferal) { $rejection = self::doHttpMethodWithAuth($this->settings, (object) [ 'url' => $this->settings->url . 'fhir/Patient/'. $patientUuid . '/Contract?topic=ServiceRequest/' . $refferalId . '&_profile=https://fhir.by/StructureDefinition/RejectionBy' ]); if ($rejection && $rejection->total > 0) { foreach ($rejection->entry as $rej) { if ($rej->resource->resourceType === 'Contract') { $rejectionFromRefferal = $rej->resource; break; } } } if (isset($refferal->encounter->reference)) { $encounter = self::doHttpMethodWithAuth($this->settings, (object) [ 'url' => $this->settings->url . 'fhir/Patient/' . $patientUuid . '/' . $refferal->encounter->reference ]); } } $resultObject = new stdClass(); if ($refferal) { $resultObject->serviceRequest = $refferal; } if ($hospitalisationFromRefferal) { $resultObject->episodeOfCare = $hospitalisationFromRefferal; } if ($rejectionFromRefferal) { $resultObject->contract = $rejectionFromRefferal; } if ($encounter) { $resultObject->encounter = $encounter; } $result = $resultObject; $patientInfo = new med_cisz_patientInfo(); $result = $patientInfo->transformPatientData($result); return array_values((array) $result->hospitalisation); } public function getOData() { $db = $this->db ?: $this->db = connectDb(null, null, true); $settings = readExtraSettings($db, med_cisz_constant::SETTING_NAME); $resData = []; if ($settings && $settings->organizationId) { $currOrgUuid = selectSqlValue($db, <<<SQL
                    SELECT CiszGuid "uuid"
                    FROM EnterpriseNumber
                    WHERE EnterpriseCode = :id
SQL,
[':id' => $settings->organizationId]); $locations = self::doHttpMethod( $this->settings, (object)[ 'url' => $this->settings->url . 'fhir/Location?organization=' . $currOrgUuid ] ); foreach ($locations->entry as $key => $value) { if ($value->fullUrl) { $resData[] = $value->resource; } } } return json_encode($resData); } public function getFileFrom(string $url): string|null { $file = self::doHttpMethodWithAuth($this->settings,(object)[ 'url' => $url ]); return base64_encode($file); } } handleJsonRpc('med_cisz_bundle'); 