# ResetCiszCert.ps1  (ASCII-only source, safe for PowerShell 5.1)
# Clears the remembered signing certificate (cert=) in [sigma] section of
# NTClientSoftware.ini so the agent asks for certificate selection again.
# Use when a wrong certificate (without CISZ send permission) was written.
#
# Usage:
#   powershell -NoProfile -ExecutionPolicy Bypass -File ResetCiszCert.ps1
#   powershell -NoProfile -ExecutionPolicy Bypass -File ResetCiszCert.ps1 -Restart

param(
    [switch]$Restart
)

$ErrorActionPreference = 'Stop'

$iniPath = 'C:\NTClientSoftware\config\NTClientSoftware.ini'
$exePath = 'C:\NTClientSoftware\NTClientSoftware.exe'

if (-not (Test-Path $iniPath)) {
    Write-Error "INI not found: $iniPath"
    exit 4
}

# ---- 1. Backup INI before modification ----
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backup = "$iniPath.reset-backup-$stamp"
Copy-Item $iniPath $backup -Force
Write-Output ("Backup created: " + $backup)

# ---- 2. Read ini as Windows-1251 (cp1251) ----
$enc = [System.Text.Encoding]::GetEncoding(1251)
$raw = [System.IO.File]::ReadAllBytes($iniPath)
$text = $enc.GetString($raw)

# ---- 3. Clear ONLY the cert= line inside [sigma] section ----
$lines = $text -split "`r`n", -1
$inSigma = $false
$oldValue = $null
for ($i = 0; $i -lt $lines.Count; $i++) {
    $line = $lines[$i]
    if ($line -match '^\s*\[') {
        $inSigma = ($line -match '^\s*\[sigma\]\s*$')
        continue
    }
    if ($inSigma -and $line -match '^\s*cert=') {
        $oldValue = $line
        $lines[$i] = 'cert='
    }
}

if ($null -eq $oldValue) {
    Write-Warning 'cert= line not found in [sigma]. Nothing to reset.'
    exit 0
}

Write-Output ("Old value: " + $oldValue)
$newText = $lines -join "`r`n"
[System.IO.File]::WriteAllBytes($iniPath, $enc.GetBytes($newText))
Write-Output 'cert= cleared in [sigma].'

# ---- 4. Optionally restart NTClientSoftware so it re-reads the ini ----
if ($Restart) {
    $proc = Get-Process -Name 'NTClientSoftware' -ErrorAction SilentlyContinue
    if ($proc) {
        Write-Output ("Restarting NTClientSoftware (PID " + $proc.Id + ") ...")
        Stop-Process -Id $proc.Id -Force
        Start-Sleep -Seconds 2
    }
    if (Test-Path $exePath) {
        Start-Process -FilePath $exePath
        Write-Output 'NTClientSoftware started.'
    } else {
        Write-Warning "Agent exe not found: $exePath (start it manually)"
    }
} else {
    Write-Output 'NOTE: restart NTClientSoftware to apply (run with -Restart to do it automatically).'
}
Write-Output 'Done.'
