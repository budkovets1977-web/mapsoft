@echo off
echo === Killing NTClientSoftware ===
taskkill /F /IM NTClientSoftware.exe 2>nul
if %errorlevel%==0 (echo killed) else (echo was not running)
timeout /t 2 /nobreak >nul
echo === Starting NTClientSoftware ===
start "" "C:\NTClientSoftware\NTClientSoftware.exe"
timeout /t 5 /nobreak >nul
echo === Process after restart ===
tasklist | findstr /I "NTClientSoftware"
echo.
echo === Current cert= value ===
type C:\NTClientSoftware\config\NTClientSoftware.ini | findstr /C:"cert="
echo.
echo === nki3.0.log last 15 lines (cert used for signing) ===
powershell -NoProfile -Command "Get-Content 'C:\NTClientSoftware\nki3.0.log' -Tail 15 -Encoding Default"
echo.
echo Now repeat the CISZ send from MIS and watch which certificate dialog appears.
pause
