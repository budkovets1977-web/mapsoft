@echo off
echo === 1. cert= line in NTClientSoftware.ini ===
type C:\NTClientSoftware\config\NTClientSoftware.ini | findstr /C:"cert="
echo.
echo === 2. NTClientSoftware process ===
tasklist | findstr /I "NTClientSoftware"
echo.
echo === 3. Autorun entries (CiszCert) ===
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" | findstr /I "CiszCert"
echo.
echo === 4. Reset backups ===
dir /b C:\NTClientSoftware\config\NTClientSoftware.ini.reset-backup-* 2>nul
echo.
echo === 5. Newest backup content (what cert was cleared) ===
for /f "delims=" %%f in ('dir /b /o-d C:\NTClientSoftware\config\NTClientSoftware.ini.reset-backup-* 2nul') do (
  echo FILE: %%f
  type "C:\NTClientSoftware\config\%%f" | findstr /C:"cert="
  goto :done
)
:done
echo.
pause
