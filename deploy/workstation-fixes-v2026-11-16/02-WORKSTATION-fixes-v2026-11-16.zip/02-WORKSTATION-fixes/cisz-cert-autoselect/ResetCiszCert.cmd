@echo off
REM ResetCiszCert.cmd - double-click wrapper (runs with -Restart)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0ResetCiszCert.ps1" -Restart
pause
